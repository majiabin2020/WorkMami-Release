"""Package and deterministic engine version."""

__version__ = "0.7.0"

__all__ = ["__version__"]
