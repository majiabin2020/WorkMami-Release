"""Load and validate map specifications."""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any, Dict, Tuple

from jsonschema import Draft202012Validator

from .locales import catalog_value, load_catalog
from .resource_files import read_resource_text


class SpecError(ValueError):
    """Raised when a map specification is invalid."""


def load_schema() -> Dict[str, Any]:
    return json.loads(read_resource_text("map-spec.schema.json"))


def current_schema_version() -> str:
    """Return the current output version declared by the packaged Schema."""

    schema = load_schema()
    value = schema.get("properties", {}).get("schema_version", {}).get("const")
    if not isinstance(value, str) or not value:
        raise RuntimeError("The packaged MapSpec Schema does not declare a version constant.")
    return value


def _is_absolute_on_any_platform(value: str) -> bool:
    return (
        Path(value).is_absolute()
        or PurePosixPath(value).is_absolute()
        or PureWindowsPath(value).is_absolute()
    )


def _apply_defaults(instance: Any, schema: Dict[str, Any], root: Dict[str, Any]) -> None:
    if "$ref" in schema:
        target: Any = root
        for part in schema["$ref"].removeprefix("#/").split("/"):
            target = target[part]
        _apply_defaults(instance, target, root)
        return
    if isinstance(instance, dict):
        for key, child_schema in schema.get("properties", {}).items():
            if key not in instance and "default" in child_schema:
                instance[key] = deepcopy(child_schema["default"])
            if key in instance:
                _apply_defaults(instance[key], child_schema, root)
    elif isinstance(instance, list):
        item_schema = schema.get("items")
        if item_schema:
            for item in instance:
                _apply_defaults(item, item_schema, root)


def validate_spec(spec: Dict[str, Any]) -> Dict[str, Any]:
    schema = load_schema()
    resolved = deepcopy(spec)
    if isinstance(resolved, dict) and resolved.get("schema_version") == "1.1":
        resolved["schema_version"] = "1.2"
    _apply_defaults(resolved, schema, schema)
    errors = sorted(Draft202012Validator(schema).iter_errors(resolved), key=lambda e: list(e.path))
    if errors:
        details = []
        for error in errors:
            location = ".".join(str(part) for part in error.absolute_path) or "<root>"
            details.append(f"{location}: {error.message}")
        raise SpecError("Invalid map specification:\n- " + "\n- ".join(details))

    catalog = load_catalog(str(resolved["locale"]))
    missing_label = str(catalog_value(catalog, "style", "missing_label"))
    for layer in resolved["layers"]:
        style = layer.setdefault("style", {})
        style.setdefault("missing_label", missing_label)

    layer_ids = [layer["id"] for layer in resolved["layers"]]
    if len(layer_ids) != len(set(layer_ids)):
        raise SpecError("Layer ids must be unique.")
    absolute_sources = [
        layer["id"]
        for layer in resolved["layers"]
        if _is_absolute_on_any_platform(str(layer["source"]["path"]))
    ]
    if absolute_sources:
        raise SpecError(
            "Source paths must be relative to the specification file: {}".format(
                ", ".join(absolute_sources)
            )
        )
    if resolved["template"] == "map-list":
        primary = resolved.get("primary_layer")
        if not primary:
            raise SpecError("map-list requires primary_layer.")
        if primary not in layer_ids:
            raise SpecError(f"primary_layer {primary!r} does not match a layer id.")
    linked = resolved.get("linked_view")
    if linked and linked["layer"] not in layer_ids:
        raise SpecError("linked_view.layer does not match a layer id.")
    return resolved


def load_spec(path: Path) -> Tuple[Dict[str, Any], Path]:
    spec_path = path.resolve()
    with spec_path.open("r", encoding="utf-8") as handle:
        raw = json.load(handle)
    return validate_spec(raw), spec_path.parent


def write_resolved_spec(spec: Dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(spec, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


__all__ = [
    "SpecError",
    "current_schema_version",
    "load_schema",
    "load_spec",
    "validate_spec",
    "write_resolved_spec",
]
