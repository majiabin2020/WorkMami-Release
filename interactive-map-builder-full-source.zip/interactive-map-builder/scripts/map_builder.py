#!/usr/bin/env python
"""Command-line entry point for interactive-map-builder."""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import sys
import tempfile
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Set, Tuple

import geopandas as gpd
import pandas as pd
import shapely
from shapely.geometry import mapping

from mapcore.arguments import build_parser as _parser
from mapcore.basemaps import basemap_warnings, migrate_legacy_basemaps
from mapcore.arcgis import ArcGISError, download_feature_service
from mapcore.delivery import (
    CORE_OUTPUTS,
    DELIVERY_MANIFEST_NAME,
    KNOWN_STATIC_OUTPUTS,
    DeliveryError,
    copy_unmanaged_files,
    relative_path as delivery_relative_path,
    safe_relative_path,
    target_path as delivery_target_path,
    verify_delivery_manifest,
    write_delivery_manifest,
)
from mapcore.inspect_data import (
    inspect_frame,
    inspect_inputs,
    inspection_summary,
    recommend_template,
)
from mapcore.loaders import DataLoadError, load_source
from mapcore.normalize import normalize_geodata
from mapcore.resource_files import read_resource_text
from mapcore.report import (
    environment_report,
    output_entry,
    sha256_file,
    validate_file_signature,
    write_usage_guide,
    write_json,
)
from mapcore.spec import SpecError, load_spec, validate_spec, write_resolved_spec
from mapcore.spec_init import SpecInitError, init_spec_from_inspection
from mapcore.style import StyleError, resolve_layer_style
from mapcore.validate import ValidationError, ensure_count_consistency, validate_geodata
from mapcore.visual_defaults import resolve_visual_plan
from mapcore.version import __version__


class BuildError(RuntimeError):
    """Raised when a build cannot meet its declared contract."""


LIGHT_FEATURES = 5_000
LIGHT_VERTICES = 100_000
LIGHT_GEOJSON_BYTES = 5 * 1024 * 1024
MEDIUM_FEATURES = 20_000
MEDIUM_VERTICES = 500_000
MEDIUM_GEOJSON_BYTES = 20 * 1024 * 1024
LARGE_HTML_BYTES = 10 * 1024 * 1024


def _json_value(value: Any) -> Any:
    if value is None:
        return None
    try:
        missing = pd.isna(value)
        if isinstance(missing, bool) and missing:
            return None
    except (TypeError, ValueError):
        pass
    if hasattr(value, "item"):
        try:
            return value.item()
        except (TypeError, ValueError):
            pass
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    return str(value)


def _display_label(value: Any, fallback: Any) -> str:
    normalized = _json_value(value)
    if normalized is None or not str(normalized).strip():
        return str(fallback)
    return str(normalized)


def _vertex_count(frame: gpd.GeoDataFrame) -> int:
    return int(
        sum(
            shapely.get_num_coordinates(geometry)
            for geometry in frame.geometry
            if geometry is not None
        )
    )


def _simplification_recommendation(
    feature_count: int,
    vertex_count: int,
    geojson_bytes: int,
) -> str:
    if (
        feature_count > MEDIUM_FEATURES
        or vertex_count > MEDIUM_VERTICES
        or geojson_bytes > MEDIUM_GEOJSON_BYTES
    ):
        return "medium"
    if (
        feature_count > LIGHT_FEATURES
        or vertex_count > LIGHT_VERTICES
        or geojson_bytes > LIGHT_GEOJSON_BYTES
    ):
        return "light"
    return "none"


def _selected_fields(
    layer_spec: Mapping[str, Any],
    linked_view: Optional[Mapping[str, Any]],
    list_config: Optional[Mapping[str, Any]] = None,
) -> Set[str]:
    fields: Set[str] = set()
    for key in (
        "tooltip_fields",
        "popup_fields",
        "search_fields",
        "filter_fields",
        "card_fields",
        "sort_fields",
    ):
        fields.update(str(value) for value in layer_spec.get(key, []))
    for key in ("id_field", "label_field"):
        if layer_spec.get(key):
            fields.add(str(layer_spec[key]))
    if layer_spec.get("link_key"):
        fields.add(str(layer_spec["link_key"]))
    style = layer_spec.get("style", {})
    if style.get("color_field"):
        fields.add(str(style["color_field"]))
    if linked_view and linked_view.get("layer") == layer_spec["id"]:
        fields.add(str(linked_view["x_field"]))
        fields.add(str(linked_view["y_field"]))
    if list_config:
        for metric in list_config.get("summary_metrics", []):
            if isinstance(metric, Mapping) and metric.get("field"):
                fields.add(str(metric["field"]))
    return fields


def _prepare_layer(
    raw: gpd.GeoDataFrame,
    layer_spec: Mapping[str, Any],
    linked_view: Optional[Mapping[str, Any]],
    list_config: Optional[Mapping[str, Any]],
    *,
    template: str,
    primary_layer: Optional[str],
    layer_count: int,
    layer_index: int,
) -> Tuple[gpd.GeoDataFrame, Dict[str, Any], Dict[str, Any]]:
    source_crs = layer_spec["source"].get("crs")
    if raw.crs is None and source_crs is not None:
        raw = raw.set_crs(source_crs)
    id_field = str(layer_spec.get("id_field") or "__map_id")
    label_field = layer_spec.get("label_field")
    id_attributes = [str(label_field)] if label_field and label_field in raw.columns else []
    normalized, normalization = normalize_geodata(
        raw,
        id_field=id_field,
        id_attributes=id_attributes,
        target_crs="EPSG:4326",
        id_prefix=str(layer_spec["id"]),
    )
    raw_style = layer_spec.get("style", {})
    explicit_style = (
        {
            key: value
            for key, value in raw_style.items()
            if key in {"color", "fill_color", "weight", "opacity", "fill_opacity", "radius"}
        }
        if isinstance(raw_style, Mapping)
        else {}
    )
    normalized, resolved_layer_spec, style_report = resolve_layer_style(normalized, layer_spec)
    if isinstance(layer_spec, dict):
        layer_spec.clear()
        layer_spec.update(resolved_layer_spec)

    visual_plan = resolve_visual_plan(
        normalized,
        layer_spec,
        template=template,
        primary_layer=primary_layer,
        layer_count=layer_count,
        layer_index=layer_index,
        explicit_style=explicit_style,
    )

    render_data = normalized
    simplify_preset = str(layer_spec.get("simplify", "none"))
    tolerance = None
    if simplify_preset in {"light", "medium"}:
        bounds = normalized.total_bounds
        diagonal = math.hypot(float(bounds[2] - bounds[0]), float(bounds[3] - bounds[1]))
        divisor = 5000.0 if simplify_preset == "light" else 2000.0
        tolerance = diagonal / divisor if diagonal > 0 else None
    simplified = False
    if tolerance is not None:
        render_data = normalized.copy()
        render_data.geometry = render_data.geometry.simplify(
            float(tolerance), preserve_topology=True
        )
        simplified = True

    required_fields = sorted(_selected_fields(layer_spec, linked_view, list_config))
    style = layer_spec.get("style", {})
    validation = validate_geodata(
        render_data,
        id_field=id_field,
        required_fields=required_fields,
        category_field=style.get("color_field"),
        allowed_categories=style.get("categories"),
        layer_name=str(layer_spec["id"]),
    )

    fields = [field for field in required_fields if field in render_data.columns]
    if id_field not in fields:
        fields.append(id_field)
    render_frame = render_data[fields + [render_data.geometry.name]].copy()
    properties: List[Dict[str, Any]] = []
    features: List[Dict[str, Any]] = []
    for _, row in render_frame.iterrows():
        values = {field: _json_value(row[field]) for field in fields}
        values["__map_id"] = str(row[id_field])
        values["__label"] = (
            _display_label(row[label_field], row[id_field])
            if label_field
            else str(row[id_field])
        )
        properties.append(values)
        features.append(
            {
                "type": "Feature",
                "id": str(row[id_field]),
                "geometry": mapping(row.geometry),
                "properties": values,
            }
        )
    bounds = render_frame.total_bounds.tolist()
    feature_collection = {"type": "FeatureCollection", "features": features}
    geojson_bytes = len(
        json.dumps(
            feature_collection,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        ).encode("utf-8")
    )
    vertex_count = _vertex_count(render_data)
    recommendation = _simplification_recommendation(
        len(features), vertex_count, geojson_bytes
    )
    prepared = {
        "id": layer_spec["id"],
        "spec": dict(layer_spec),
        "feature_collection": feature_collection,
        "records": properties,
        "count": len(features),
        "bounds": bounds,
        "visual": visual_plan,
    }
    layer_report = {
        "id": layer_spec["id"],
        "name": layer_spec["name"],
        "input_count": int(len(raw)),
        "normalized_count": int(len(normalized)),
        "rendered_count": len(features),
        "simplified": simplified,
        "simplify_preset": simplify_preset,
        "performance": {
            "feature_count": len(features),
            "vertex_count": vertex_count,
            "geojson_bytes": geojson_bytes,
            "simplification_recommendation": recommendation,
        },
        "style": style_report,
        "visual": visual_plan,
        "normalization": normalization.to_dict(),
        "validation": validation.to_dict(),
        "warnings": [],
    }
    if normalization.generated_id_count:
        layer_report["warnings"].append(
            "{} generated {} deterministic ID(s).".format(
                layer_spec["id"], normalization.generated_id_count
            )
        )
    if normalization.repaired_count:
        layer_report["warnings"].append(
            "{} repaired {} invalid geometr{}.".format(
                layer_spec["id"],
                normalization.repaired_count,
                "y" if normalization.repaired_count == 1 else "ies",
            )
        )
    for field, count in validation.null_field_counts.items():
        layer_report["warnings"].append(
            "{} field {!r} contains {} null display value(s).".format(
                layer_spec["id"], field, count
            )
        )
    if style_report.get("missing_count"):
        layer_report["warnings"].append(
            "{} mapped {} null categor{} to {!r}.".format(
                layer_spec["id"],
                style_report["missing_count"],
                "y" if style_report["missing_count"] == 1 else "ies",
                layer_spec.get("style", {}).get("missing_label", "Missing"),
            )
        )
    if not layer_spec.get("source_note"):
        layer_report["warnings"].append(
            "{} does not declare source_note.".format(layer_spec["id"])
        )
    if simplified:
        layer_report["warnings"].append(
            "{} used the {!r} geometry simplification preset.".format(
                layer_spec["id"], simplify_preset
            )
        )
    if recommendation != "none" and simplify_preset == "none":
        layer_report["warnings"].append(
            "{} may benefit from {!r} simplification.".format(
                layer_spec["id"], recommendation
            )
        )
    return normalized, prepared, layer_report


def _bundle_spec_sources(
    spec: Mapping[str, Any],
    base_dir: Path,
    destination: Path,
) -> Dict[str, Any]:
    """Copy unique source files into dist/data and rewrite source paths."""

    bundled = deepcopy(dict(spec))
    data_dir = destination / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    copied: Dict[Path, str] = {}
    used_names: Dict[str, Path] = {}
    for layer in bundled["layers"]:
        source_value = str(layer["source"]["path"])
        source = (base_dir / source_value).resolve()
        if not source.is_file():
            raise BuildError("Cannot bundle missing source: {}".format(source))
        if source in copied:
            layer["source"]["path"] = copied[source]
            continue
        candidate = source.name
        folded = candidate.casefold()
        if folded in used_names and used_names[folded] != source:
            candidate = "{}-{}".format(layer["id"], source.name)
            stem = Path(candidate).stem
            suffix = Path(candidate).suffix
            counter = 2
            while candidate.casefold() in used_names:
                candidate = "{}-{}{}".format(stem, counter, suffix)
                counter += 1
        target = data_dir / candidate
        if source != target.resolve():
            shutil.copy2(source, target)
        relative = target.relative_to(destination).as_posix()
        copied[source] = relative
        used_names[candidate.casefold()] = source
        layer["source"]["path"] = relative
    return bundled


def _build_map_in_place(
    spec_path: Path,
    out_dir: Path,
    *,
    bundle_sources: bool = False,
) -> Dict[str, Any]:
    from mapcore.render_html import render_html

    spec, base_dir = load_spec(spec_path)
    destination = out_dir.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    if bundle_sources:
        spec = _bundle_spec_sources(spec, base_dir, destination)
        base_dir = destination
    portable_bundle = bundle_sources or (
        base_dir.resolve() == destination
        and all(
            Path(str(layer["source"]["path"])).parts[:1] == ("data",)
            for layer in spec["layers"]
        )
    )
    warnings: List[str] = basemap_warnings(spec)
    prepared_layers: List[Dict[str, Any]] = []
    static_layers: Dict[str, gpd.GeoDataFrame] = {}
    layer_reports: List[Dict[str, Any]] = []
    inspection_layers: List[Dict[str, Any]] = []
    visual_plans: Dict[str, Dict[str, Any]] = {}

    for layer_index, layer_spec in enumerate(spec["layers"]):
        source_path = Path(layer_spec["source"]["path"])
        resolved_source = source_path if source_path.is_absolute() else base_dir / source_path
        try:
            raw = load_source(layer_spec["source"], base_dir=base_dir)
        except Exception as exc:
            if not layer_spec.get("required", True):
                warnings.append(f"Optional layer {layer_spec['id']} was skipped: {exc}")
                continue
            raise BuildError(f"Required layer {layer_spec['id']} failed to load: {exc}") from exc
        inspection_layers.append(
            inspect_frame(
                raw,
                layer_id=str(layer_spec["id"]),
                name=str(layer_spec["name"]),
                source={
                    key: value
                    for key, value in layer_spec["source"].items()
                    if key != "crs" or value is not None
                },
            )
        )
        normalized, prepared, layer_report = _prepare_layer(
            raw,
            layer_spec,
            spec.get("linked_view"),
            (
                spec.get("list")
                if layer_spec["id"] == spec.get("primary_layer")
                else None
            ),
            template=str(spec["template"]),
            primary_layer=(
                str(spec.get("primary_layer")) if spec.get("primary_layer") else None
            ),
            layer_count=len(spec["layers"]),
            layer_index=layer_index,
        )
        if resolved_source.is_file():
            layer_report["source"] = {
                "path": str(source_path).replace("\\", "/"),
                "bytes": resolved_source.stat().st_size,
                "sha256": sha256_file(resolved_source),
            }
        prepared_layers.append(prepared)
        static_layers[str(layer_spec["id"])] = normalized
        visual_plans[str(layer_spec["id"])] = dict(prepared["visual"])
        layer_reports.append(layer_report)
        warnings.extend(layer_report.get("warnings", []))

    required_ids = {layer["id"] for layer in spec["layers"] if layer.get("required", True)}
    loaded_ids = {layer["id"] for layer in prepared_layers}
    missing_required = sorted(required_ids - loaded_ids)
    if missing_required:
        raise BuildError("Missing required layers: " + ", ".join(missing_required))
    if not prepared_layers:
        raise BuildError("No layers were available to render.")

    primary_count: Optional[int] = None
    if spec["template"] == "map-list":
        primary = next(
            (layer for layer in prepared_layers if layer["id"] == spec["primary_layer"]), None
        )
        if primary is None:
            raise BuildError("The primary layer was not loaded.")
        primary_count = ensure_count_consistency(
            normalized=int(primary["count"]),
            map_features=len(primary["feature_collection"]["features"]),
            list_records=len(primary["records"]),
        )

    html_path = destination / "map.html"
    html_result = render_html(
        spec,
        prepared_layers,
        html_path,
        read_resource_text("vendor", "leaflet-1.9.4", "leaflet.js"),
        read_resource_text("vendor", "leaflet-1.9.4", "leaflet.css"),
    )

    generated_paths: List[Path] = [html_path]
    html_bytes = html_path.stat().st_size
    if html_bytes > LARGE_HTML_BYTES:
        warnings.append(
            "map.html is {:.1f} MiB; browser startup may be slow.".format(
                html_bytes / (1024 * 1024)
            )
        )
    static_result: Dict[str, Path] = {}
    static_font: Dict[str, Any] = {
        "font": None,
        "cjk_text_detected": False,
        "cjk_font_found": None,
        "warning": None,
    }
    if spec.get("static", {}).get("enabled", False):
        from mapcore.render_figure import render_static_figures

        static_result = render_static_figures(
            static_layers, spec, destination, visual_plans=visual_plans
        )
        static_font = dict(static_result.font_report)
        generated_paths.extend(static_result.values())
        if static_font.get("warning"):
            warnings.append(str(static_font["warning"]))

    resolved_spec_path = destination / "map_spec.json"
    write_resolved_spec(spec, resolved_spec_path)
    generated_paths.append(resolved_spec_path)

    inspection_path = destination / "inspection.json"
    build_inspection = {
        "schema_version": "1.0",
        "inputs": [
            {
                "path": str(layer["source"]["path"]).replace("\\", "/"),
                "sha256": layer.get("source", {}).get("sha256"),
                "bytes": layer.get("source", {}).get("bytes"),
            }
            for layer in layer_reports
        ],
        "layers": inspection_layers,
    }
    build_inspection["template_recommendation"] = recommend_template(inspection_layers)
    write_json(build_inspection, inspection_path)
    generated_paths.append(inspection_path)

    usage_path = destination / "README_USAGE.md"
    write_usage_guide(
        usage_path,
        title=str(spec["title"]),
        html_name=html_path.name,
        figure_names=[path.name for path in static_result.values()],
        basemaps=spec.get("basemaps", []),
        portable_bundle=portable_bundle,
        locale=str(spec["locale"]),
    )
    generated_paths.append(usage_path)

    for layer_report, prepared in zip(layer_reports, prepared_layers):
        ensure_count_consistency(
            input=layer_report["input_count"],
            normalized=layer_report["normalized_count"],
            rendered=prepared["count"],
        )

    if spec.get("basemaps"):
        warnings.append(
            "Configured basemap tiles require a network connection."
        )
    report_path = destination / "build_report.json"
    legend_item_count = sum(
        len(layer.get("style", {}).get("categories", {}))
        if isinstance(layer.get("style", {}).get("categories", {}), Mapping)
        else 0
        for layer in spec["layers"]
    )
    report: Dict[str, Any] = {
        "schema_version": "1.0",
        "built_at": datetime.now(timezone.utc).isoformat(),
        "engine_version": __version__,
        "status": "pass",
        "template": spec["template"],
        "title": spec["title"],
        "visual_system": "atlas-studio-light",
        "environment": environment_report(),
        "layers": layer_reports,
        "checks": {
            "data_readable_and_nonempty": True,
            "crs_epsg_4326": True,
            "geometry_valid_and_nonempty": True,
            "unique_ids": True,
            "output_counts_consistent": True,
            "primary_count": primary_count,
            "declared_layer_count": len(spec["layers"]),
            "rendered_layer_count": len(prepared_layers),
            "list_record_count": primary_count,
            "legend_item_count": legend_item_count,
            "html_qa": html_result,
            "portable_bundle": portable_bundle,
            "static_font": static_font,
        },
        "performance": {
            "feature_count": sum(layer["count"] for layer in prepared_layers),
            "vertex_count": sum(
                layer["performance"]["vertex_count"] for layer in layer_reports
            ),
            "geojson_bytes": sum(
                layer["performance"]["geojson_bytes"] for layer in layer_reports
            ),
            "html_bytes": html_bytes,
            "simplification_recommendation": max(
                (
                    layer["performance"]["simplification_recommendation"]
                    for layer in layer_reports
                ),
                key={"none": 0, "light": 1, "medium": 2}.get,
            ),
        },
        "warnings": warnings,
        "basemap_live_check": "not_performed",
        "network_dependencies": [
            {"name": item["name"], "url": item["url"], "attribution": item["attribution"]}
            for item in spec.get("basemaps", [])
        ],
        "outputs": [output_entry(path) for path in generated_paths],
    }
    write_json(report, report_path)
    return {"report_path": str(report_path), "report": report}


def _path_is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def _managed_paths_from_build(staging: Path, report: Mapping[str, Any]) -> List[Path]:
    paths = [staging / "build_report.json"]
    for entry in report.get("outputs", []):
        if isinstance(entry, Mapping) and entry.get("path"):
            paths.append(delivery_target_path(staging, entry["path"]))
    data_dir = staging / "data"
    if data_dir.is_dir():
        paths.extend(path for path in data_dir.rglob("*") if path.is_file())
    unique: Dict[str, Path] = {}
    for path in paths:
        unique[delivery_relative_path(staging, path)] = path
    return [unique[key] for key in sorted(unique)]


def build_map(
    spec_path: Path,
    out_dir: Path,
    *,
    bundle_sources: bool = False,
) -> Dict[str, Any]:
    """Build and verify in a sibling staging directory, then atomically replace the delivery."""

    source_spec = Path(spec_path).resolve()
    destination = Path(out_dir).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(
        tempfile.mkdtemp(
            prefix=f".{destination.name}.staging-",
            dir=str(destination.parent),
        )
    )
    seed: Optional[Path] = None
    backup: Optional[Path] = None
    try:
        effective_bundle = bool(bundle_sources)
        if destination.exists() and _path_is_within(source_spec, destination):
            seed = Path(
                tempfile.mkdtemp(
                    prefix=f".{destination.name}.source-",
                    dir=str(destination.parent),
                )
            )
            shutil.copytree(destination, seed, dirs_exist_ok=True)
            source_spec = seed / source_spec.relative_to(destination)
            effective_bundle = True

        result = _build_map_in_place(
            source_spec,
            staging,
            bundle_sources=effective_bundle,
        )
        report = result["report"]
        managed_paths = _managed_paths_from_build(staging, report)
        managed_relative = [delivery_relative_path(staging, path) for path in managed_paths]
        preserved = copy_unmanaged_files(destination, staging, managed_relative)
        report["checks"]["transactional_delivery"] = True
        report["checks"]["preserved_unmanaged_files"] = preserved
        report["checks"]["bundled_source_integrity"] = any(
            value.startswith("data/") for value in managed_relative
        )
        write_json(report, staging / "build_report.json")
        managed_paths = _managed_paths_from_build(staging, report)
        write_delivery_manifest(
            staging,
            managed_paths,
            engine_version=__version__,
            built_at=report.get("built_at"),
            preserved_unmanaged_files=preserved,
        )
        verify_dist(staging)

        if destination.exists():
            backup = destination.parent / f".{destination.name}.backup-{uuid.uuid4().hex}"
            destination.replace(backup)
        try:
            staging.replace(destination)
        except Exception:
            if backup is not None and backup.exists() and not destination.exists():
                backup.replace(destination)
            raise
        if backup is not None and backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
            backup = None
        result["report_path"] = str(destination / "build_report.json")
        result["report"] = report
        return result
    finally:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        if seed is not None and seed.exists():
            shutil.rmtree(seed, ignore_errors=True)
        if backup is not None and backup.exists() and not destination.exists():
            backup.replace(destination)



def verify_dist(out_dir: Path) -> Dict[str, Any]:
    destination = out_dir.resolve()
    report_path = destination / "build_report.json"
    if not report_path.is_file():
        raise BuildError(f"Missing build report: {report_path}")
    try:
        report = json.loads(report_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BuildError(f"Unreadable build report: {report_path}") from exc

    errors: List[str] = []
    if not isinstance(report, Mapping):
        errors.append("Build report must be a JSON object.")
        report = {}
    if report.get("schema_version") != "1.0":
        errors.append("Build report has an unsupported schema version.")
    if report.get("status") != "pass":
        errors.append("Build report status is not pass.")

    outputs = report.get("outputs", [])
    if not isinstance(outputs, list):
        errors.append("Build report outputs must be an array.")
        outputs = []
    report_paths = set()
    folded = set()
    for entry in outputs:
        if not isinstance(entry, Mapping):
            errors.append("Build report contains a non-object output entry.")
            continue
        try:
            relative = safe_relative_path(entry.get("path"))
            path = delivery_target_path(destination, relative)
        except DeliveryError as exc:
            errors.append(str(exc))
            continue
        if relative in report_paths or relative.casefold() in folded:
            errors.append(f"Build report contains a duplicate output path: {relative}.")
            continue
        report_paths.add(relative)
        folded.add(relative.casefold())
        if not path.is_file() or path.is_symlink():
            errors.append(f"Missing output: {relative}")
            continue
        try:
            expected_bytes = int(entry.get("bytes", -1))
        except (TypeError, ValueError):
            expected_bytes = -1
        if path.stat().st_size != expected_bytes:
            errors.append(f"Size mismatch: {relative}")
        expected_sha = str(entry.get("sha256") or "").casefold()
        if sha256_file(path) != expected_sha:
            errors.append(f"SHA-256 mismatch: {relative}")
        if not validate_file_signature(path):
            errors.append(f"Invalid file signature: {relative}")

    for name in CORE_OUTPUTS:
        if not (destination / name).is_file():
            errors.append(f"Missing required delivery output: {name}")

    _manifest, manifest_paths, manifest_errors = verify_delivery_manifest(destination)
    errors.extend(manifest_errors)
    required_manifest_paths = set(CORE_OUTPUTS) - {DELIVERY_MANIFEST_NAME}
    for name in sorted(required_manifest_paths - manifest_paths):
        errors.append(f"Required delivery output is not managed by the manifest: {name}")
    for name in sorted(report_paths - manifest_paths):
        errors.append(f"Build-report output is not managed by the manifest: {name}")

    try:
        spec = json.loads((destination / "map_spec.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        spec = {}
        errors.append("Resolved map_spec.json is unreadable.")
    expected_static = set()
    static = spec.get("static", {}) if isinstance(spec, Mapping) else {}
    if isinstance(static, Mapping) and static.get("enabled") is True:
        presets = static.get("presets", [])
        if "slide-16x9" in presets:
            expected_static.add("map_slide_16x9.png")
        if "paper" in presets:
            expected_static.update({"map_paper.png", "map_paper.svg", "map_paper.pdf"})
    for name in KNOWN_STATIC_OUTPUTS:
        path = destination / name
        if name in expected_static:
            if not path.is_file():
                errors.append(f"Missing expected static output: {name}")
            if name not in manifest_paths:
                errors.append(f"Expected static output is not managed by the manifest: {name}")
        elif path.exists():
            errors.append(f"Unexpected stale static output: {name}")

    html_entries = [value for value in report_paths if value.lower().endswith(".html")]
    for relative in html_entries:
        html_path = delivery_target_path(destination, relative)
        html_text = html_path.read_text(encoding="utf-8")
        if "__interactiveMapBuilderQA" not in html_text:
            errors.append(f"HTML is missing the QA interface: {relative}")
        if "https://unpkg.com/leaflet" in html_text or "cdnjs.cloudflare.com" in html_text:
            errors.append(f"HTML UI unexpectedly depends on a CDN: {relative}")
    if errors:
        raise BuildError("Verification failed:\n- " + "\n- ".join(errors))
    return {
        "status": "pass",
        "verified_outputs": len(manifest_paths) + 1,
        "report": str(report_path),
        "manifest": str(destination / DELIVERY_MANIFEST_NAME),
    }


def _inspection_from_args(args: argparse.Namespace) -> Dict[str, Any]:
    return inspect_inputs(
        args.inputs,
        layer=args.layer,
        sheet=args.sheet,
        crs=args.crs,
        x_field=args.x,
        y_field=args.y,
        wkt_field=args.wkt,
        encoding=args.encoding,
    )


def _required_path(primary: Optional[str], secondary: Optional[str], label: str) -> Path:
    value = primary or secondary
    if not value:
        raise BuildError("{} is required.".format(label))
    return Path(value)


def _copy_run_inputs(inputs: Sequence[str], destination: Path) -> List[str]:
    data_dir = destination / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    copied: List[str] = []
    used = set()
    for index, value in enumerate(inputs):
        source = Path(value).expanduser().resolve()
        if not source.is_file():
            raise BuildError("Input does not exist: {}".format(source))
        name = source.name
        if name.casefold() in used:
            name = "{}-{}{}".format(source.stem, index + 1, source.suffix)
        used.add(name.casefold())
        target = data_dir / name
        if source != target.resolve():
            shutil.copy2(source, target)
        copied.append(str(target))
    return copied


def main(
    argv: Optional[Sequence[str]] = None,
    *,
    prog: str = "python scripts/map_builder.py",
) -> int:
    args = _parser(prog=prog).parse_args(argv)
    try:
        if args.command == "inspect":
            result = _inspection_from_args(args)
            if args.output:
                write_json(result, Path(args.output))
            print(inspection_summary(result))
            print()
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif args.command == "init-spec":
            inspection_path = _required_path(
                args.inspection, args.inspection_option, "inspection path"
            )
            inspection = json.loads(inspection_path.read_text(encoding="utf-8"))
            output_path = Path(args.output)
            spec = init_spec_from_inspection(
                inspection,
                spec_path=output_path,
                template=args.template,
                title=args.title,
                primary_layer=args.primary_layer,
                locale=args.locale,
            )
            write_json(spec, output_path)
            print(
                json.dumps(
                    {
                        "status": "pass",
                        "template": spec["template"],
                        "layers": len(spec["layers"]),
                        "output": str(output_path.resolve()),
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
        elif args.command == "fetch-arcgis":
            fields = args.out_fields if args.out_fields == "*" else args.out_fields.split(",")
            result = download_feature_service(
                args.url,
                args.out,
                where=args.where,
                out_fields=fields,
                batch_size=args.batch_size,
                provenance_path=args.provenance,
            )
            print(json.dumps(result.to_dict(), ensure_ascii=False, indent=2))
        elif args.command == "build":
            spec_path = _required_path(args.spec_path, args.spec_option, "spec path")
            result = build_map(
                spec_path,
                Path(args.output),
                bundle_sources=args.bundle_sources,
            )
            print(
                json.dumps(
                    {
                        "status": "pass",
                        "report": result["report_path"],
                        "outputs": [
                            entry["path"] for entry in result["report"].get("outputs", [])
                        ]
                        + [Path(result["report_path"]).name, DELIVERY_MANIFEST_NAME],
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
        elif args.command == "migrate-basemaps":
            source, target = Path(args.spec).resolve(), Path(args.output).resolve()
            raw = json.loads(source.read_text(encoding="utf-8"))
            validate_spec(raw)  # Reject invalid input before rebasing any source path.
            migrated, changes = migrate_legacy_basemaps(raw)
            if not changes:
                print(json.dumps({"status": "unchanged", "changes": []}))
                return 0
            for layer in migrated["layers"]:
                original = (source.parent / layer["source"]["path"]).resolve()
                layer["source"]["path"] = Path(os.path.relpath(original, target.parent)).as_posix()
            migrated = validate_spec(migrated)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("x", encoding="utf-8") as handle:
                json.dump(migrated, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
            print(json.dumps({"status": "pass", "changes": changes, "output": str(target)}, ensure_ascii=False))
        elif args.command == "verify":
            print(json.dumps(verify_dist(Path(args.dist)), ensure_ascii=False, indent=2))
        elif args.command == "run":
            destination = Path(args.output).resolve()
            destination.mkdir(parents=True, exist_ok=True)
            copied_inputs = _copy_run_inputs(args.inputs, destination)
            inspection = inspect_inputs(
                copied_inputs,
                layer=args.layer,
                sheet=args.sheet,
                crs=args.crs,
                x_field=args.x,
                y_field=args.y,
                wkt_field=args.wkt,
                encoding=args.encoding,
            )
            inspection_path = destination / "inspection.json"
            write_json(inspection, inspection_path)
            spec_path = destination / "map_spec.json"
            spec = init_spec_from_inspection(
                inspection,
                spec_path=spec_path,
                template=args.template,
                title=args.title,
                primary_layer=args.primary_layer,
                locale=args.locale,
            )
            write_json(spec, spec_path)
            result = build_map(spec_path, destination, bundle_sources=True)
            print(
                json.dumps(
                    {
                        "status": "pass",
                        "template": spec["template"],
                        "report": result["report_path"],
                        "outputs": [
                            entry["path"] for entry in result["report"].get("outputs", [])
                        ]
                        + [Path(result["report_path"]).name, DELIVERY_MANIFEST_NAME],
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
        return 0
    except (
        ArcGISError,
        BuildError,
        DataLoadError,
        SpecError,
        SpecInitError,
        StyleError,
        ValidationError,
        json.JSONDecodeError,
        OSError,
        ValueError,
    ) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
