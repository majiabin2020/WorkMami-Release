# 组件与动效库：选型、许可、Agent 接入

组件库给的是三样东西，顺序不能反：参数（duration/easing/stagger/spring 的可读数值）、节奏（同库组件共用一套时长与缓动）、源码（通过 registry 装进仓库）。前两样属于设计层，第三样属于实现层。

## 一、React 侧

| 库 | URL | 气质与用途 | 许可 |
|---|---|---|---|
| React Bits | https://reactbits.dev/ ／ https://github.com/DavidHDev/react-bits | 51.7k star、216 组件，文字动画/动效/组件/微交互/背景五类，JS/TS × CSS/Tailwind 四种变体，另有五个免费调参工具 | MIT + Commons Clause |
| React Bits Pro | https://pro.reactbits.dev/ | 一次买断约 $129，约 230 组件、300 页面区块、15 套模板、20 个 Agent Skill；做对外分发模板需要它 | 商业 |
| Magic UI | https://magicui.design/ | MIT，150+ 动效组件，Marquee / shimmer / 数字滚动，风格克制，适合当动效语言基线，有官方 MCP | MIT |
| Aceternity UI | https://ui.aceternity.com/ | 200+ 组件，聚光灯、3D 卡片、bento、发光边框。最值得学的是首屏层级而不是单个光效 | 免费 + 付费区块 |
| Motion Primitives | https://motion-primitives.com/ | 组合式动效原语，Text Effect / Scramble / Tilt / 形变 Dialog，整套共享 timing 与 easing，最像「动效语言」而非效果超市 | 开源 |
| Animate UI | https://animate-ui.com/ | Dialog / Tabs / Dropdown / Tooltip 的动效优先实现，用来研究微交互的时机与落点 | 开源 |
| Smooth UI | https://smoothui.dev/ | AI 产品界面，输入框、生成反馈、动态岛，顺滑克制，带无障碍与响应式状态 | 开源 |
| Cult UI | https://www.cult-ui.com/ | 在 shadcn/ui 之上打磨细节，Apple 质感，适合研究同一基础组件靠间距与状态过渡做出贵的感觉 | 部分付费 |
| Kokonut UI | https://kokonutui.com/ | 100+ 组件，流光文字、粒子按钮、动态 SVG 背景；注册表机器可读 | 开源 |
| Fancy Components | https://fancycomponents.dev/ | playful 物理、跟随光标的动能排版、重力卡片，依赖很少，属「效果酷炫」一档 | 免费开源 |
| Animata | https://animata.design/ | 80+ 纯 Tailwind copy-paste 动画，不引入动画运行时，最轻的一档 | 开源 |
| Uiverse | https://uiverse.io/ | 3,000+ 社区 UI 元素，找某个控件的一百种做法最快；质量参差，脚本访问返回 403 但浏览器正常 | 社区贡献 |
| Origin UI / Kibo UI / HyperUI | https://originui.com/ ／ https://www.kibo-ui.com/ ／ https://www.hyperui.dev/ | 表单认证定价表 / 复杂控件 / 营销电商大合集。三家不带强视觉主张，适合规范定好之后按结构取件 | 开源 |
| ThreeUI / Componentry / Watermelon UI | https://threeui.com/ ／ https://componentry.fun/ ／ https://ui.watermelon.sh/ | Three.js 与 WebGL 背景首屏 / 动效优先交互件 / Tailwind+Radix+Motion 组件 | 开源 |
| shadcn/ui | https://ui.shadcn.com/ ／ https://github.com/shadcn-ui/ui | 约 12 万 star，Blocks 与开放 Registry，官方 MCP 与 Skills，是整套 registry 生态的地基 | MIT |

注：coss ui 与 Origin UI 是两个独立项目，不是改名关系。

## 二、Vue / Nuxt 侧

| 库 | URL | 要点 |
|---|---|---|
| Vue Bits | https://vue-bits.dev/ ／ https://github.com/DavidHDev/vue-bits | React Bits 的官方 Vue 移植，同一作者 David Haz，注册表列 201 组件，MIT + Commons Clause。用 shadcn CLI 或 jsrepo 逐件安装 |
| Inspira UI | https://inspira-ui.com/ | 130+ 组件，Vue 3 / Nuxt 专用，Tailwind v4 + motion-v + GSAP + Three.js，官方推荐复制源码而非装依赖 |
| motion-v | https://motion.dev/ ／ https://github.com/motiondivision/motion-vue | Motion 的官方 Vue 版，与 React 不是同一个 import；`useReducedMotion`、`useMotionValue`、`stagger` 两套基本一致 |
| Nuxt UI / shadcn-vue | https://ui.nuxt.com/ | Reka UI + Tailwind，Vue 侧对齐 shadcn 设计语言的组件层 |
| Nuxt 官方模板 | https://nuxt.com/templates | 43 个模板，每个在干净环境每日构建验证。`pnpm create nuxt@latest my-app -t landing` |
| Svelte Bits | https://sveltebits.xyz/ | 同一作者的 Svelte 移植，说明 Bits 这套动效语言可跨框架沿用 |

Vue Bits 依赖按组件分化：文字与 2D 动效走 gsap、motion-v、@vueuse/motion、lenis；shader 背景会拉进 three、@tresjs/core、OGL、postprocessing、matter-js，装前先看该组件依赖清单。Inspira UI 官网动效很满，看的时候别照着堆。

## 三、Shader 与特效

| 资源 | URL | 要点 |
|---|---|---|
| Paper Shaders | https://shaders.paper.design/ ／ https://github.com/paper-design/shaders | Apache-2.0 零依赖 Canvas shader，MeshGradient / DotOrbit / Dithering / Warp / Noise，可视化调完导出代码 |
| Shader Lab | https://eng.basement.studio/tools/shader-lab | Gradient / Pattern / Text / Dithering / CRT 分层可调，能加关键帧或绑音频 |
| Shader Gradient | https://shadergradient.co/ | 动画 3D 着色器渐变，先调顺颜色与噪声再导出代码 |
| Three.js / R3F | https://threejs.org/ | Web 3D 地基，React 侧用 R3F + Drei。r184 起 WebGLRenderer 进入维护模式 |

性能与许可见 `motion.md` 第七、八节。shader 与 3D 组件必须准备静态兜底。

## 四、让 Agent 真正能调用

```bash
# shadcn MCP：搜索、查看源码、取示例、生成安装命令（只读），写入仍由 CLI 完成
npx shadcn@latest mcp init --client claude
npx shadcn@latest add button

# 跨命名空间统一检索：components.json 里把 @react-bits 指向 https://reactbits.dev/r/{name}.json
npx shadcn@latest add @react-bits/Aurora-TS-TW

# 装之前先读依赖与源码
curl -s https://reactbits.dev/r/SplitText-TS-TW.json

# 官方给 Agent 读的索引
# https://reactbits.dev/llms.txt

# 另一条逐件安装通道
npx jsrepo@latest add https://reactbits.dev/r/SplitText-TS-TW

# 第三方组件库 Skill
npx terminal-skills install react-bits
npx skills add https://github.com/emilkowalski/skills --skill emil-design-eng
```

优先选有 `llms.txt` 或 registry 的库；只给截图不给机器可读入口的库，Agent 只能靠猜。组件源码进仓库前逐个核 LICENSE。

## 五、可 clone 的完整开源站点

React / Next.js：`https://github.com/reactjs/react.dev`（克制排版）、`https://github.com/shadcn-ui/ui`（含官网源码）、`https://github.com/cruip/open-react-template`、`https://github.com/cruip/tailwind-landing-page-template`、`https://github.com/Mthize/Awwwards-Winning-Website`（React 19 + GSAP）、`https://github.com/Thakuma07/Truus.co-Awwward-Website`（获奖站重建）、`https://github.com/Ali-Sanati/awwwards-adidas`（R3F 3D 产品页）、`https://github.com/7ovr/shadcn-next-starter`（自带 CLAUDE.md 约定）、`https://www.shadcn.io/awesome/templates`（66 个模板目录）。

Vue / Nuxt：`https://github.com/nuxt-ui-templates/landing`、`https://madewithwhat.net/vue`、`https://madewithwhat.net/nuxt`。这一侧资源明显少于 React，优先官方入口。

商业模板（如 Agntix、ThemeForest）只能当版式与动效编排的视觉参考，不能把源码交给模型复刻。
