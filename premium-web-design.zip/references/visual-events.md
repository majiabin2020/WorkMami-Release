# 视觉事件：九个可以直接搭出来的段落

字号大不等于有冲击力。一页里真正让人停下来的，是**完整的视觉事件**：一个段落从结构、尺寸、动效到滚动位置是一整套设计，缺一块就塌。

这里的九个事件都能用原生 CSS 加几十行 JS 加一两段素材做出来，不需要 GSAP、不需要 Three.js、不需要构建工具。每个事件都给了结构、代码骨架、验收数值和失败样子。

## 先定数量

- 一页放 **2 到 4 个**，不要超过 4 个。超过就互相打架，观众记不住任何一个。
- 事件 07 和 08 吃素材：四张同机位的图，或者一段几秒的片子。用户没有素材就先按 `asset-generation.md` 生成，不要因为没图就跳过这两件。
- 位置固定：**首屏必须一个**（决定第一印象），**中段一个**（撑住滚动），**结尾一个**（收尾）。
- 同一种事件全页只能用一次。三个段落都用满屏出血，等于没有事件。
- 事件 00（入场编排）不算在 2 到 4 个里。它只发生在加载的头 2 秒，不占滚动段落，但首屏那一个事件必须带上它。

## 通用前提（每个事件都遵守）

1. 元素默认就是终态，动画只把终态重放一遍。脚本不执行、减弱动效开启时，页面直接停在完成状态。
2. 滚动进度用 CSS 变量传递：JS 只写 `el.style.setProperty('--p', 0..1)`，位移和缩放全部写在 CSS 的 `calc()` 里。这样样式和逻辑分离，Agent 改起来不会互相踩。
3. 每帧只读一次 `getBoundingClientRect`，并在 `scroll` 事件里用 `requestAnimationFrame` 节流。
4. 移动端降级：视差、钉住、光标跟随全部关掉，只保留静态排布。`100svh` 在手机上比 `100vh` 稳。

---

## 事件 00 · 首屏入场编排

**用在**：页面加载后的头 1.8 秒。用户还没滚动，先决定他会不会往下看。这一层和滚动无关，所以单独算一件事。

**结构**：不动 DOM，只给首屏里已有的四层（图、巨字、文案、底部信息条）配三组 keyframes，靠延迟排出先后。

**核心思路**：不是"一起淡入"，是**分三层依次进场**——图片先从左边刷出来（clip-path），巨字逐字从下面浮上来，文案按阅读顺序一行行跟上。三层时间轴有重叠，不是排队。

```css
@keyframes heroClip { from { clip-path: inset(0 0 0 100%); } to { clip-path: inset(0 0 0 0); } }
@keyframes heroRise { from { opacity: 0; transform: translateY(64px); } to { opacity: 1; transform: none; } }
@keyframes heroRow  { from { opacity: 0; transform: translateY(40px); } to { opacity: 1; transform: none; } }

/* 第一层：图片从左往右刷出，1.4 秒 */
.hero__media { animation: heroClip 1400ms cubic-bezier(.16, 1, .3, 1) both; }

/* 第二层：巨字逐字上浮，每个字母 80ms 错开，从 380ms 起跑 */
.hero__mega span { animation: heroRise 900ms cubic-bezier(.16, 1, .3, 1) both; }
.hero__mega span:nth-child(1) { animation-delay: 380ms; }
.hero__mega span:nth-child(2) { animation-delay: 460ms; }
.hero__mega span:nth-child(3) { animation-delay: 540ms; }
.hero__mega span:nth-child(4) { animation-delay: 620ms; }
.hero__mega span:nth-child(5) { animation-delay: 700ms; }
.hero__mega span:nth-child(6) { animation-delay: 780ms; }

/* 第三层：文案按阅读顺序，从 620ms 起每级 +80 到 +100ms */
.hero__eyebrow { animation: heroRow 700ms cubic-bezier(.16, 1, .3, 1) 620ms both; }
.hero__title   { animation: heroRow 800ms cubic-bezier(.16, 1, .3, 1) 700ms both; }
.hero__lede    { animation: heroRow 800ms cubic-bezier(.16, 1, .3, 1) 800ms both; }
.hero__cta     { animation: heroRow 800ms cubic-bezier(.16, 1, .3, 1) 900ms both; }
.hero__foot    { animation: heroRow 800ms cubic-bezier(.16, 1, .3, 1) 1000ms both; }
```

**关键数值**

| 项 | 值 | 为什么 |
|---|---|---|
| 图片揭示 | 1400ms | 短了看不出来，长了像卡住 |
| 巨字单字时长 | 900ms | 位移 64px，慢一点才有"浮上来"的重量 |
| 巨字错开 | 80ms／字 | 六个字母拖出 400ms 的尾巴，多于 120ms 就散架 |
| 巨字首字延迟 | 380ms | 等图片铺开一半再出来 |
| 文案首条延迟 | 620ms | 和巨字第二、三个字母同时发生 |
| 全流程收尾 | 约 1800ms | 超过 2500ms，用户已经滚走了 |
| 缓动 | `cubic-bezier(.16, 1, .3, 1)` | 起步快、尾巴长，不是 `ease-out` 那种一冲就停 |

**必须做的三件事**

1. 全部用 `animation-fill-mode: both`，写死在 CSS 里。不要用「默认 `opacity: 0` 等 JS 加类」的做法——JS 一旦报错，整屏就是白的。
2. 字体、图片必须是本地资源或已经预加载的，否则动画跑完了图才到，等于没做。
3. 减弱动效下**必须停掉这一层**，直接给终态。滚动入场那套 `.js-anim` 管不到加载入场，这是最容易漏的一处：

```css
@media (prefers-reduced-motion: reduce) {
  .hero__media,
  .hero__mega span,
  .hero__eyebrow,
  .hero__title,
  .hero__lede,
  .hero__cta,
  .hero__foot {
    animation: none !important;
    clip-path: none !important;
    opacity: 1 !important;
    transform: none !important;
  }
}
```

**失败样子**

- 四层一起 `opacity 0 → 1`：这是所有模板的默认值，等于没做入场。
- 位移给到 200px 以上：元素从屏幕外飞进来，浮夸，掉档。
- 每个元素之间隔 300ms 排队进场：像 PPT 逐条飞入，观众会等得不耐烦。
- 只动文字不动图：图片是首屏面积最大的一层，它不动，整屏就是静的。
- 巨字用 `clip-path` 从下往上擦出：字母被切成横条，认不出来，比不动更糟。
- 忘了减弱动效：这次实测就踩到了——图刷、字浮、文案跟，一共 12 个动画在跑，`prefers-reduced-motion` 只停了滚动那部分。

---

## 事件 01 · 满屏出血 + 压底巨字

**用在**：首屏。这是全页最贵的一屏，决定「像获奖站」还是「像模板」。

**结构**：一层满屏图 + 一层压底巨字 + 一层文案。文案在上半部，巨字在下三分之一并越出视口。

```html
<section class="hero">
  <div class="hero__media" data-hero-media>
    <img src="hero.jpg" alt="……">
  </div>
  <div class="hero__content">
    <p class="hero__eyebrow mono">BRAND / CATEGORY / EST. 1891</p>
    <h1 class="hero__title">主标题两行以内<br>第二行</h1>
    <p class="hero__lede">三到四行说明，不要超过四行。</p>
    <a class="hero__cta" href="#next">一个明确动作 ↓</a>
  </div>
  <div class="hero__foot"><span>01 / 06</span><p>图注</p><span>SCROLL ↓</span></div>
  <div class="hero__mega" aria-hidden="true">
    <span>S</span><span>C</span><span>A</span><span>N</span><span>I</span><span>A</span>
  </div>
</section>
```

```css
.hero {
  --mega: clamp(96px, 27vw, 396px);
  --p: 0;                         /* JS 写入的滚动进度 */
  position: relative;
  min-height: min(100svh, 960px);
  display: flex; flex-direction: column;
  padding-top: 112px;
  padding-bottom: calc(var(--mega) * 0.65);   /* 给巨字留位置，foot 不会压上去 */
  overflow: hidden;
  background: #161614; color: #FAFAF8;
  isolation: isolate;
}
.hero__media { position: absolute; inset: -6% 0; z-index: 0;
  transform: scale(calc(1.08 - var(--p) * 0.06)) translateY(calc(var(--p) * 5vh)); }
.hero__media img { width: 100%; height: 100%; object-fit: cover;
  filter: grayscale(1) contrast(1.08) brightness(0.50); }   /* 压曝光，不压灰遮罩 */
.hero__content { position: relative; z-index: 3; }
.hero__mega {
  position: absolute; left: 48px; bottom: -0.16em; z-index: 2;
  display: flex; white-space: nowrap;
  font-size: var(--mega); line-height: 0.78; letter-spacing: -0.062em;
  transform: translate3d(0, calc(var(--p) * -9vh), 0);
}
```

**关键数值**

| 项 | 值 | 为什么 |
|---|---|---|
| 字标字号 | `clamp(96px, 27vw, 396px)` | 1440 宽时约 389px，六个字母刚好横跨内容宽度 |
| 越界裁切 | `bottom: -0.16em` | 约裁掉字高的 20%，15–25% 是「刻意」区间，裁 5% 像渲染出错，裁 40% 像断头 |
| 图片曝光 | `brightness(0.5)` 上下 | 压到 0.5 白字才稳；压到 0.7 亮部会把字吃掉 |
| 首屏高度 | `min(100svh, 960px)` | 超宽屏不限高，普通本正好一屏 |
| 滚动位移 | 字标 `-9vh`、图片 `+5vh` | 反向运动，产生「穿过」感，同向会显得黏 |

**失败样子**

- 用 `rgba` 灰遮罩盖整张图：明暗全被抹平，页面立刻发灰，这是最常见的一处塌方。
- 巨字只做 `opacity: 0→1`：字是出来了，但没有位移和裁切关系，看着像贴图。
- `padding-bottom` 按百分比写：百分比 padding 按宽度算、`bottom` 按高度算，手机上必然重叠。

---

## 事件 02 · 滚动推移带

**用在**：首屏之后，作为第一章的开场。作用是「把时间或数量铺开」，成本极低，节奏感极强。

**结构**：一条深色横带，里面一行超大年份或数字，随滚动横向推移。内容重复两遍，保证推移过程中不断档。

```html
<section class="ticker" aria-label="关键年份">
  <div class="ticker__track" data-shift>
    <span>1891</span><i></i><span>1902</span><i></i><span>2025</span><i></i>
    <span>1891</span><i></i><span>1902</span><i></i><span>2025</span><i></i>
  </div>
</section>
```

```css
.ticker { overflow: hidden; background: #161614; color: #FAFAF8; padding-block: 24px; }
.ticker__track {
  display: flex; align-items: center; gap: clamp(28px, 4vw, 72px);
  width: max-content;
  font-family: var(--font-mono); font-size: clamp(44px, 7.2vw, 104px);
  line-height: 1; letter-spacing: -0.05em;
  transform: translate3d(calc(var(--shift, 0) * 1vw), 0, 0);
  will-change: transform;
}
.ticker__track i { width: 10px; height: 10px; background: var(--accent); flex: none; }
```

```js
var r = ticker.getBoundingClientRect();
var p = clamp01((innerHeight - r.top) / (innerHeight + r.height));
track.style.setProperty('--shift', 26 - p * 46);   // +26vw → -20vw
```

**关键数值**

- 字号 `clamp(44px, 7.2vw, 104px)`：比正文大 5–8 倍，比首屏字标小一号，形成第二层级。
- 位移区间 `+26vw → -20vw`：跨度 46vw，滚动时肉眼明确能看到移动，又不至于把内容甩出去。
- 分隔符用实心小方块，不用圆点、不用图标。

**失败样子**

- 用 `animation: marquee linear infinite` 自动滚。这是无限循环，违反反 AI 味禁令，而且和滚动位置无关，用户会觉得是模板组件。
- 内容只写一遍：推移到后半段就露出空白。

---

## 事件 03 · 钉住图文 + 镜头推移

**用在**：讲一段有时间线的历史、流程、案例。左边文字往下走，右边图钉住不动，同时图内部缓慢推近，像镜头在推。

```html
<div class="chapter__body">
  <div class="chapter__text">……长文与时间线……</div>
  <figure class="chapter__media">
    <div class="chapter__frame"><img src="x.jpg" alt="……"></div>
    <figcaption>图注</figcaption>
  </figure>
</div>
```

```css
.chapter__body { display: grid; grid-template-columns: 5fr 6fr; gap: clamp(32px, 5vw, 96px); align-items: start; }
.chapter__media { position: sticky; top: 104px; margin: 0; }   /* 钉住 */
.chapter__frame { overflow: hidden; height: clamp(340px, 66vh, 620px); }
.chapter__frame img {
  width: 100%; height: 100%; object-fit: cover;
  transform: scale(calc(1.14 - var(--sp, 0) * 0.14));   /* 1.14 → 1.00 */
  will-change: transform;
}
```

**前提**：左栏内容高度必须明显大于图片高度，否则 sticky 没有可钉的空间。

**关键数值**

- 图片高度 `66vh` 上下：比半屏高、比全屏矮，给左栏留出滚动距离。
- 推近幅度 `1.14 → 1.00`：14% 就够，超过 20% 会出现像素拉伸。
- 钉住位置 `top: 104px`：要大于导航高度，否则图会被导航切掉一截。

**失败样子**

- 图片高度设成 `auto`：sticky 没有行程，看起来和普通图文没区别。
- 用 `background-attachment: fixed` 代替：手机上全部失效，还会掉帧。

---

## 事件 04 · 整屏段落 + 反向位移

**用在**：中段。全页最强的一次视觉停顿，用来放一个地点、一个产品、一个数字。

```html
<section class="bleed">
  <div class="bleed__media" data-bleed-media><img src="y.jpg" alt="……"></div>
  <div class="bleed__inner">
    <p class="bleed__eyebrow mono">03 / PLACE · 2025</p>
    <div class="bleed__word" aria-hidden="true">RUGAO</div>
    <p class="bleed__lede">两句事实说明。</p>
  </div>
</section>
```

```css
.bleed {
  --bp: 0;
  position: relative; height: min(100svh, 880px); min-height: 560px;
  display: grid; align-content: space-between;
  padding-block: clamp(112px, 15vh, 172px) clamp(48px, 8vh, 88px);
  overflow: hidden; isolation: isolate;
  background: #161614; color: #FAFAF8;
}
.bleed__media { position: absolute; inset: -12% 0; z-index: 0;
  transform: translate3d(0, calc(var(--bp) * -8vh), 0) scale(1.06); }
.bleed__media img { filter: grayscale(1) contrast(1.1) brightness(0.44); }
.bleed__word {
  font-size: clamp(84px, 26vw, 400px); line-height: 0.78; letter-spacing: -0.06em;
  transform: translate3d(calc(var(--bp) * -7vw), 0, 0);   /* 与图片反向 */
}
.bleed__lede { justify-self: end; max-width: 420px; }
```

**关键数值**

- 图片与巨字**反向**（一个向上一个向左）：同向会显得整块在飘，反向才有「穿过」的立体感。
- 顶部内距必须 ≥ 112px：手机上和导航折行后的高度打架，这是最容易漏的一处。
- 巨字宽度控制在内容宽度的 90–110%：超过就会把说明文字推出去。

**失败样子**

- 巨字直接压满整屏不留说明：只有字没有信息，看完记不住这是哪家公司。
- 顶部内距写成 72px：桌面端导航 76px 会压住小标题。

---

## 事件 05 · 账本式数据墙

**用在**：三个以上真实数字要展示时。不要做 2×2 卡片，做竖排账本。

```html
<div class="stats__list">
  <div class="stats__row" data-reveal>
    <span class="stats__num" data-count-to="53000" data-count-format="comma">53,000</span>
    <span class="stats__label">员工人数，约</span>
  </div>
  <!-- 每条一行 -->
</div>
```

```css
.stats__list { border-top: 1px solid var(--line); }
.stats__row {
  display: grid; grid-template-columns: 1fr 0.72fr;
  align-items: baseline; gap: 32px;
  padding-block: clamp(18px, 2.2vw, 34px);
  border-bottom: 1px solid var(--line);
}
.stats__num { font-size: clamp(46px, 8.4vw, 138px); line-height: 0.94; letter-spacing: -0.055em; }
.stats__label { font-size: 13px; color: var(--muted); text-align: right; }
```

**关键数值**

- 数字 `clamp(46px, 8.4vw, 138px)`，标签 13px：单条内部就有 10 倍跨度。
- 分隔线只有 1px，不用卡片、不用底色、不用阴影。
- 数字进视口时从 0 计到真值，1.2–1.4 秒一次，不循环；2.8 秒后强制写回真值兜底。

**失败样子**

- 用 `text-align: center` 居中：账本感全丢，变回卡片墙。
- 数字是编的：所有大数字必须有年份和出处，这条比好看重要。

---

## 事件 06 · 光标跟随

**用在**：桌面端，有大幅图片时。成本约 20 行，但对「精致感」的贡献远高于成本。

```css
.cursor {
  position: fixed; left: 0; top: 0; width: 56px; height: 56px; margin: -28px 0 0 -28px;
  z-index: 40; pointer-events: none; opacity: 0;
  display: grid; place-items: center;
  transition: opacity 300ms var(--ease-enter);
}
.cursor::after {
  content: ""; width: 56px; height: 56px;
  background: var(--accent); border: 1px solid transparent;
  transform: scale(0.143);        /* 8px 实心小方块 */
  transition: transform 340ms var(--ease-enter), background-color 340ms, border-color 340ms;
}
.cursor.is-wide::after { transform: scale(1); background: transparent; border-color: rgba(250,250,248,.72); }
```

```js
if (window.matchMedia('(hover: hover)').matches) {
  var cx = 0, cy = 0, tx = 0, ty = 0;
  addEventListener('mousemove', function (e) {
    tx = e.clientX; ty = e.clientY;
    cursor.classList.add('is-live');
    cursor.classList.toggle('is-wide', !!(e.target.closest && e.target.closest('.hero, .bleed, .chapter__frame')));
  }, { passive: true });
  (function loop() {
    cx += (tx - cx) * 0.2; cy += (ty - cy) * 0.2;
    cursor.style.transform = 'translate3d(' + cx + 'px,' + cy + 'px,0)';
    requestAnimationFrame(loop);
  })();
}
```

**关键数值**

- 跟随系数 `0.2`：太小会黏手，太大像瞬移。0.15–0.25 之间。
- 尺寸固定 56px 用 `scale` 缩放，不要用 `width/height` 过渡（会触发布局并违反体检规则）。
- `(hover: hover)` 才启用，触屏设备直接不加载。

**失败样子**

- 把 `cursor: none` 藏掉系统指针：可用性灾难，不要做。
- 光标不做区域变色：在白色背景上白方框完全看不见。

---

## 事件 07 · 序列帧推进

**用在**：需要把「过程」讲清楚的段落，比如装配、生长、开门、施工、装卸。四到六张同机位的图，滚动一段换一张。

**为什么值钱**：静态图只能给一个结果，序列给人一个过程。同一张画面反复出现会腻，而过程是越看越有意思的，这也是最不像模板的一种做法。

**结构**：一个很高的轨道装一个满屏的 sticky 舞台，所有帧叠在同一个位置。

```html
<section class="seq" id="assembly">
  <div class="seq__stage">
    <div class="seq__frames">
      <figure class="seq__frame" data-seq-frame>
        <img src="assets/img/seq-01.jpg" alt="这一帧具体画了什么">
        <figcaption class="seq__cap">
          <span class="seq__cap-num mono">01</span>
          <span class="seq__cap-name">车架落位</span>
          <span class="seq__cap-text">一句话说明这一阶段</span>
        </figcaption>
      </figure>
      <!-- 其余各帧同样写法 -->
    </div>
    <p class="seq__top mono">02 / 装配</p>
    <div class="seq__hud">
      <div><span data-seq-num></span><span data-seq-name></span></div>
      <p data-seq-desc></p>
    </div>
    <div class="seq__bar"><i data-seq-bar></i></div>
  </div>
</section>
```

```css
.seq { background: #0E0E0C; color: #FAFAF8; }
.seq__frame img { display: block; width: 100%; height: auto; filter: grayscale(1) brightness(.74); }
.seq__cap { display: grid; grid-template-columns: auto 1fr; column-gap: 24px; row-gap: 8px;
            align-items: baseline; padding: 16px 48px 32px; }
.seq__cap-num { font-family: var(--mono); font-size: 13px; color: rgba(250,250,248,.56); }
.seq__cap-name { font-size: 21px; }
.seq__cap-text { grid-column: 2; max-width: 46ch; font-size: 13px; line-height: 1.55;
                 color: rgba(250,250,248,.82); }
.js-anim .seq__cap { display: none; }      /* 脚本接管后由 HUD 说话 */
.seq__hud, .seq__bar { display: none; }    /* 没脚本时整段就是四张竖排大图加图注 */

.js-anim .seq { height: 360vh; }
.js-anim .seq__stage { position: sticky; top: 0; height: 100svh; overflow: hidden; }
.js-anim .seq__frames { position: absolute; inset: 0; }
.js-anim .seq__frame { position: absolute; inset: 0; opacity: 0; }
.js-anim .seq__frame:first-child { opacity: 1; }
.js-anim .seq__frame img { width: 100%; height: 100%; object-fit: cover; filter: grayscale(1) brightness(.6); }
```

```js
/* 图注是唯一的数据源，HUD 从图注里搬字，不要另存一套 data-name/data-desc */
var caps = frames.map(function (f) {
  return { name: f.querySelector('.seq__cap-name'), text: f.querySelector('.seq__cap-text') };
});

function updateSeq(p) {
  var n = frames.length, t = p * n;
  for (var i = 0; i < n; i++) {
    var fadeIn = clamp01((t - i + 0.35) / 0.35);
    var fadeOut = (i === n - 1) ? 1 : clamp01((i + 1 - t) / 0.35);
    frames[i].style.opacity = Math.min(fadeIn, fadeOut).toFixed(3);
    frames[i].style.transform = 'scale(' + (1.05 - 0.05 * clamp01(t - i)).toFixed(4) + ')';
  }
  var idx = Math.min(n - 1, Math.floor(t));
  if (idx !== lastIndex) {          /* 帧号只在变化时写文字，别每帧都动 DOM */
    lastIndex = idx;
    numEl.textContent = ('0' + (idx + 1)).slice(-2);
    nameEl.textContent = caps[idx].name ? caps[idx].name.textContent : '';
    descEl.textContent = caps[idx].text ? caps[idx].text.textContent : '';
  }
}
```

**关键数值**

| 项 | 值 | 为什么 |
|---|---|---|
| 轨道高度 | 每个事件 300–380vh | 低于 250vh 帧还没看清就被推走 |
| 轨道总高 | 帧数 × 90vh 左右 | 四帧约 360vh |
| 淡入淡出区间 | 0.35 段 | 小于 0.2 会像硬切，大于 0.5 会出现双影 |
| 帧内缩放 | 1.05 → 1.00 | 只在帧自己的区间里走完 |
| 进度条 | 2px，主题色 | 唯一的「还有多少」提示 |

**必须做的四件事**

1. **四帧的机位、厂房、光线必须一致**，只有主体在变。不一致就不是序列，是四张不相干的图。做法是用图生图，拿第一帧当底图改主体。
2. **最后一帧不淡出。** 按统一公式算，最后一帧在终点会淡成 0，滚到底就是一块黑屏。
3. **用 `data-seq-frame` 标记每一帧**。体检脚本按这个约定数「序列帧推进」这个事件，不标记就识别不到。
4. **帧名和说明只写在 `figcaption` 里一份，HUD 从图注里读文字，不要在 `data-` 属性上再抄一遍。** 图注是没脚本时的正脸内容：这些文字一旦只挂在 `data-` 属性上，用户一开「减弱动效」或者脚本加载失败，四张图就没有任何说明，读者不知道自己在看什么。HUD 里的 `<span>` 保持空标签即可，反正它在没脚本时是 `display:none`。

**失败样子**

- 四张图机位各不相同：看着像幻灯片轮播，读者会以为图放错了。
- 每帧停留太短（轨道 < 250vh）：字还没读完就跳下一帧。
- 帧号文字每帧都重写 DOM：滚动时抖。
- 只做透明度不做缩放：图会「闪」而不是「推」。
- 忘了降级：没脚本时四帧全叠在一起，只看到最后一张。
- 降级成了但没图注：四张没头没尾的图排成一列，读者不知道每一张是什么。

---

## 事件 08 · 视频时间轴

**用在**：需要真实运动的段落，一段雪、一段车流、一段机器运转、一段人流。视频放对了是降维打击，放错了就是模板站的自动播放背景。

**结构**：和序列帧一样是 sticky 轨道，钉住的换成一个 `<video>`。

```html
<section class="film" id="road">
  <div class="film__stage">
    <video id="filmVideo" muted playsinline preload="none"
           poster="assets/video/poster.jpg" aria-label="画面描述"></video>
    <div class="film__inner">
      <p class="film__index mono">07 / 公路</p>
      <p class="film__line">出厂那天，<br>路才开始。</p>
      <p class="film__note">画面为 AI 生成的示意片段。播放进度由滚动控制。</p>
    </div>
    <div class="film__bar"><i data-film-bar></i></div>
  </div>
</section>
```

```js
/* 滚到附近才给 src，首屏不为视频买单 */
if (rect.top < innerHeight * 2.2) {
  video.src = 'assets/video/clip.mp4';
  video.preload = 'auto';
  video.load();
}

/* 滚动进度直接写播放头 */
function updateFilm(p) {
  if (!ready || !video.duration) return;
  var t = p * (video.duration - 0.08);
  if (Math.abs(video.currentTime - t) > 0.04) video.currentTime = t;
}
```

**关键数值**

| 项 | 值 | 为什么 |
|---|---|---|
| 片长 | 3–6 秒 | 再长就是正片，滚动拖不完 |
| 文件大小 | < 1.5MB | 拖时间轴要能瞬间到位 |
| 轨道高度 | 250–300vh | 短了拖不动，长了空转 |
| 首帧亮度 | 压到 0.4–0.5 | 视频一般比图片亮，白字压不住 |
| 文字可读 | 底部 45% 高度加黑渐变 | 只压文字区，上半截保持干净 |

**必须做的三件事**

1. **不自动播放、不循环。** `<video>` 不加 `autoplay` 和 `loop`，判据是 `video.paused === true`。自动循环的背景视频是最典型的模板味。
2. **别指望生成模型把推近做够，自己再叠一层缩放。** 实测一段要求「推近 5%」的片子，首尾帧的平均差异只有 5/255，滚到底几乎看不出变化。可靠做法是在视频上再写一条 `transform: scale(calc(1 + var(--fp) * 0.12))`，滚到底放大 12%，这层完全可控，和生成结果无关。
3. **片子要能被 seek，最稳的办法是先用 fetch 取成 Blob，再交给 `<video>`。** 浏览器只有在服务器返回 `Accept-Ranges: bytes` / 206 时才认这个文件可拖；很多静态托管（本地预览服务、部分对象存储默认配置）不支持 Range，于是 `video.seekable` 变成 `[0,0]`，`currentTime` 赋值被静默忽略，画面永远停在第一帧，控制台一个字都不报，排查起来能耗掉半天。Blob URL 由浏览器自己托管，永远可 seek，代价只是把整段片子放进内存（几秒的片子不到 1MB）：

```js
fetch('assets/video/clip.mp4')
  .then(function (r) { return r.blob(); })
  .then(function (b) { video.src = URL.createObjectURL(b); video.load(); })
  .catch(function () { video.src = 'assets/video/clip.mp4'; });   // 取不到就退回直连
```

交付前在控制台读一次 `video.seekable`，是 `[0,0]` 就说明这一步没做对。
4. **必须有 poster。** 视频没加载完、脚本没跑、减弱动效三种情况下，看到的就是这张图。

**失败样子**

- `autoplay loop muted`：变成背景墙纸，和滚动没关系，用户不会觉得酷，只会觉得吵。
- 没做 Range 支持还以为是代码问题：这是排查起来最费时间的一种，因为一点报错都没有。
- 视频里带音轨：多几百 KB，还得记得静音，不如直接 `-an`。
- 片子太亮：白字浮在浅灰上，怎么调字重都救不了，只能压亮度或者加底部渐变。

---

## 把事件排成一页

一个可复用的骨架，按这个顺序搭，任何行业都能套：

| 段落 | 事件 | 承担什么 |
|---|---|---|
| 01 首屏 | 事件 00 入场编排 + 满屏出血 + 压底巨字 | 定调，第一印象，两层一起上 |
| 02 推移带 | 滚动推移带 | 过渡，把节奏带起来 |
| 03 数据 | 账本式数据墙 | 可信度 |
| 04 过程 | 序列帧推进 | 把「怎么做出来的」讲成一段，最容易出彩的一段 |
| 05 主体 | 钉住图文 + 镜头推移 | 信息密度最高的一段 |
| 06 停顿 | 整屏段落 + 反向位移 | 视觉呼吸 |
| 07 明细 | 常规排版（表格 / 列表） | 承接信息，主动降噪 |
| 08 情绪 | 视频时间轴 | 全页最强的一屏，滚动拖播放头 |
| 09 收尾 | 明暗反转 + 巨字落款 | 收束 |

这九段不必全用，一页挑 2 到 4 个事件即可。但**顺序不能乱**：过程和情绪这两段前后必须各接一个浅色章节，连着放三段暗色画面，节奏会塌。

**验收**：段落之间必须有明暗变化（浅 → 深 → 浅 → 深），不能连续三段同色。每段只出现一种事件（首屏是唯一允许叠两层的段落，因为加载入场属于另一个时间轴）。

## 抄之前先量一遍

不要直接套用上面的 px。每个页面开做前先确认三件事：

1. 视口宽（1440 / 1280 / 390）下，巨字实际渲染宽度是否落在内容宽度的 90–110%；
2. 首屏 `padding-bottom` 是否够放下巨字，底部信息条与巨字有没有重叠（用 `getBoundingClientRect` 量，不要靠肉眼）；
3. 首屏高度是否 ≤ 视口，超出的部分会把签名画面挤到折线以下。

这三件都是几何问题，量一次比改十次快。
