#!/usr/bin/env python3
"""按场景生成项目级 DESIGN.md。

只用标准库。示例：
  python3 new_design.py --list
  python3 new_design.py --scenario saas-landing --project "我的产品" --out ./DESIGN.md
  python3 new_design.py --scenario portfolio --vibe quiet --out ./DESIGN.md --force
"""

import argparse
import datetime
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PRESETS = os.path.join(ROOT, "assets", "presets.json")
TEMPLATE = os.path.join(ROOT, "assets", "DESIGN.md.template")


def load():
    with open(PRESETS, encoding="utf-8") as f:
        presets = json.load(f)
    with open(TEMPLATE, encoding="utf-8") as f:
        template = f.read()
    return presets, template


def bullets(items):
    return "\n".join("- " + str(x) for x in items)


def render(presets, template, scenario_key, project, vibe, out):
    scenarios = presets["scenarios"]
    if scenario_key not in scenarios:
        keys = ", ".join(sorted(scenarios))
        raise SystemExit("未知场景 %r。可用场景：%s" % (scenario_key, keys))

    s = scenarios[scenario_key]
    dose = vibe or s["motion_dose"]
    if dose not in presets["motion_doses"]:
        raise SystemExit("未知动效剂量 %r。可用：%s" % (dose, ", ".join(presets["motion_doses"])))

    # 手动覆盖剂量时，签名时刻说明要跟着换，避免出现「剂量允许签名时刻」却写「不设」的矛盾。
    if vibe and vibe != s["motion_dose"]:
        signature = {
            "quiet": "不设签名时刻，只保留 hover、focus、导航和展开收起。",
            "balanced": "可选一处首屏主视觉揭示作为全页唯一签名时刻，需有静态兜底。",
            "expressive": "设一处高强度签名时刻，全页仅此一处，需有静态兜底并在移动端量过首屏。",
        }[dose]
    else:
        signature = s["signature"]

    values = {
        "PROJECT": project,
        "SCENARIO_KEY": scenario_key,
        "SCENARIO_NAME": s["name"],
        "GOAL": s["goal"],
        "CONTAINER": s["container"],
        "TEXT_MEASURE": s["text_measure"],
        "SECTION_GAP": s["section_gap"],
        "TYPE_SHIFT": s["type_shift"],
        "MOTION_DOSE": dose,
        "MOTION_DOSE_DESC": presets["motion_doses"][dose],
        "SIGNATURE": signature,
        "SECTION_LIST": bullets(s["sections"]),
        "AVOID_LIST": bullets(s["avoid"]),
        "REFERENCE": s["reference"],
        "DATE": datetime.date.today().isoformat(),
    }

    text = template
    for key, value in values.items():
        text = text.replace("{{%s}}" % key, str(value))

    if "{{" in text:
        missing = sorted(set(re.findall(r"\{\{(\w+)\}\}", text)))
        raise SystemExit("模板存在未替换占位符：%s" % ", ".join(missing))

    parent = os.path.dirname(os.path.abspath(out))
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write(text)

    dose_desc = presets["motion_doses"][dose]
    print("已生成：%s" % os.path.abspath(out))
    print("场景：%s（%s）" % (s["name"], scenario_key))
    print("目标：%s" % s["goal"])
    print("动效剂量：%s — %s" % (dose, dose_desc))
    print("签名时刻：%s" % signature)
    print("下一步：复制 assets/tokens.css 进项目并在入口样式引入，随后实现页面并运行 audit.py。")


def main():
    p = argparse.ArgumentParser(description="生成项目级 DESIGN.md")
    p.add_argument("--scenario", help="场景键名，见 --list")
    p.add_argument("--project", default="未命名项目", help="项目名，写进 DESIGN.md 标题")
    p.add_argument("--vibe", choices=["quiet", "balanced", "expressive"],
                   help="覆盖场景默认动效剂量")
    p.add_argument("--out", default="DESIGN.md", help="输出路径，默认当前目录 DESIGN.md")
    p.add_argument("--force", action="store_true", help="允许覆盖已存在的文件")
    p.add_argument("--list", action="store_true", help="列出全部场景后退出")
    args = p.parse_args()

    presets, template = load()

    if args.list:
        print("可用场景（%d 类）：" % len(presets["scenarios"]))
        for key, s in presets["scenarios"].items():
            print("  %-20s %-24s %s" % (key, s["name"], s["motion_dose"]))
        print("\n动效剂量：")
        for key, desc in presets["motion_doses"].items():
            print("  %-12s %s" % (key, desc))
        return

    if not args.scenario:
        p.error("需要 --scenario，或先用 --list 查看全部场景")

    if os.path.exists(args.out) and not args.force:
        raise SystemExit("目标已存在：%s。确认覆盖请加 --force" % args.out)

    render(presets, template, args.scenario, args.project, args.vibe, args.out)


if __name__ == "__main__":
    main()
