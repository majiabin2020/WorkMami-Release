#!/usr/bin/env python3
"""AI 味体检：扫描生成页面，输出可执行的删改报告。

只用标准库。示例：
  python3 audit.py ./my-site
  python3 audit.py ./my-site --scenario pricing
  python3 audit.py ./my-site --json
  python3 audit.py ./my-site --strict

退出码：有 FAIL 时返回 1；--strict 时 WARN 也会返回 1；全部通过返回 0。
"""

import argparse
import json
import os
import re
import sys

EXTS = {".html", ".htm", ".css", ".scss", ".sass", ".less",
        ".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte", ".astro"}
JSON_NAMES = {"package.json", "components.json"}
SKIP_DIRS = {"node_modules", ".git", ".next", ".nuxt", "dist", "build",
             "out", "vendor", "coverage", ".cache", "__pycache__", ".venv"}
MAX_BYTES = 2_000_000

ALLOW_THREE_COLS = {"pricing", "docs", "dashboard"}

PURPLE = re.compile(
    r"(?i)(indigo|violet|purple|rebeccapurple|#6366f1|#818cf8|#8b5cf6|#a855f7|"
    r"#c084fc|#7c3aed|#ec4899|#f472b6|#d946ef)")
GRADIENT = re.compile(r"(?i)(linear|radial|conic)-gradient\s*\(")
GLASS = re.compile(r"(?i)backdrop-filter\s*:")
SHADOW_DECL = re.compile(r"(?i)(?:box-shadow|text-shadow)\s*:([^;]+)")
SHADOW = re.compile(r"(?i)box-shadow\s*:")
RADIUS = re.compile(r"(?i)border-radius\s*:\s*([\d.]+)px")
BIG_RADIUS_CLASS = re.compile(r"(?i)rounded-(?:3xl|full)\b|rounded-\[[\d.]+rem\]")
EMOJI = re.compile("[\U0001F300-\U0001FAFF\U00002600-\U000027BF\u2728\u2b50]")
INFINITE = re.compile(r"(?i)\binfinite\b|\banimation-iteration-count\s*:\s*(?!1\b)\d+")
TRANSITION_ALL = re.compile(r"(?i)transition(?:-property)?\s*:\s*all\b")
TRANSITION_PROP = re.compile(
    r"(?i)transition(?:-property)?\s*:[^;]*\b(width|height|top|left|right|bottom|"
    r"background|margin|padding|font-size|border-color)\b")
ANIM_LONG = re.compile(r"(?i)animation-duration\s*:\s*([\d.]+)s\b|\bduration\s*:\s*([\d.]+)\s*[,}]")
CENTER = re.compile(r"(?i)text-align\s*:\s*center\b|\btext-center\b")
THREE_COLS = re.compile(r"(?i)repeat\(\s*3\s*,\s*1fr\s*\)|grid-cols-3\b|"
                        r"grid-template-columns\s*:\s*1fr\s+1fr\s+1fr")
BENTO = re.compile(r"(?i)\bbento\b")
FAKE_COPY = re.compile(
    r"(?i)lorem ipsum|unlock the power|supercharge your|effortless|seamless|"
    r"赋能|一站式|极致体验|开启新篇章|重新定义|深度融合|让[^，。]{1,8}更简单")
SOCIAL_PROOF = re.compile(
    r"(?i)trusted by|our clients|as seen on|10,000\+|99\.9%|award-winning|"
    r"fake-logo|客户 logo|合作伙伴")
IMPORTANT = re.compile(r"!important")
REDUCED_RESET = re.compile(
    r"(?i)(animation-duration|animation-iteration-count|transition-duration|scroll-behavior|animation\s*:)")
FONT_FAMILY = re.compile(r"(?i)font-family\s*:\s*([^;]+)")
FONT_SIZE = re.compile(r"(?i)font-size\s*:\s*([\d.]+)px")
HEX = re.compile(r"(?i)#[0-9a-f]{6}\b|#[0-9a-f]{3}\b")
INLINE_STYLE = re.compile(r"(?i)\sstyle\s*=")
IMG = re.compile(r"(?i)<img\b")
PLACEHOLDER_IMG = re.compile(r"(?i)placehold\.|picsum|via\.placeholder|dummyimage")
VIEWPORT = re.compile(r"(?i)<meta[^>]+name\s*=\s*[\"']viewport[\"']")
WEBGL = re.compile(r"(?i)@react-three|from\s+['\"]three|require\(['\"]three|"
                   r"\bOGL\b|postprocessing|WebGLRenderer|ShaderMaterial")
# 只在 import / require / package.json 依赖里认动画运行时，避免把 --motion-* 变量名
# 和 prefers-reduced-motion 里的 "motion" 误判成装了 Motion。
IMPORT_LIB = re.compile(
    r"(?i)(?:from\s*|require\(\s*|import\s*)['\"](gsap|framer-motion|motion|"
    r"motion/react|motion-v|animejs|@motionone/motion|@vueuse/motion)(?:['\"/])")
RUNTIME_MAP = {
    "gsap": "gsap", "framer-motion": "framer-motion", "motion": "motion",
    "motion/react": "motion", "motion-v": "motion", "animejs": "animejs",
    "@motionone/motion": "motionone", "@vueuse/motion": "vueuse-motion",
}


def runtimes_from(path, text):
    found = set()
    if os.path.basename(path) == "package.json":
        try:
            data = json.loads(text)
        except (ValueError, TypeError):
            data = {}
        for section in ("dependencies", "devDependencies", "peerDependencies"):
            for key in data.get(section, {}) or {}:
                k = key.lower()
                if k in RUNTIME_MAP:
                    found.add(RUNTIME_MAP[k])
    else:
        for m in IMPORT_LIB.finditer(text):
            name = m.group(1).lower()
            found.add(RUNTIME_MAP.get(name, name))
    return found
REDUCED_MOTION = re.compile(r"(?i)prefers-reduced-motion|useReducedMotion")
ANIM_PRESENT = re.compile(r"(?i)\banimation\s*:|\btransition\s*:|@keyframes|"
                          r"\bmotion\.|animate\(|useAnimate|ScrollTrigger")

FIX = {
    "AI_PALETTE": "换成 DESIGN.md 里那一个低饱和 Accent，或直接用中性色。",
    "GRADIENT_SPAM": "首版尽量不用渐变；确需保留只留一处，且不做背景大面积铺色。",
    "GLASS": "删掉毛玻璃，靠留白和 1px 描边分组。",
    "GLOW": "删掉发光；阴影最多一层，blur ≤ 24px、透明度 ≤ 0.08，只给浮层。",
    "SHADOW_SPAM": "静态卡片不加阴影，只给弹窗、下拉、吸顶导航。",
    "BIG_RADIUS": "圆角退回 0 / 4 / 8px 三档，特殊容器最多 12px。",
    "BIG_RADIUS_CLASS": "换掉 rounded-3xl / rounded-full 这类大圆角类名。",
    "EMOJI": "删掉装饰性 emoji，层级靠字号和间距。",
    "INFINITE": "改成有触发条件的一次性动效，零无限循环。",
    "TRANSITION_ALL": "改成只过渡 opacity 与 transform。",
    "TRANSITION_PROP": "改过渡属性为 opacity / transform，别动布局属性。",
    "ANIM_LONG": "压到 500ms 以内；超过必须写出功能理由并写进 DESIGN.md。",
    "CENTER_ALL": "正文、列表、说明文字左对齐到同一条基线，居中只留给短标题。",
    "THREE_COLS": "改成宽窄混排（5:7 分栏或窄文配宽图），别用三列等宽卡片。",
    "BENTO": "先想清信息顺序，别用 Bento 网格掩盖结构没想好。",
    "FAKE_COPY": "改成真人会写的完整句子，删掉模板文案和空词。",
    "SOCIAL_PROOF": "确认数据真实；没有真实数据就整段删掉，不要放占位 Logo。",
    "IMPORTANT": "靠选择器优先级解决，不要靠 !important 硬压。",
    "TOO_MANY_FONTS": "字体家族收到两套以内，Mono 用系统等宽。",
    "UNSTABLE_TYPE": "统一到 DESIGN.md 那九级字阶，别逐个元素临时调字号。",
    "TOO_MANY_COLORS": "颜色角色收回五个，语义色不参与装饰。",
    "INLINE_STYLE": "把行内样式收进 tokens.css 或组件类里。",
    "IMG_ALT": "给图片补上有意义的 alt 描述。",
    "PLACEHOLDER_IMG": "换成真实图片，没有就用一个纯色块或留白。",
    "NO_VIEWPORT": "补上 viewport meta，并在 390px 宽度下复查。",
    "WEBGL_FALLBACK": "确认有 WebGL 上下文失败时的静态画面，并在移动端量一次首屏。",
    "NO_REDUCED_MOTION": "补上 prefers-reduced-motion 分支，减弱动效时直接呈现内容。",
    "MULTI_RUNTIME": "整站只保留一个动画运行时，动效只认一家来源。",
}


def collect(path):
    if os.path.isfile(path):
        return [path]
    files = []
    for base, dirs, names in os.walk(path):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        for name in names:
            ext = os.path.splitext(name)[1].lower()
            if ext in EXTS or (ext == ".json" and name in JSON_NAMES):
                if "min." in name or ".min." in name:
                    continue
                full = os.path.join(base, name)
                try:
                    if os.path.getsize(full) <= MAX_BYTES:
                        files.append(full)
                except OSError:
                    pass
    return sorted(files)


def clean_lines(text):
    """去掉注释内容，保留行号。"""
    out = []
    in_block = False
    for line in text.splitlines():
        s = line
        if in_block:
            end = s.find("*/")
            if end < 0:
                out.append("")
                continue
            s = s[end + 2:]
            in_block = False
        if "/*" in s:
            start = s.find("/*")
            end = s.find("*/", start + 2)
            if end < 0:
                out.append(s[:start])
                in_block = True
                continue
            s = s[:start] + s[end + 2:]
        s = re.sub(r"<!--.*?-->", "", s)
        s = re.sub(r"^\s*//.*$", "", s)
        out.append(s)
    return out


def add(findings, sev, code, path, line, snippet, extra=""):
    findings.append({
        "severity": sev, "code": code, "file": path, "line": line,
        "snippet": snippet.strip()[:120], "message": extra,
        "fix": FIX.get(code, "按 DESIGN.md 对应条目修正。"),
    })


def scan(path, scenario):
    findings = []
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            text = f.read()
    except OSError:
        return findings, {"has_anim": False, "has_reduced": False, "runtimes": set()}
    lines = clean_lines(text)
    whole = "\n".join(lines)
    rel = path
    is_html = path.lower().endswith((".html", ".htm"))

    counters = {"gradient": 0, "shadow": 0, "center": 0, "inline": 0}
    fonts, sizes, colors = set(), set(), set()

    for i, line in enumerate(lines, 1):
        if not line.strip():
            continue

        if PURPLE.search(line):
            add(findings, "FAIL", "AI_PALETTE", rel, i, line,
                "出现蓝紫 / 粉紫 AI 渐变色系的色值或关键字。")
        counters["gradient"] += len(GRADIENT.findall(line))
        if GLASS.search(line):
            add(findings, "FAIL", "GLASS", rel, i, line, "出现玻璃拟态 backdrop-filter。")
        for m in SHADOW_DECL.finditer(line):
            decl = m.group(1)
            px = [int(x) for x in re.findall(r"(\d+)px", decl)]
            if re.search(r"(?i)\b0\s+0\s+\d+px\b", decl) or (px and max(px) > 40):
                add(findings, "FAIL", "GLOW", rel, i, line,
                    "出现零偏移发光或扩散超过 40px 的阴影。")
        counters["shadow"] += len(SHADOW.findall(line))
        for m in RADIUS.finditer(line):
            try:
                if float(m.group(1)) > 16:
                    add(findings, "FAIL", "BIG_RADIUS", rel, i, line,
                        "圆角 %spx 超过 16px 上限。" % m.group(1))
            except ValueError:
                pass
        if BIG_RADIUS_CLASS.search(line):
            add(findings, "WARN", "BIG_RADIUS_CLASS", rel, i, line, "出现大圆角工具类。")
        if EMOJI.search(line):
            add(findings, "FAIL", "EMOJI", rel, i, line, "出现装饰性 emoji。")
        if INFINITE.search(line):
            add(findings, "FAIL", "INFINITE", rel, i, line, "出现无限循环动画。")
        if TRANSITION_ALL.search(line):
            add(findings, "FAIL", "TRANSITION_ALL", rel, i, line, "使用了 transition: all。")
        elif TRANSITION_PROP.search(line):
            add(findings, "WARN", "TRANSITION_PROP", rel, i, line,
                "过渡作用在布局属性上：%s。" % TRANSITION_PROP.search(line).group(1))
        for m in ANIM_LONG.finditer(line):
            val = m.group(1) or m.group(2)
            try:
                if float(val) > 0.5:
                    add(findings, "WARN", "ANIM_LONG", rel, i, line,
                        "单次动效 %ss 超过 500ms。" % val)
            except (ValueError, TypeError):
                pass
        counters["center"] += len(CENTER.findall(line))
        if scenario not in ALLOW_THREE_COLS and THREE_COLS.search(line):
            add(findings, "WARN", "THREE_COLS", rel, i, line, "出现三列等宽骨架。")
        if BENTO.search(line):
            add(findings, "WARN", "BENTO", rel, i, line, "出现 Bento 网格。")
        if FAKE_COPY.search(line):
            add(findings, "FAIL", "FAKE_COPY", rel, i, line,
                "出现模板文案或空词：%s。" % FAKE_COPY.search(line).group(0))
        if SOCIAL_PROOF.search(line):
            add(findings, "WARN", "SOCIAL_PROOF", rel, i, line,
                "出现社会证明：%s。" % SOCIAL_PROOF.search(line).group(0))
        if IMPORTANT.search(line) and not REDUCED_RESET.search(line):
            add(findings, "WARN", "IMPORTANT", rel, i, line, "出现 !important。")
        for m in FONT_FAMILY.finditer(line):
            fonts.add(m.group(1).strip()[:60])
        for m in FONT_SIZE.finditer(line):
            sizes.add(m.group(1))
        for m in HEX.finditer(line):
            colors.add(m.group(0).lower())
        counters["inline"] += len(INLINE_STYLE.findall(line))
        if IMG.search(line) and not re.search(r"(?i)\balt\s*=", line):
            add(findings, "WARN", "IMG_ALT", rel, i, line, "img 缺少 alt。")
        if PLACEHOLDER_IMG.search(line):
            add(findings, "WARN", "PLACEHOLDER_IMG", rel, i, line, "出现占位图服务。")
        if WEBGL.search(line):
            has_fallback = bool(REDUCED_MOTION.search(whole)) or bool(
                re.search(r"(?i)fallback|静态|noscript|catch\s*\(", whole))
            add(findings, "WARN" if has_fallback else "FAIL", "WEBGL_FALLBACK", rel, i, line,
                "出现 WebGL / shader 实现，需确认静态兜底与移动端首屏。" if has_fallback
                else "出现 WebGL / shader 实现但没找到静态兜底。")

    if is_html and not VIEWPORT.search(whole):
        add(findings, "FAIL", "NO_VIEWPORT", rel, 1, "<html>", "缺少 viewport meta，手机端会缩放异常。")

    if counters["gradient"] > 2:
        add(findings, "WARN", "GRADIENT_SPAM", rel, 0, "gradients=%d" % counters["gradient"],
            "单文件出现 %d 处渐变。" % counters["gradient"])
    if counters["shadow"] > 3:
        add(findings, "WARN", "SHADOW_SPAM", rel, 0, "box-shadow=%d" % counters["shadow"],
            "单文件出现 %d 处阴影。" % counters["shadow"])
    if counters["center"] >= 3:
        add(findings, "WARN", "CENTER_ALL", rel, 0, "text-align:center=%d" % counters["center"],
            "单文件出现 %d 处居中对齐。" % counters["center"])
    if counters["inline"] > 8:
        add(findings, "WARN", "INLINE_STYLE", rel, 0, "style= =%d" % counters["inline"],
            "单文件出现 %d 处行内样式。" % counters["inline"])
    if len(fonts) > 3:
        add(findings, "WARN", "TOO_MANY_FONTS", rel, 0, ", ".join(sorted(fonts)[:4]),
            "出现 %d 套 font-family 声明。" % len(fonts))
    if len(sizes) > 10:
        add(findings, "WARN", "UNSTABLE_TYPE", rel, 0, ", ".join(sorted(sizes)[:12]),
            "出现 %d 种字号，字阶不稳定。" % len(sizes))
    if len(colors) > 12:
        add(findings, "WARN", "TOO_MANY_COLORS", rel, 0, ", ".join(sorted(colors)[:12]),
            "出现 %d 个具名颜色，超过颜色角色上限。" % len(colors))

    return findings, {"has_anim": bool(ANIM_PRESENT.search(whole)),
                      "has_reduced": bool(REDUCED_MOTION.search(whole)),
                      "runtimes": runtimes_from(path, text)}


def main():
    p = argparse.ArgumentParser(description="AI 味体检")
    p.add_argument("path", help="项目目录，或单个页面文件")
    p.add_argument("--scenario", help="场景键名，用于放宽定价页 / 文档站的三列骨架")
    p.add_argument("--json", action="store_true", help="输出 JSON")
    p.add_argument("--strict", action="store_true", help="WARN 也计入失败")
    args = p.parse_args()

    if not os.path.exists(args.path):
        raise SystemExit("路径不存在：%s" % args.path)

    files = collect(args.path)
    if not files:
        raise SystemExit("没有找到可检查的页面文件（支持 html/css/js/jsx/ts/tsx/vue/svelte/astro/package.json）。")

    all_findings, meta_all, meta_anim = [], set(), False
    for path in files:
        fs, meta = scan(path, args.scenario)
        all_findings.extend(fs)
        meta_all |= meta["runtimes"]
        meta_anim = meta_anim or meta["has_anim"]
        if meta["has_reduced"]:
            meta_all.add("__has_reduced__")

    if meta_anim and "__has_reduced__" not in meta_all:
        all_findings.append({
            "severity": "FAIL", "code": "NO_REDUCED_MOTION", "file": args.path, "line": 0,
            "snippet": "", "message": "项目里有动画或过渡，但没有任何减弱动效处理。",
            "fix": FIX["NO_REDUCED_MOTION"],
        })
    if len(meta_all - {"__has_reduced__"}) > 1:
        libs = ", ".join(sorted(meta_all - {"__has_reduced__"}))
        all_findings.append({
            "severity": "FAIL", "code": "MULTI_RUNTIME", "file": args.path, "line": 0,
            "snippet": libs, "message": "检测到多个动画运行时：%s。" % libs,
            "fix": FIX["MULTI_RUNTIME"],
        })

    order = {"FAIL": 0, "WARN": 1}
    all_findings.sort(key=lambda x: (order[x["severity"]], x["file"], x["line"], x["code"]))
    fails = [f for f in all_findings if f["severity"] == "FAIL"]
    warns = [f for f in all_findings if f["severity"] == "WARN"]

    if args.json:
        print(json.dumps({
            "path": os.path.abspath(args.path), "files": len(files),
            "scenario": args.scenario, "fail": len(fails), "warn": len(warns),
            "pass": not fails and (not args.strict or not warns),
            "findings": all_findings,
        }, ensure_ascii=False, indent=2))
    else:
        print("AI 味体检 · %s" % os.path.abspath(args.path))
        print("扫描 %d 个文件 · FAIL %d · WARN %d" % (len(files), len(fails), len(warns)))
        print("=" * 66)
        if not all_findings:
            print("全部通过，没有发现 AI 味痕迹。")
        for f in all_findings:
            loc = ("%s:%d" % (f["file"], f["line"])) if f["line"] else f["file"]
            print("[%s] %-20s %s" % (f["severity"], f["code"], loc))
            print("    问题：%s" % f["message"])
            if f["snippet"]:
                print("    位置：%s" % f["snippet"])
            print("    改法：%s" % f["fix"])
        print("=" * 66)
        if fails:
            print("还有 %d 项必须改。优先删装饰，不要用更多特效去盖；改完复跑一次。" % len(fails))
        elif warns and args.strict:
            print("FAIL 已清零，但 strict 模式下 %d 项 WARN 也要处理。" % len(warns))
        elif warns:
            print("FAIL 已清零。%d 项 WARN 逐条判断，保留的话在交付说明里写清理由。" % len(warns))
        else:
            print("可以交付。")

    if fails or (args.strict and warns):
        sys.exit(1)


if __name__ == "__main__":
    main()
