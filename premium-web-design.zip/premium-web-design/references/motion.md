# 动效规范：把「酷炫」变成可控参数

## 一、核心规则：只认一家动效语言

从组件库里挑一家，把它的默认时长、缓动、交错间隔、触发条件抄成 token，之后整站只认这一套，最多为一个真正希望用户记住的效果破一次例。从六个库各装一个效果，页面会出现六套缓动、六种时长，有时还带两个动画运行时，看起来像拼装的而不是设计过的。

先抽参数和节奏，再从 registry 装源码。顺序反了就会变成「看到什么效果都想加一个」。

## 二、动效基准（公开设计系统数值）

```
--motion-duration-micro:      120ms;  /* hover、focus、toggle、按钮按压 */
--motion-duration-component: 240ms;  /* 弹窗、抽屉、下拉展开 */
--motion-duration-page:      400ms;  /* 整页切换，只在有语义时用 */
--motion-ease-standard: cubic-bezier(0.2, 0, 0, 1);
--motion-ease-enter:    cubic-bezier(0.05, 0.7, 0.1, 1);
--motion-ease-exit:     cubic-bezier(0.3, 0, 1, 1);
--motion-stagger:       40ms;        /* 列表逐项出现 */
--motion-exit-ratio:    0.65;        /* 出场时长约为入场的 65% */
```

依据：Material 3 标准曲线 `cubic-bezier(0.2, 0, 0, 1)`、强调减速 `(0.05, 0.7, 0.1, 1)`、加速 `(0.3, 0, 1, 1)`；IBM Carbon productive `(0.2, 0, 0.38, 0.9)`、expressive `(0.4, 0.14, 0.3, 1)`；Apple HIG 落在相近区间。Emil Kowalski 的规则是 UI 动效不超过 300ms、入场用 ease-out、高频操作绝不动画、键盘触发的操作禁止动画。

## 三、允许动的地方

只在这些位置出现动效：状态变化、操作反馈、导航、展开收起、切换、内容揭示。纯装饰位置一律不动。

只动 `opacity` 与 `transform`，不要动 `width` / `height` / `top` / `left` / `background`，不写 `transition: all`。列表逐项出现用 40ms stagger，最多五到七项，超过就整组一次性出现。入场比出场长三到五成，出场用 exit 曲线。高频操作压在 150ms 内，超过 500ms 必须写出功能理由。零无限循环。

## 四、剂量分档

| 档位 | 适用 | 内容 |
|---|---|---|
| `quiet` | 企业官网、文档、后台、内容站 | 只有 hover / focus / 展开收起，无入场动画，无签名时刻 |
| `balanced` | SaaS 落地页、定价页、作品集、个人主页 | 三到五处有功能理由的动效，一处首屏主视觉揭示，一处滚动叙事，其余克制 |
| `expressive` | 活动页、发布页、品牌店、创意作品集 | 一个签名时刻 + 五到八处微交互，仍需单一来源、静态兜底、移动端首屏达标 |

剂量由 `scenarios.md` 与 `assets/presets.json` 决定，不由「这个效果很酷」决定。用户明确要求「酷炫」时升到 `expressive`，但禁令和体检标准不放宽。

## 五、签名时刻

全页唯一一处高强度效果，允许突破 `quiet` / `balanced` 的常规剂量。合格条件：和内容直接相关、能一句话说清为什么值得动、不干扰主要操作、有静态兜底、尊重减弱动效、移动端首屏不过载。

可选实现：一次滚动驱动的产品演示转场、一段文字遮罩显现、一个数据可视化揭示、首屏一层轻量 shader。避免整页滚动劫持、长时间锁屏动画、自动播放音效。

## 六、库选型与引擎

克制优先选 Magic UI（MIT）或 Motion Primitives（组合式原语，整套共享 timing/easing）；视觉冲击选 React Bits 或 Aceternity UI；Vue/Nuxt 选 Vue Bits 或 Inspira UI。详细对照、许可证和 registry 命令见 `component-libs.md`。

引擎依据：

| 工具 | 要点 |
|---|---|
| GSAP https://gsap.com/showcase/ | 3.13 起 ScrollTrigger、SplitText、ScrollSmoother 等原付费插件免费开放，商用条款不是常规 OSI 开源，以官网为准 |
| Motion https://motion.dev/ | React 用 `motion/react`，Vue 是独立的 `motion-v`；vanilla 最小包 `motion/mini` 约 2.3KB；Motion One 已冻结并入本项目，新项目别选 |
| Lenis https://lenis.dev/ | 惯性滚动标准件，旧 `@studio-freight` 包废弃；默认不自动尊重 `prefers-reduced-motion`，需主动不初始化或销毁 |
| Anime.js v4 https://animejs.com/ | MIT 约 6KB，ESM 按需导入，v3 代码不能直接用 |
| 原生 CSS https://transitions.dev/ | scroll-driven animations 在 Chromium 与 Safari 26 可用；同文档 View Transitions 已成 Baseline。很多滚动显现零 JS 就能做 |
| Paper Shaders https://shaders.paper.design/ | Apache-2.0 零依赖 Canvas shader，比拖整个 3D 引擎划算 |

## 七、性能与无障碍

- 必须写 `@media (prefers-reduced-motion: reduce)` 分支，把非必要动画关掉、把内容直接呈现。
- Lenis 一类惯性滚动在减弱动效模式下不初始化。
- WebGL / shader 先探测上下文，失败时显示准备好的静态画面；Three.js 自 r184 起 WebGLRenderer 进入维护模式，新项目规划 WebGPURenderer 并保留 WebGL2 回退。
- shader 和 3D 组件会拉进 `three`、`OGL`、`postprocessing`，先在 390px 移动端量一次首屏再决定留不留。
- 动画运行时全项目只保留一个，别同时装 GSAP、Motion、Anime.js。

## 八、许可提醒

React Bits、Vue Bits、Svelte Bits 是 MIT 加 Commons Clause：放进自己的网站或产品里商用没问题，但不能把组件本身打包转售、做成模板市场、建站器或对外分发的移植版，这类用途要买 React Bits Pro 商业授权。Paper Shaders 是 Apache-2.0。Aceternity UI 与 Cult UI 的区块模板部分付费。把源码交给模型前逐个核仓库里的 LICENSE。
