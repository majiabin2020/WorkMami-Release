#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""微信公众号 SVG 交互动画 · 配置驱动生成器

四层配置互相独立，换任意一层都不用改代码：
    theme.*.json          配色（8 套）
    presets/scene.*.json  题材场景（分屏骨架 + 推荐组合）
    presets/motion.*.json 动效（5 套）
    presets/layout.*.json 版式（3 套）
    content.*.json        内容（分屏文案，段数可增删）
    choreography.json     编排（节奏 / 触发模式 / 缓动 / 时长）

输出（写到 --out 所在目录）：
    <out>.html                 微信正文片段（微信净化形态，小写标签属性）
    静态兜底版.html            纯静态长图，动画被平台清空时仍可完整阅读
    预览.html                   本地模拟手机宽度的预览页
    导入助手.html               F12 注入 / Console 注入 / 自检工具
    注入代码.txt                Console 注入用的独立代码文件

兼容性硬约束（见 ../references/设计规范与兼容白名单.md）：
    · 绝不能靠「复制富文本 → Ctrl+V」导入：微信编辑器粘贴过滤器会剥离
      <animate> / <animatetransform>，SVG 变成静态图。必须走 DOM 注入。
    · 输出形态照抄原文线上被微信净化后的真实 DOM：标签名与属性名全部小写
      （animatetransform / attributename / repeatcount / calcmode / keytimes /
      keysplines / viewbox），浏览器解析 HTML 内的 SVG 时会自动修正回驼峰。
    · <tspan leaf=""> 必须带 leaf，否则文字可能被当叶子节点清洗。
    · 不用 <line>（微信会剥离其内动画），一律 <path> / <rect>。
    · 动画 attributeName 只用白名单：opacity / width / stroke-dashoffset；
      animateTransform 的 type 只用 translate / scale。
    · 无 script / 无 style 标签 / 无 id / 无 class / 无 defs / 无 CSS 动画。
"""
import argparse
import base64
import html
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def esc(v):
    return html.escape(str(v), quote=True)


def num(v):
    if isinstance(v, str):
        return v
    f = float(v)
    return str(int(f)) if f.is_integer() else str(round(f, 1))


def wrap_cn(s, per_line=17):
    """中文按字数折行，返回行数组；SVG <text> 不会自动换行。"""
    s = str(s).strip()
    if len(s) <= per_line:
        return [s]
    out, buf = [], ""
    for ch in s:
        buf += ch
        if len(buf) >= per_line:
            cut = -1
            for p in ("，", "。", "、", "；", " ", "：", ","):
                idx = buf.rfind(p)
                if idx >= per_line - 5:
                    cut = idx + 1
                    break
            if cut > 0:
                out.append(buf[:cut].strip())
                buf = buf[cut:]
            else:
                out.append(buf.strip())
                buf = ""
    if buf.strip():
        out.append(buf.strip())
    return out


class Layout:
    """版式策略：只管骨架（对齐 / 边距 / 行距 / 元信息 / 分隔线 / 分栏），不管内容。

    换 layout 预设就能改变全篇的排版性格，而不需要动任何场景方法。
    """

    def __init__(self, b, cfg):
        self.b = b
        self.cfg = cfg or {}
        self.M = int(self.cfg.get("margin", 96))
        self.R = 1080 - self.M
        self.density = float(self.cfg.get("density", 1.0))
        self.align = self.cfg.get("head_align", "left")
        self.meta = self.cfg.get("meta", "ruler")
        self.footer = self.cfg.get("footer", "ruler")
        self.divider_style = self.cfg.get("divider", "hairline")
        self.kicker_style = self.cfg.get("kicker", "label")
        self.accent_rule = int(self.cfg.get("accent_rule", 56))
        self.cols = [int(v) for v in self.cfg.get("columns", [96, 580])]
        self.cmid = [int(v) for v in self.cfg.get("center_columns", [310, 770])]

    def step(self, v):
        """逐行行距按密度缩放；密度区间 0.88-1.08 已做过越界实测。"""
        return v * self.density

    def col(self, i):
        return self.cols[min(i, len(self.cols) - 1)]

    def center(self, i):
        return self.cmid[min(i, len(self.cmid) - 1)]

    def divider(self, x1, y1, x2, y2):
        """表格行分隔线：none 时靠留白分组，strong 时做档案式实线。"""
        if self.divider_style == "none":
            return ""
        T = self.b.T
        if self.divider_style == "strong":
            return self.b.line(x1, y1, x2, y2, T["rule_strong"], T["rule_w_strong"])
        return self.b.line(x1, y1, x2, y2, T["rule"], T["rule_w"])

    def foot(self, y0, at):
        """段尾骨架：标尺 / 短强调线 / 完全留白。"""
        if self.footer == "none":
            return ""
        T = self.b.T
        if self.footer == "folio":
            return self.b.draw(f"M{self.M} {num(y0)}H{num(self.M + 56)}",
                               T["accent"], T["rule_w_accent"], at, 0.8)
        return self.b.ruler(y0, at)


class Builder:
    """视觉层 v3 · 三层可组合（风格 theme / 动效 motion / 版式 layout）

    与 v2 的机制完全相同：三层容器、分段撑高、click;Ns 双触发、静态兜底、
    微信净化形态。差别只在于入场路径与版式骨架现在由预设决定，不再写死。

    不传 motion / layout 时，行为与 v2.1 定稿逐字一致（用于回归比对）。
    """

    def __init__(self, theme, choreo, layout=None, motion=None, static=False):
        self.T = theme
        self.LAY = layout or {}
        self.MOT = motion or {}
        self.static = static

        # 编排层：choreo 作骨架，motion 覆盖节奏 / 缓动 / 默认参数。
        C = dict(choreo or {})
        if self.MOT:
            for k in ("easing", "defaults", "scene_span", "tail_loop_at", "tail_pad"):
                if k in self.MOT:
                    C[k] = self.MOT[k]
            if "expand_at" in self.MOT:
                C["expand_at"] = self.MOT["expand_at"]
            else:
                C.pop("expand_at", None)   # 交给 scene_span 自动逐屏补齐
        self.C = C
        self.mode = C.get("mode", "hybrid")
        self.sh = int(C.get("screen_height", 1920))
        self.D = dict((choreo or {}).get("defaults", {}))
        self.D.update(self.MOT.get("defaults", {}))

        self.L = Layout(self, self.LAY)
        self.M, self.R = self.L.M, self.L.R
        self.k = float(theme.get("type_scale", 1.18))

        self.n_anim = 0
        self.n_scene = 0
        self.n_total = 0

    # ---------- 基础 ----------
    def ease(self):
        e = self.C.get("easing", {})
        if not e.get("calcMode"):
            return ""
        s = f'calcMode="{e["calcMode"]}"'
        if e.get("keyTimes"):
            s += f' keyTimes="{e["keyTimes"]}"'
        if e.get("keySplines"):
            s += f' keySplines="{e["keySplines"]}"'
        return s

    def begin(self, at, clickable=False):
        at = round(float(at), 2)
        if clickable and self.mode == "hybrid":
            return f"click;{num(at)}s"
        return f"{num(at)}s"

    # ---------- 图元 ----------
    def font(self, kind):
        T = self.T
        return {"body": T["font"], "serif": T["serif"], "mono": T["mono"]}.get(kind, T["font"])

    def txt(self, x, y, s, size, color, anchor="middle", weight=400,
            font="body", tracking=0, opacity=None, extra=""):
        size = int(round(size * self.k))
        tracking = int(round(tracking * self.k))
        op = f' opacity="{opacity}"' if opacity is not None else ""
        ls = f' letter-spacing="{num(tracking)}"' if tracking else ""
        return (f'<text x="{num(x)}" y="{num(y)}" font-size="{num(size)}" '
                f'fill="{color}" font-family="{esc(self.font(font))}" '
                f'text-anchor="{anchor}" font-weight="{weight}"{ls}{op}{extra}>'
                f'<tspan x="{num(x)}" y="{num(y)}">{esc(s)}</tspan></text>')

    def rect(self, x, y, w, h, fill, rx=0, stroke=None, sw=1, opacity=None, extra=""):
        st = f' stroke="{stroke}" stroke-width="{num(sw)}"' if stroke else ""
        op = f' opacity="{opacity}"' if opacity is not None else ""
        r = f' rx="{num(rx)}"' if rx else ""
        return (f'<rect x="{num(x)}" y="{num(y)}" width="{num(w)}" height="{num(h)}"{r} '
                f'fill="{fill}"{st}{op}{extra}/>')

    def circle(self, cx, cy, r, fill, stroke=None, sw=1, opacity=None):
        st = f' stroke="{stroke}" stroke-width="{num(sw)}"' if stroke else ""
        op = f' opacity="{opacity}"' if opacity is not None else ""
        return f'<circle cx="{num(cx)}" cy="{num(cy)}" r="{num(r)}" fill="{fill}"{st}{op}/>'

    def line(self, x1, y1, x2, y2, stroke, sw=1, opacity=None, extra=""):
        """一律输出 <path>；端点用默认 butt，不用 round，避免圆润卡通感。"""
        op = f' opacity="{opacity}"' if opacity is not None else ""
        return (f'<path d="M{num(x1)} {num(y1)}L{num(x2)} {num(y2)}" fill="none" '
                f'stroke="{stroke}" stroke-width="{num(sw)}"{op}{extra}/>')

    # ---------- 动画原子 ----------
    def fade(self, inner, at, dur=None, frm=0, to=1, extra="", clickable=False):
        if self.static:
            return f'<g opacity="{to}"{extra}>{inner}</g>'
        d = dur if dur is not None else self.D.get("fade_dur", 0.9)
        b = self.begin(at, clickable)
        a = (f'<animate attributeName="opacity" values="{frm};{to}" begin="{b}" '
             f'dur="{num(d)}s" fill="freeze" restart="never" {self.ease()}/>')
        self.n_anim += 1
        return f'<g opacity="{frm}"{extra}>{inner}{a}</g>'

    def rise(self, inner, at, dy=None, dur=None):
        if self.static:
            return f'<g opacity="1">{inner}</g>'
        dy = self.D.get("rise_dy", 16) if dy is None else dy
        d = dur if dur is not None else self.D.get("rise_dur", 1.0)
        b = self.begin(at)
        a1 = (f'<animateTransform attributeName="transform" type="translate" '
              f'values="0 {num(dy)};0 0" begin="{b}" dur="{num(d)}s" '
              f'fill="freeze" restart="never" {self.ease()}/>')
        a2 = (f'<animate attributeName="opacity" values="0;1" begin="{b}" '
              f'dur="{num(d)}s" fill="freeze" restart="never" {self.ease()}/>')
        self.n_anim += 2
        return f'<g transform="translate(0 {num(dy)})" opacity="0">{inner}{a1}{a2}</g>'

    def drift(self, inner, at, dx=None, dur=None):
        """横向推入：page-turn 从左/右、cadence 反向，幅度都在 18-30px。"""
        if self.static:
            return f'<g opacity="1">{inner}</g>'
        dx = self.D.get("drift_dx", 24) if dx is None else dx
        d = dur if dur is not None else self.D.get("drift_dur", 1.0)
        b = self.begin(at)
        a1 = (f'<animateTransform attributeName="transform" type="translate" '
              f'values="{num(dx)} 0;0 0" begin="{b}" dur="{num(d)}s" '
              f'fill="freeze" restart="never" {self.ease()}/>')
        a2 = (f'<animate attributeName="opacity" values="0;1" begin="{b}" '
              f'dur="{num(d)}s" fill="freeze" restart="never" {self.ease()}/>')
        self.n_anim += 2
        return f'<g transform="translate({num(dx)} 0)" opacity="0">{inner}{a1}{a2}</g>'

    def cut(self, inner, at):
        """硬切显现：<set> 只驱动 visibility，是白名单里 <set> 唯一允许的属性。"""
        if self.static:
            return f'<g visibility="visible">{inner}</g>'
        b = self.begin(at)
        a = (f'<set attributeName="visibility" to="visible" begin="{b}" '
             f'fill="freeze" restart="never"/>')
        self.n_anim += 1
        return f'<g visibility="hidden">{inner}{a}</g>'

    def enter(self, inner, at, emphasis=False, dur=None):
        """场景级统一入口：具体路径由 motion 预设的 entry / emphasis 决定。

        组件内部（眼镜描边、标尺刻度、点击遮罩、打字机）仍直接调各自的原子，
        保证产品签名与交互结构在所有配方里保持一致。
        """
        if self.static:
            return f'<g opacity="1">{inner}</g>'
        e = self.MOT.get("emphasis", "rise") if emphasis else self.MOT.get("entry", "fade")
        if e == "cut":
            return self.cut(inner, at)
        if e == "drift":
            return self.drift(inner, at, dur=dur)
        if e == "rise":
            return self.rise(inner, at, dur=dur)
        return self.fade(inner, at, dur=dur)

    def draw(self, d, stroke, sw, at, dur=None, dash=100):
        """描边生长：只用于引出线、标尺主线与短强调线。"""
        if self.static:
            return (f'<path d="{d}" fill="none" stroke="{stroke}" '
                    f'stroke-width="{num(sw)}"/>')
        du = dur if dur is not None else self.D.get("draw_dur", 0.8)
        b = self.begin(at)
        a = (f'<animate attributeName="stroke-dashoffset" values="{dash};0" '
             f'begin="{b}" dur="{num(du)}s" fill="freeze" restart="never" {self.ease()}/>')
        self.n_anim += 1
        return (f'<path d="{d}" fill="none" stroke="{stroke}" stroke-width="{num(sw)}" '
                f'pathLength="{dash}" stroke-dasharray="{dash}" stroke-dashoffset="{dash}">'
                f'{a}</path>')

    def typewriter(self, s, x, y, size, color, at, cw=30, step=None, font="body"):
        cw = cw * self.k
        st = step if step is not None else self.D.get("type_step", 0.14)
        out = []
        for i, ch in enumerate(str(s)):
            one = self.txt(x + i * cw, y, ch, size, color, "middle", 400, font)
            if self.static:
                out.append(one)
                continue
            b = self.begin(round(at + i * st, 2))
            a = (f'<animate attributeName="opacity" values="0;1" begin="{b}" '
                 f'dur="0.2s" fill="freeze" restart="never"/>')
            self.n_anim += 1
            out.append(f'<g opacity="0">{one}{a}</g>')
        return "".join(out)

    def switch(self, before, after, at, show_at=None):
        """点击揭晓：底层答案 + 上层遮罩，两个 click 动画的宿主在同一祖先链上。"""
        show = at if show_at is None else show_at
        if self.static:
            return self.fade(after, show, 0.9)
        b = self.begin(at, True)
        if self.mode == "hybrid":
            b2 = f"click+0.5s;{num(round(at + 0.5, 2))}s"
        else:
            b2 = f"{num(round(at + 0.5, 2))}s"
        a1 = (f'<animate attributeName="opacity" values="1;0" begin="{b}" '
              f'dur="0.45s" fill="freeze" restart="never"/>')
        a2 = (f'<animateTransform attributeName="transform" type="translate" '
              f'values="0 0;3000 0" begin="{b2}" dur="0.01s" '
              f'fill="freeze" restart="never"/>')
        self.n_anim += 2
        cover = (f'<g opacity="1">{a1}'
                 f'<g transform="translate(0 0)">{a2}<g>{before}</g></g></g>')
        return self.fade(after, show, 0.9) + self.fade(cover, show, 0.9)

    # ---------- 版式骨架组件 ----------
    def ruler(self, y0, at, left="", right="", strong=False):
        """标尺母题：meta=ruler 画 13 刻度，grid 画满宽结构线，folio 只留细线。"""
        T = self.T
        M, R = self.M, self.R
        meta = self.L.meta
        color = T["rule_strong"] if (strong or meta == "grid") else T["rule"]
        sw = T["rule_w_strong"] if (strong or meta == "grid") else T["rule_w"]
        main = self.draw(f"M{M} {num(y0)}H{R}", color, sw, at, 1.0)
        ticks = []
        if meta == "ruler":
            for i in range(13):
                x = M + i * (R - M) / 12
                ln = 14 if i in (0, 6, 12) else 7
                ticks.append(f"M{num(x)} {num(y0)}V{num(y0 + ln)}")
        elif meta == "grid":
            for i in (0, 6, 12):
                x = M + i * (R - M) / 12
                ticks.append(f"M{num(x)} {num(y0)}V{num(y0 + 18)}")
        body = ""
        if ticks:
            body = (f'<path d="{" ".join(ticks)}" fill="none" stroke="{color}" '
                    f'stroke-width="{num(sw)}"/>')
        if left:
            body += self.txt(M, y0 - 22, self._clip(left, 22), 22,
                             T["ink_faint"], "start", 400,
                             "body", T["tracking_label"])
        if right:
            body += self.txt(R, y0 - 22, self._clip(right, 16), 22,
                             T["ink_faint"], "end", 400,
                             "mono", T["tracking_label"])
        return main + self.fade(body, at + 0.15, 0.9)

    def fit_size(self, s, base, max_w, tracking=0):
        """长标题按字宽等比收字号，避免左对齐时被 viewBox 右边界裁掉。"""
        n = len(str(s))
        if not n:
            return base
        k = self.k
        est = n * base * k + n * tracking * k
        if est <= max_w:
            return base
        return max(38, int(base * max_w / est))

    def section_no(self, n, y0=None, at=None):
        # 兼容两种调用：旧屏型写死传 (编号, y0, at)，新屏型只传 (y0, at)。
        # 屏号一律按内容里的真实顺序计算，增删任意一屏都不会出现写死编号。
        if at is None:
            n, y0, at = 0, n, y0
        n = getattr(self, "cur_idx", 0) + 1
        T = self.T
        M, R = self.M, self.R
        meta = self.L.meta
        if meta == "folio":
            body = (self.txt(M, y0 + 150, f"{n:02d}", 76, T["ink_faint"],
                             "start", 400, "serif")
                    + self.txt(R, y0 + 150, f"/ {self.n_total:02d}", 22,
                               T["ink_faint"], "end", 400, "mono", T["tracking_label"]))
            return self.enter(body, at)
        if meta == "grid":
            body = (self.txt(M, y0 + 130, f"SEC.{n:02d} / {self.n_total:02d}", 22,
                             T["ink_faint"], "start", 400, "mono", T["tracking_label"])
                    + self.line(M, y0 + 168, R, y0 + 168,
                                T["rule_strong"], T["rule_w_strong"]))
            return self.enter(body, at)
        s = f"{n:02d} / {self.n_total:02d}"
        return self.enter(self.txt(R, y0 + 130, s, 22, T["ink_faint"],
                                   "end", 400, "mono", T["tracking_label"]), at)

    def section_head(self, kicker, title, y0, at, align=None):
        T = self.T
        M = self.M
        align = align or self.L.align
        x = M if align == "left" else 540
        anchor = "start" if align == "left" else "middle"
        ks = self.L.kicker_style
        ktext = self._clip(str(kicker), 22)
        if ks == "plain":
            kt = self.txt(x, y0 + 240, ktext, 28, T["ink_dim"], anchor, 400, "serif")
        elif ks == "number":
            kt = self.txt(x, y0 + 240, "§ " + ktext, 22, T["ink_faint"],
                          anchor, 400, "mono", T["tracking_label"])
        else:
            kt = self.txt(x, y0 + 240, ktext, 24, T["accent"], anchor,
                          400, "body", T["tracking_kicker"])
        out = self.enter(kt, at)
        max_w = (self.R - self.M - 24) if align == "left" else 960
        ts = self.fit_size(title, 66, max_w, T["tracking_title"])
        out += self.enter(self.txt(x, y0 + 370, title, ts, T["ink"], anchor,
                                   400, "serif", T["tracking_title"]),
                          at + 0.2, emphasis=True)
        ar = self.L.accent_rule
        if ar > 0:
            sx = x if align == "left" else 512
            out += self.draw(f"M{num(sx)} {num(y0 + 425)}H{num(sx + ar)}",
                             T["accent"], T["rule_w_accent"], at + 0.6, 0.8)
        else:
            out += self.draw(f"M{M} {num(y0 + 425)}H{self.R}",
                             T["rule_strong"], T["rule_w_strong"], at + 0.6, 0.9)
        return out

    def glyph(self, kind, cx, cy, sc, at, label=""):
        """封面几何签名插画：任意题材通用，替代早期版本的产品专用眼镜线稿。

        设计约束与全篇一致：单一低饱和强调色、宋体之外的细线几何、无渐变、
        无光晕、无高饱和色块、无大位移、无无限循环。所有笔画用描边生长进入。
        kind 由内容 JSON 的 hero.glyph 指定，新增形状只需在这里加一个分支。
        可选值：orbit / lens / grid / bars / arc / wave / stack / compass / glasses
        """
        T = self.T
        acc, deep = T["accent"], T["accent_deep"]
        faint, rule = T["ink_dim"], T["rule_strong"]
        sw, thin = 3.0, 1.8
        g = []
        kind = (kind or "orbit").lower()

        def d(path, color=acc, width=sw, delay=0.0, dur=1.0):
            g.append(self.draw(path, color, width, at + delay, dur))

        def dot(x, y, r=6, color=acc, delay=0.0):
            g.append(self.fade(self.circle(x, y, r, color), at + delay, 0.7))

        def ring(r, color=acc, delay=0.0, width=sw):
            d(f"M{-r} 0 a{r} {r} 0 1 0 {2 * r} 0 a{r} {r} 0 1 0 {-2 * r} 0",
              color, width, delay, 1.3)

        if kind == "glasses":
            return self.glasses(cx, cy, sc, at)

        if kind == "orbit":
            ring(210)
            ring(146, deep, 0.18, thin)
            ring(74, faint, 0.34, thin)
            d("M-300 0H300", rule, thin, 0.5, 0.9)
            d("M0 -300V300", rule, thin, 0.6, 0.9)
            dot(210, 0, 8, acc, 0.9)
            dot(-146, 0, 5, deep, 1.0)
        elif kind == "lens":
            d("M-230 -150H230V150H-230Z", acc, sw, 0.05, 1.4)
            d("M0 -150V150", rule, thin, 0.4)
            d("M-230 0H230", rule, thin, 0.45)
            d("M-120 -80L120 80", deep, 2.0, 0.7)
            d("M120 -80L-120 80", deep, 2.0, 0.8)
            dot(0, 0, 10, acc, 1.1)
        elif kind == "grid":
            for i in (-1, 0, 1):
                d(f"M{i * 140} -210V210", rule, thin, 0.1 + (i + 1) * 0.08, 1.0)
                d(f"M-210 {i * 140}H210", rule, thin, 0.2 + (i + 1) * 0.08, 1.0)
            d("M0 -210H140V-70H0Z", acc, sw, 0.65, 1.0)
            dot(70, -140, 7, acc, 1.0)
        elif kind == "bars":
            d("M-300 170H300", rule, thin, 0.05, 1.0)
            for i, h in enumerate((90, 150, 210, 130, 250)):
                x = -250 + i * 125
                d(f"M{x} 170V{170 - h}", acc if i == 4 else deep,
                  3.0 if i == 4 else 2.2, 0.2 + i * 0.12, 0.8)
                dot(x, 170 - h, 5, acc if i == 4 else faint, 0.9 + i * 0.12)
        elif kind == "arc":
            for i, (r, col) in enumerate(((240, acc), (180, deep), (120, faint))):
                d(f"M{-r} 60 A{r} {r} 0 0 1 {r} 60", col,
                  3.0 - i * 0.5, 0.1 + i * 0.18, 1.3)
            d("M0 60L150 -150", acc, 2.6, 0.8, 0.9)
            dot(0, 60, 8, acc, 1.1)
            d("M-300 60H300", rule, thin, 0.9, 0.8)
        elif kind == "wave":
            d("M-300 0 C-180 -120 -60 120 60 0 S240 -120 300 0", acc, 3.0, 0.1, 1.4)
            d("M-300 90 C-180 -30 -60 210 60 90 S240 -30 300 90", deep, 2.0, 0.4, 1.4)
            d("M-300 -90 C-180 -210 -60 30 60 -90 S240 -210 300 -90", faint, 1.6, 0.6, 1.4)
            d("M-300 170H300", rule, thin, 0.8, 0.9)
            dot(60, 0, 7, acc, 1.1)
        elif kind == "stack":
            for i in range(4):
                x, y = -200 + i * 36, -140 + i * 44
                d(f"M{num(x)} {num(y)}H{num(x + 300)}V{num(y + 120)}H{num(x)}Z",
                  acc if i == 3 else rule, 3.0 if i == 3 else thin,
                  0.1 + i * 0.16, 1.0)
            dot(4 + 300, -140 + 3 * 44, 7, acc, 1.0)
        elif kind == "compass":
            ring(200)
            d("M-260 0H260", rule, thin, 0.3)
            d("M0 -260V260", rule, thin, 0.35)
            d("M-90 90L120 -150", acc, 3.0, 0.7, 0.9)
            dot(120, -150, 8, acc, 1.1)
            d("M-90 90L-160 160", deep, 2.0, 0.9, 0.8)
        else:  # 未知图形退回 orbit，保证内容永远不会因为打错字而生成空白封面
            ring(210)
            ring(146, deep, 0.18, thin)
            d("M-300 0H300", rule, thin, 0.5, 0.9)

        if label:
            d("M190 -110L270 -190H340", deep, 2.0, 1.2, 0.7)
            g.append(self.fade(
                self.txt(350, -182, self._clip(label, 8), 24, faint, "start", 400,
                         "body", T["tracking_label"]), at + 1.5, 0.8))
        return f'<g transform="translate({num(cx)} {num(cy)}) scale({num(sc)})">' + "".join(g) + "</g>"

    def glasses(self, cx, cy, sc, at):
        """单线几何眼镜：保留给老内容做兼容，新内容一律用上面的通用 glyph。"""
        T = self.T
        ink, acc, deep = T["accent"], T["accent"], T["accent"]
        faint, sw = T["ink_dim"], 3.4
        g = []
        left = ("M-202 -66 H-76 Q-42 -66 -42 -32 V32 Q-42 66 -76 66 "
                "H-202 Q-236 66 -236 32 V-32 Q-236 -66 -202 -66 Z")
        right = ("M76 -66 H202 Q236 -66 236 -32 V32 Q236 66 202 66 "
                 "H76 Q42 66 42 32 V-32 Q42 -66 76 -66 Z")
        g.append(self.draw(left, ink, sw, at + 0.1, 1.2))
        g.append(self.draw(right, ink, sw, at + 0.15, 1.2))
        g.append(self.draw("M-42 -26 Q0 -50 42 -26", ink, sw, at + 0.45, 0.6))
        g.append(self.draw("M-236 -38 L-322 -70 L-356 -46", ink, sw, at + 0.3, 0.8))
        g.append(self.draw("M236 -38 L322 -70 L356 -46", ink, sw, at + 0.3, 0.8))
        g.append(self.fade(self.circle(-210, -38, 5, acc) +
                           self.circle(-210, -38, 12, "none", acc, 1.5), at + 1.0, 0.7))
        g.append(self.fade(self.line(76, -22, 172, -22, acc, 1.5, 0.75) +
                           self.line(76, 6, 140, 6, acc, 1.5, 0.75), at + 1.1, 0.8))
        g.append(self.draw("M232 -20 L300 -104 H372", deep, 2.2, at + 1.3, 0.8))
        g.append(self.fade(self.txt(380, -96, "光波导显示", 26, faint, "start", 400,
                                    "body", T["tracking_label"]), at + 1.7, 0.8))
        g.append(self.draw("M-210 -38 L-300 -132 H-392", deep, 2.2, at + 1.4, 0.8))
        g.append(self.fade(self.txt(-400, -124, "摄像头", 26, faint, "end", 400,
                                    "body", T["tracking_label"]), at + 1.8, 0.8))
        g.append(self.draw("M180 66 L260 136 H300", deep, 2.2, at + 1.5, 0.8))
        g.append(self.fade(self.txt(308, 144, "本地 AI 芯片", 26, faint, "start", 400,
                                    "body", T["tracking_label"]), at + 1.9, 0.8))
        return f'<g transform="translate({num(cx)} {num(cy)}) scale({num(sc)})">' + "".join(g) + "</g>"

    # ---------- 场景模板 ----------
    def s_hero(self, c, y0, at):
        """通用封面：几何签名 + 主标题 + 副题 + 一组数据（数据可缺省）。"""
        T = self.T
        L = self.L
        idx = getattr(self, "cur_idx", 0) + 1
        s = [self.ruler(y0 + 140, at + 0.1, left=c.get("kicker", ""),
                        right=f"{idx:02d} / {self.n_total:02d}")]
        s.append(self.glyph(c.get("glyph", "orbit"), 540, y0 + 620, 0.92,
                            at + 0.5, c.get("glyph_label") or c.get("badge", "")))
        headline = c.get("headline") or c.get("title") or ""
        s.append(self.enter(self.txt(540, y0 + 1080, headline,
                                     self.fit_size(headline, 88, 960,
                                                   T["tracking_title"] + 4),
                                     T["ink"], "middle", 400, "serif",
                                     T["tracking_title"] + 4), at + 1.4, emphasis=True))
        s.append(self.draw(f"M512 {num(y0 + 1150)}H568", T["accent"],
                           T["rule_w_accent"], at + 1.8, 0.8))
        s.append(self.enter(self.txt(540, y0 + 1250, c.get("sub", ""), 32,
                                     T["ink_dim"]), at + 2.0))
        s.append(self.enter(self.txt(540, y0 + 1320, c.get("note", ""), 26,
                                     T["ink_faint"]), at + 2.2))
        st = self.D.get("stagger", 0.42)
        stats = [x for x in c.get("stats", []) if x][:3]
        for i, pair in enumerate(stats):
            v, lab = (list(pair) + [""])[:2]
            x = 540 + (i - (len(stats) - 1) / 2.0) * 360
            cell = (self.line(x - 80, y0 + 1500, x + 80, y0 + 1500,
                              T["rule_strong"], T["rule_w_strong"])
                    + self.txt(x, y0 + 1640, v, 60, T["ink"], "middle", 400, "serif")
                    + self.txt(x, y0 + 1710, self._clip(lab, 8), 26, T["ink_dim"]))
            s.append(self.enter(cell, at + 2.4 + i * st))
        s.append(L.foot(y0 + 1850, at + 3.0))
        return "".join(s)

    def s_bill(self, c, y0, at):
        T = self.T
        M, R, L = self.M, self.R, self.L
        s = [self.section_no(2, y0, at),
             self.section_head("先算一笔", c["title"], y0, at)]
        s.append(self.enter(self.txt(M, y0 + 540, "每天在做的事", 24, T["ink_faint"],
                                     "start", 400, "body", T["tracking_label"])
                            + self.txt(R, y0 + 540, "次数", 24, T["ink_faint"],
                                       "end", 400, "body", T["tracking_label"]), at + 0.7))
        s.append(self.draw(f"M{M} {num(y0 + 570)}H{R}", T["rule_strong"], 1.5, at + 0.8, 0.9))
        st = self.D.get("stagger", 0.42)
        for i, (lab, val) in enumerate(c["rows"]):
            yy = y0 + 660 + i * L.step(140)
            row = (self.txt(M, yy, lab, 34, T["ink"], "start", 400, "serif")
                   + self.txt(R, yy, val, 30, T["ink_dim"], "end", 400, "mono")
                   + L.divider(M, yy + 44, R, yy + 44))
            s.append(self.enter(row, at + 1.0 + i * st))
        s.append(self.draw(f"M{M} {num(y0 + 1400)}H{R}", T["rule_strong"], 1.5, at + 3.0, 0.9))
        s.append(self.enter(self.txt(M, y0 + 1480, c["total_label"], 26, T["ink_dim"],
                                     "start", 400, "body", T["tracking_label"]), at + 3.2))
        s.append(self.enter(self.txt(M, y0 + 1610, c["total_value"],
                                     self.fit_size(c["total_value"], 68,
                                                   self.R - self.M - 24, 2),
                                     T["ink"], "start", 400, "serif", 2),
                            at + 3.4, emphasis=True))
        s.append(self.enter(self.txt(M, y0 + 1700, c["foot"], 26, T["ink_faint"], "start"),
                            at + 3.8))
        s.append(L.foot(y0 + 1850, at + 4.1))
        return "".join(s)

    def s_reveal(self, c, y0, at):
        T = self.T
        M, L = self.M, self.L
        s = [self.section_no(3, y0, at)]
        s.append(self.enter(self.txt(540, y0 + 260, c["kicker"], 26, T["accent"],
                                     "middle", 400, "body", T["tracking_kicker"]), at))
        s.append(self.enter(self.txt(540, y0 + 780, c["big"], 172, T["ink"],
                                     "middle", 400, "serif"), at + 0.4, emphasis=True))
        s.append(self.draw(f"M512 {num(y0 + 850)}H568", T["accent"],
                           T["rule_w_accent"], at + 0.9, 0.8))
        s.append(self.enter(self.txt(540, y0 + 960, c["unit"], 36, T["ink_dim"]), at + 1.1))
        st = self.D.get("stagger", 0.42)
        for i, line in enumerate(c["lines"]):
            yy = y0 + 1160 + i * L.step(170)
            one = (self.line(M, yy - 34, M, yy + 10, T["accent"], 2.2)
                   + self.txt(M + 40, yy, line, 32, T["ink"], "start"))
            s.append(self.enter(one, at + 1.5 + i * st))
        s.append(self.enter(self.txt(540, y0 + 1700, c["note"], 26, T["ink_faint"]), at + 3.2))
        s.append(L.foot(y0 + 1850, at + 3.5))
        return "".join(s)

    def s_hardware(self, c, y0, at):
        T = self.T
        M, L = self.M, self.L
        s = [self.section_no(4, y0, at),
             self.section_head("两种办法", c["title"], y0, at)]
        s.append(self.draw(f"M540 {num(y0 + 520)}V{num(y0 + 1180)}",
                           T["rule_strong"], 1.5, at + 0.7, 1.0))
        st = self.D.get("stagger", 0.42)
        for i, card in enumerate(c["cards"]):
            x = L.col(i)
            hi = i == 0
            col = T["accent"] if hi else T["ink_dim"]
            body = (self.txt(x, y0 + 590, card["title"], 32, col, "start", 400, "serif")
                    + self.txt(x, y0 + 650, card["tag"], 22, T["ink_faint"], "start", 400,
                               "body", T["tracking_label"]))
            for j, sp in enumerate(card["specs"]):
                body += self.txt(x, y0 + 750 + j * L.step(120), sp, 28,
                                 T["ink"] if hi else T["ink_dim"], "start")
            s.append(self.enter(body, at + 0.9 + i * st))
        flow = c["flow"]
        for i, word in enumerate(flow):
            x = 180 + i * 360
            one = (self.txt(x, y0 + 1360, f"0{i + 1}", 22, T["ink_faint"],
                            "middle", 400, "mono", T["tracking_label"])
                   + self.txt(x, y0 + 1450, word, 34, T["ink"], "middle", 400, "serif", 2))
            s.append(self.enter(one, at + 2.0 + i * st))
        s.append(L.foot(y0 + 1540, at + 2.8))
        s.append(self.enter(self.txt(M, y0 + 1680, c["note"], 26, T["ink_faint"], "start"),
                            at + 3.1))
        s.append(L.foot(y0 + 1850, at + 3.4))
        return "".join(s)

    def s_grid(self, c, y0, at):
        T = self.T
        M, R, L = self.M, self.R, self.L
        s = [self.section_no(5, y0, at),
             self.section_head(c["kicker"], c["title"], y0, at)]
        items = c["items"]
        for i, (name, out) in enumerate(items):
            col, row = i % 2, i // 2
            x = L.col(col)
            yy = y0 + 560 + row * L.step(220)
            cell = (self.txt(x, yy, f"{i + 1:02d}", 22, T["ink_faint"],
                             "start", 400, "mono", T["tracking_label"])
                    + self.txt(x + 56, yy, name, 32, T["ink"], "start", 400, "serif")
                    + self.txt(x + 56, yy + 56, out, 26, T["accent"], "start")
                    + L.divider(x, yy + 90, min(x + 400, R), yy + 90))
            s.append(self.enter(cell, at + 0.8 + i * 0.16))
        s.append(self.enter(self.txt(M, y0 + 1700, c["note"], 26, T["ink_faint"], "start"),
                            at + 2.8))
        s.append(L.foot(y0 + 1850, at + 3.1))
        return "".join(s)

    def s_demo(self, c, y0, at):
        T = self.T
        M, R, L = self.M, self.R, self.L
        s = [self.section_no(6, y0, at),
             self.section_head(c["kicker"], c["title"], y0, at)]
        st = self.D.get("stagger", 0.42)
        q = 0
        for i, d in enumerate(c["dialog"]):
            yy = y0 + 600 + i * L.step(230)
            if d["who"] == "？":
                who = ["客户", "同事"][min(q, 1)]
                q += 1
                before = (self.txt(M, yy, "？", 26, T["accent"], "start", 400, "mono")
                          + self.line(M, yy + 18, M + 48, yy + 18, T["accent"], 1.5))
                after = self.txt(M, yy, who, 26, T["accent_deep"], "start", 400, "serif")
                s.append(self.switch(before, after, at + 4.2 + i * 0.3,
                                     show_at=at + 0.9 + i * st))
            else:
                s.append(self.enter(self.txt(M, yy, d["who"], 26, T["ink_faint"],
                                             "start", 400, "serif"), at + 0.9 + i * st))
            s.append(self.enter(self.txt(M + 170, yy, d["line"], 30, T["ink"], "start"),
                                at + 1.0 + i * st))
            s.append(self.enter(L.divider(M, yy + 72, R, yy + 72),
                                at + 1.1 + i * st))
        s.append(self.draw(f"M{M} {num(y0 + 1440)}V{num(y0 + 1660)}",
                           T["accent_deep"], 1.5, at + 3.0, 0.9))
        s.append(self.enter(self.txt(M + 28, y0 + 1500, c["result"], 26, T["ink_dim"], "start")
                            + self.txt(M + 28, y0 + 1570, c["notes"][0], 26, T["ink_faint"], "start")
                            + self.txt(M + 28, y0 + 1640, c["notes"][1], 26, T["ink_faint"], "start"),
                            at + 3.2))
        s.append(self.enter(self.txt(M, y0 + 1760, c["prompt"], 26, T["accent"], "start"),
                            at + 3.6))
        s.append(L.foot(y0 + 1850, at + 3.9))
        return "".join(s)

    def s_terminal(self, c, y0, at):
        T = self.T
        M, R, L = self.M, self.R, self.L
        s = [self.section_no(7, y0, at),
             self.section_head(c["kicker"], c["title"], y0, at)]
        s.append(self.draw(f"M{M} {num(y0 + 520)}H{R}", T["rule_strong"], 1.5, at + 0.7, 0.9))
        s.append(self.enter(self.txt(M, y0 + 620, "›", 30, T["accent"],
                                     "start", 400, "mono"), at + 0.9))
        s.append(self.typewriter(c["cmd"], M + 56, y0 + 620, 30, T["ink"], at + 1.1))
        s.append(self.enter(self.txt(M + 56, y0 + 740, c["reply"], 28, T["ink_dim"], "start"),
                            at + 4.0))
        s.append(self.draw(f"M{M} {num(y0 + 810)}H{R}", T["rule"], T["rule_w"], at + 4.2, 0.9))
        s.append(self.enter(self.txt(M, y0 + 940, "今天 · 待办", 36, T["ink"],
                                     "start", 400, "serif", 2), at + 4.4, emphasis=True))
        st = self.D.get("stagger", 0.42)
        for i, t in enumerate(c["todos"]):
            yy = y0 + 1080 + i * L.step(160)
            one = (self.txt(M, yy, f"0{i + 1}", 22, T["ink_faint"], "start", 400, "mono")
                   + self.txt(M + 80, yy, t, 30, T["ink"], "start")
                   + L.divider(M, yy + 44, R, yy + 44))
            s.append(self.enter(one, at + 4.6 + i * st))
        s.append(self.enter(self.txt(M, y0 + 1600, c["note"], 26, T["ink_faint"], "start"),
                            at + 5.8))
        s.append(L.foot(y0 + 1850, at + 6.0))
        return "".join(s)

    def s_finale(self, c, y0, at):
        T = self.T
        L = self.L
        s = [self.section_no(8, y0, at)]
        s.append(self.enter(self.txt(540, y0 + 240, c["kicker"], 26, T["accent"],
                                     "middle", 400, "body", T["tracking_kicker"]), at))
        s.append(self.enter(self.txt(540, y0 + 380, c["title"],
                                     self.fit_size(c["title"], 70, 960,
                                                   T["tracking_title"]),
                                     T["ink"], "middle", 400, "serif",
                                     T["tracking_title"]), at + 0.2, emphasis=True))
        s.append(self.draw(f"M512 {num(y0 + 440)}H568", T["accent"],
                           T["rule_w_accent"], at + 0.6, 0.8))
        s.append(self.draw(f"M540 {num(y0 + 540)}V{num(y0 + 1160)}",
                           T["rule_strong"], 1.5, at + 0.8, 1.0))
        for i, key in enumerate(("left", "right")):
            d = c[key]
            cx = L.center(i)
            hi = i == 1
            body = (self.txt(cx, y0 + 610, d["title"], 28,
                             T["ink_dim"] if not hi else T["accent"],
                             "middle", 400, "serif")
                    + self.txt(cx, y0 + 740, d["price"], 56, T["ink"],
                               "middle", 400, "serif", 2))
            for j, sp in enumerate(d["specs"]):
                body += self.txt(cx, y0 + 880 + j * L.step(92), sp, 26,
                                 T["ink_dim"], "middle")
            s.append(self.enter(body, at + 1.0 + i * 0.35))
        s.append(self.enter(self.txt(540, y0 + 1370, c["logo"],
                                     self.fit_size(c["logo"], 76, 960, 10),
                                     T["ink"], "middle", 400, "serif", 10),
                            at + 2.2, emphasis=True))
        s.append(self.enter(self.txt(540, y0 + 1480, c["footer"], 32, T["ink_dim"]), at + 2.6))
        s.append(self.enter(self.txt(540, y0 + 1570, c["disclaimer"], 22, T["ink_faint"]),
                            at + 2.9))
        s.append(L.foot(y0 + 1800, at + 3.3))
        return "".join(s)

    # ---------- 通用场景模板：任意题材的公众号文章都能用 ----------
    # 这一组不假设是产品发布稿，字段全部可缺省，新增屏型只要照着加 s_xxx。
    def _clip(self, s, n=20):
        # 1080 设计稿在手机上只有 390px（0.361 缩放），窄内栏版式下
        # 一行最多放约 16 个汉字；统一卡上限，避免右边界裁字。
        n = min(int(n), 16)
        s = str(s)
        return s if len(s) <= n else s[:max(1, n - 1)] + "…"

    def _head(self, c, y0, at):
        return (self.section_no(y0, at)
                + self.section_head(c.get("kicker", ""), c.get("title", ""), y0, at))

    def _foot(self, y0, at):
        return self.L.foot(y0 + 1850, at)

    def s_chapter(self, c, y0, at):
        """章节扉页：超大章节号 + 章标题 + 引言，长文分节用。"""
        T, L, M = self.T, self.L, self.M
        idx = getattr(self, "cur_idx", 0) + 1
        s = [self.ruler(y0 + 140, at + 0.1, left=c.get("kicker", ""),
                        right=f"{idx:02d} / {self.n_total:02d}")]
        s.append(self.enter(self.txt(M, y0 + 600, f"{idx:02d}", 148,
                                     T["rule_strong"], "start", 400, "serif"), at + 0.3))
        title = c.get("title", "")
        s.append(self.enter(self.txt(M, y0 + 860, title,
                                     self.fit_size(title, 72, self.R - M - 24,
                                                   T["tracking_title"]),
                                     T["ink"], "start", 400, "serif",
                                     T["tracking_title"]), at + 0.5, emphasis=True))
        s.append(self.draw(f"M{M} {num(y0 + 930)}H{num(M + max(56, L.accent_rule))}",
                           T["accent"], T["rule_w_accent"], at + 0.8, 0.8))
        for i, ln in enumerate(wrap_cn(c.get("sub", ""), 20)[:3]):
            s.append(self.enter(self.txt(M, y0 + 1080 + i * L.step(84), ln, 32,
                                         T["ink_dim"], "start"), at + 1.0 + i * 0.22))
        if c.get("note"):
            s.append(self.enter(self.txt(M, y0 + 1540, self._clip(c["note"], 26),
                                         26, T["ink_faint"], "start"), at + 1.8))
        s.append(self._foot(y0, at + 2.2))
        return "".join(s)

    def s_prose(self, c, y0, at):
        """正文屏：若干段落自动折行，逐行显现；行距按总行数自适应，绝不越界。"""
        T, L, M = self.T, self.L, self.M
        s = [self._head(c, y0, at)]
        paras = c.get("paragraphs") or ([c["text"]] if c.get("text") else [])
        per = int(c.get("per_line", 20))
        lines = []
        for p in paras:
            for ln in wrap_cn(p, per):
                lines.append((ln, False))
            lines.append(("", True))
        top, bottom = 600, 1650
        step = min(70, (bottom - top) / max(1, len(lines)))
        st = self.D.get("stagger", 0.42) * 0.45
        for i, (ln, gap) in enumerate(lines):
            if gap or not ln:
                continue
            s.append(self.enter(self.txt(M, y0 + top + i * step, ln, 30,
                                         T["ink"], "start"), at + 0.85 + i * st))
        if c.get("note"):
            s.append(self.enter(self.txt(M, y0 + 1740, self._clip(c["note"], 28),
                                         26, T["ink_faint"], "start"), at + 1.4))
        s.append(self._foot(y0, at + 1.9))
        return "".join(s)

    def s_quote(self, c, y0, at):
        """金句屏：大字引文居中、左侧一条强调竖线、右下出处。"""
        T, L, M, R = self.T, self.L, self.M, self.R
        s = [self.section_no(y0, at)]
        s.append(self.enter(self.txt(M, y0 + 300, c.get("kicker", ""), 24,
                                     T["accent"], "start", 400, "body",
                                     T["tracking_kicker"]), at))
        lines = wrap_cn(c.get("quote", ""), 12)[:7]
        base = self.fit_size(max(lines, key=len) if lines else "", 72, 820,
                             T["tracking_title"])
        top, step = 660, min(120, 900 / max(1, len(lines)))
        s.append(self.draw(f"M{M} {num(y0 + 560)}V{num(y0 + 560 + len(lines) * step)}",
                           T["accent"], T["rule_w_accent"], at + 0.3, 0.9))
        for i, ln in enumerate(lines):
            s.append(self.enter(self.txt(540, y0 + top + i * step, ln, base,
                                         T["ink"], "middle", 400, "serif",
                                         T["tracking_title"]),
                                at + 0.5 + i * 0.22, emphasis=True))
        if c.get("source"):
            s.append(self.enter(self.txt(R, y0 + 1600, self._clip(c["source"], 22),
                                         26, T["ink_dim"], "end", 400, "serif"), at + 1.6))
        if c.get("note"):
            s.append(self.enter(self.txt(M, y0 + 1720, self._clip(c["note"], 28),
                                         26, T["ink_faint"], "start"), at + 1.9))
        s.append(self._foot(y0, at + 2.3))
        return "".join(s)

    def s_list(self, c, y0, at):
        """要点清单：等宽编号 + 名称 + 一行说明 + 细分隔线。"""
        T, L, M, R = self.T, self.L, self.M, self.R
        items = (c.get("items") or [])[:7]
        s = [self._head(c, y0, at)]
        st = self.D.get("stagger", 0.42)
        step = min(230, (1640 - 580) / max(1, len(items)))
        for i, it in enumerate(items):
            if isinstance(it, (list, tuple)):
                name, desc = (list(it) + [""])[:2]
            else:
                name, desc = str(it), ""
            yy = y0 + 580 + i * step
            cell = (self.txt(M, yy, f"{i + 1:02d}", 22, T["ink_faint"], "start",
                             400, "mono", T["tracking_label"])
                    + self.txt(M + 70, yy, self._clip(name, 18), 34, T["ink"],
                               "start", 400, "serif", 2))
            if desc:
                cell += self.txt(M + 70, yy + 56, self._clip(desc, 24), 26,
                                 T["ink_dim"], "start")
            cell += L.divider(M, yy + 96, min(M + 460, R), yy + 96)
            s.append(self.enter(cell, at + 0.8 + i * st))
        if c.get("note"):
            s.append(self.enter(self.txt(M, y0 + 1740, self._clip(c["note"], 28),
                                         26, T["ink_faint"], "start"), at + 2.4))
        s.append(self._foot(y0, at + 2.8))
        return "".join(s)

    def s_compare(self, c, y0, at):
        """左右对照：两栏要点 + 中线 + 点击揭晓的结论。"""
        T, L, M = self.T, self.L, self.M
        sides = [c.get("left") or {}, c.get("right") or {}]
        s = [self._head(c, y0, at)]
        s.append(self.draw(f"M540 {num(y0 + 540)}V{num(y0 + 1380)}",
                           T["rule_strong"], 1.5, at + 0.7, 1.0))
        st = self.D.get("stagger", 0.42)
        for i, d in enumerate(sides):
            x = L.col(i)
            col = T["accent"] if i == 1 else T["ink_dim"]
            body = (self.txt(x, y0 + 600, self._clip(d.get("title", ""), 10), 30,
                             col, "start", 400, "serif")
                    + self.txt(x, y0 + 660, self._clip(d.get("tag", ""), 12), 22,
                               T["ink_faint"], "start", 400, "body",
                               T["tracking_label"]))
            for j, p in enumerate((d.get("points") or [])[:5]):
                body += self.txt(x, y0 + 790 + j * L.step(110), self._clip(p, 12),
                                 28, T["ink"] if i == 1 else T["ink_dim"], "start")
            s.append(self.enter(body, at + 0.9 + i * st))
        if c.get("conclusion"):
            s.append(self.fade(
                self.txt(540, y0 + 1580, self._clip(c["conclusion"], 24), 34,
                         T["ink"], "middle", 400, "serif", 2),
                at + 3.6, clickable=True))
            s.append(self.enter(self.txt(540, y0 + 1680, "点一下，结论就出来", 24,
                                         T["accent"], "middle", 400, "body",
                                         T["tracking_label"]), at + 1.4))
        s.append(self._foot(y0, at + 4.2))
        return "".join(s)

    def s_numbers(self, c, y0, at):
        """数据看板：3 个横排或 4 个 2×2，数值用宋体大字，注脚写清来源。"""
        T, L, M, R = self.T, self.L, self.M, self.R
        items = [x for x in (c.get("items") or []) if x][:4]
        s = [self._head(c, y0, at)]
        st = self.D.get("stagger", 0.42)
        if len(items) <= 3:
            for i, p in enumerate(items):
                v, lab, note = (list(p) + ["", ""])[:3]
                x = 540 + (i - (len(items) - 1) / 2.0) * 310
                cell = (self.line(x - 90, y0 + 700, x + 90, y0 + 700,
                                  T["rule_strong"], T["rule_w_strong"])
                        + self.txt(x, y0 + 900, self._clip(v, 10), 68, T["ink"],
                                   "middle", 400, "serif")
                        + self.txt(x, y0 + 990, self._clip(lab, 12), 28,
                                   T["ink_dim"], "middle")
                        + self.txt(x, y0 + 1060, self._clip(note, 14), 24,
                                   T["ink_faint"], "middle"))
                s.append(self.enter(cell, at + 0.8 + i * st))
            s.append(self.draw(f"M{M} {num(y0 + 1200)}H{R}", T["rule"],
                               T["rule_w"], at + 2.0, 0.9))
        else:
            for i, p in enumerate(items):
                v, lab, note = (list(p) + ["", ""])[:3]
                x = L.center(i % 2)
                yy = y0 + 700 + (i // 2) * 470
                cell = (self.line(x - 90, yy, x + 90, yy, T["rule_strong"],
                                  T["rule_w_strong"])
                        + self.txt(x, yy + 180, self._clip(v, 10), 64, T["ink"],
                                   "middle", 400, "serif")
                        + self.txt(x, yy + 265, self._clip(lab, 12), 28,
                                   T["ink_dim"], "middle")
                        + self.txt(x, yy + 330, self._clip(note, 14), 24,
                                   T["ink_faint"], "middle"))
                s.append(self.enter(cell, at + 0.8 + i * st))
            s.append(self.draw(f"M540 {num(y0 + 620)}V{num(y0 + 1600)}",
                               T["rule"], T["rule_w"], at + 2.0, 0.9))
        if c.get("conclusion"):
            s.append(self.fade(
                self.txt(540, y0 + 1420, self._clip(c["conclusion"], 24), 36,
                         T["ink"], "middle", 400, "serif", 2),
                at + 3.5, clickable=True))
        if c.get("source"):
            s.append(self.enter(self.txt(M, y0 + 1700, self._clip(c["source"], 30),
                                         24, T["ink_faint"], "start"), at + 2.2))
        s.append(self._foot(y0, at + 4.1))
        return "".join(s)

    def s_timeline(self, c, y0, at):
        """时间轴：竖轴 + 节点 + 时间 / 事件 / 说明三行。"""
        T, L, M, R = self.T, self.L, self.M, self.R
        items = (c.get("items") or [])[:5]
        s = [self._head(c, y0, at)]
        x0 = M + 60
        s.append(self.draw(f"M{num(x0)} {num(y0 + 580)}V{num(y0 + 1600)}",
                           T["rule_strong"], 1.5, at + 0.6, 1.2))
        st = self.D.get("stagger", 0.42)
        step = min(250, (1600 - 620) / max(1, len(items)))
        for i, p in enumerate(items):
            t, ev, note = (list(p) + ["", ""])[:3]
            yy = y0 + 620 + i * step
            cell = (self.circle(x0, yy - 10, 7, T["accent"], T["bg"], 2)
                    + self.txt(x0 + 50, yy, self._clip(t, 14), 22,
                               T["ink_faint"], "start", 400, "mono",
                               T["tracking_label"])
                    + self.txt(x0 + 50, yy + 70, self._clip(ev, 20), 34,
                               T["ink"], "start", 400, "serif", 2)
                    + self.txt(x0 + 50, yy + 122, self._clip(note, 24), 26,
                               T["ink_dim"], "start")
                    + L.divider(x0 + 50, yy + 160, R, yy + 160))
            s.append(self.enter(cell, at + 0.8 + i * st))
        s.append(self._foot(y0, at + 2.9))
        return "".join(s)

    def s_qa(self, c, y0, at):
        """问答：问句常驻，答案「点了就出、不点也会自己出」。"""
        T, L, M = self.T, self.L, self.M
        items = (c.get("items") or [])[:3]
        s = [self._head(c, y0, at)]
        step = min(400, (1660 - 580) / max(1, len(items)))
        for i, p in enumerate(items):
            q, a = (list(p) + [""])[:2]
            yy = y0 + 580 + i * step
            s.append(self.enter(
                self.txt(M, yy, "Q", 22, T["accent"], "start", 400, "mono",
                         T["tracking_label"])
                + self.txt(M + 56, yy, self._clip(q, 20), 34, T["ink"],
                           "start", 400, "serif", 2), at + 0.8 + i * 0.8))
            s.append(self.draw(f"M{M} {num(yy + 42)}V{num(yy + step - 70)}",
                               T["accent"], 2.2, at + 1.0 + i * 0.8, 0.7))
            ans = "".join(
                self.txt(M + 56, yy + 96 + j * L.step(66), ln, 28,
                         T["ink_dim"], "start")
                for j, ln in enumerate(wrap_cn(a, 18)[:3]))
            s.append(self.fade(ans, at + 3.4 + i * 0.5, clickable=True))
        s.append(self.enter(self.txt(M, y0 + 1740, "点一下，答案就出来；不点也会自己出现", 24,
                                     T["accent"], "start", 400, "body",
                                     T["tracking_label"]), at + 1.3))
        s.append(self._foot(y0, at + 4.4))
        return "".join(s)

    def s_steps(self, c, y0, at):
        """步骤流程：01 / 02 / 03 逐条落下，教程与操作指南用。"""
        T, L, M, R = self.T, self.L, self.M, self.R
        items = (c.get("items") or [])[:5]
        s = [self._head(c, y0, at)]
        st = self.D.get("stagger", 0.42)
        step = min(240, (1640 - 600) / max(1, len(items)))
        for i, p in enumerate(items):
            name, desc = (list(p) + [""])[:2]
            yy = y0 + 600 + i * step
            cell = (self.txt(M, yy, f"0{i + 1}", 40,
                             T["accent"] if i == 0 else T["ink_faint"],
                             "start", 400, "mono", T["tracking_label"])
                    + self.txt(M + 130, yy, self._clip(name, 18), 34, T["ink"],
                               "start", 400, "serif", 2)
                    + self.txt(M + 130, yy + 60, self._clip(desc, 24), 26,
                               T["ink_dim"], "start")
                    + L.divider(M, yy + 100, R, yy + 100))
            s.append(self.enter(cell, at + 0.8 + i * st))
        if c.get("conclusion"):
            s.append(self.fade(
                self.txt(540, y0 + 1740, self._clip(c["conclusion"], 24), 30,
                         T["ink"], "middle", 400, "serif"),
                at + 3.5, clickable=True))
        s.append(self._foot(y0, at + 4.0))
        return "".join(s)

    def s_closing(self, c, y0, at):
        """通用收尾：一句主张 + 署名 + 免责说明 + 三句行动提示。"""
        T, L, M = self.T, self.L, self.M
        s = [self.section_no(y0, at)]
        s.append(self.enter(self.txt(540, y0 + 260, c.get("kicker", ""), 26,
                                     T["accent"], "middle", 400, "body",
                                     T["tracking_kicker"]), at))
        title = c.get("title", "")
        s.append(self.enter(self.txt(540, y0 + 430, title,
                                     self.fit_size(title, 70, 960,
                                                   T["tracking_title"]),
                                     T["ink"], "middle", 400, "serif",
                                     T["tracking_title"]), at + 0.2, emphasis=True))
        s.append(self.draw("M512 " + num(y0 + 500) + "H568", T["accent"],
                           T["rule_w_accent"], at + 0.6, 0.8))
        logo = c.get("logo", "")
        if logo:
            s.append(self.enter(self.txt(540, y0 + 860, logo,
                                         self.fit_size(logo, 76, 960, 10),
                                         T["ink"], "middle", 400, "serif", 10),
                                at + 1.0, emphasis=True))
        if c.get("footer"):
            s.append(self.enter(self.txt(540, y0 + 990, c["footer"], 32,
                                         T["ink_dim"], "middle"), at + 1.4))
        ctas = (c.get("cta") or [])[:3]
        if ctas:
            s.append(self.draw(f"M{M} {num(y0 + 1120)}H{self.R}", T["rule_strong"],
                               T["rule_w_strong"], at + 1.6, 0.9))
            st = self.D.get("stagger", 0.42)
            for i, one in enumerate(ctas):
                x = 540 + (i - (len(ctas) - 1) / 2.0) * 320
                cell = (self.txt(x, y0 + 1300, f"0{i + 1}", 22, T["ink_faint"],
                                 "middle", 400, "mono", T["tracking_label"])
                        + self.txt(x, y0 + 1390, self._clip(one, 12), 28, T["ink"],
                                   "middle", 400, "serif"))
                # 最后一个行动提示用「点了就出、不点也会自己出」的双触发：
                # 保证每一篇（哪怕没有问答 / 对照屏）都保留点击交互。
                if i == len(ctas) - 1:
                    s.append(self.fade(cell, at + 1.9 + i * st, clickable=True))
                else:
                    s.append(self.enter(cell, at + 1.9 + i * st))
        if c.get("disclaimer"):
            block = self.txt(540, y0 + 1640,
                             self._clip(c["disclaimer"], 34), 22,
                             T["ink_faint"], "middle")
            if not ctas:   # 没有行动提示时，用免责说明兜住点击交互
                s.append(self.fade(block, at + 2.8, clickable=True))
            else:
                s.append(self.enter(block, at + 2.8))
        s.append(L.foot(y0 + 1800, at + 3.2))
        return "".join(s)

    # ---------- 组装 ----------
    def build(self, content):
        scenes = content["scenes"]
        n = len(scenes)
        self.n_total = n
        H = n * self.sh
        span = float(self.C.get("scene_span", 8.0))
        expand = [float(x) for x in self.C.get("expand_at", [])][:max(0, n - 1)]
        while len(expand) < n - 1:
            expand.append(round((expand[-1] if expand else 0) + span, 2))
        scene_at = [0.0] + list(expand)
        self.n_scene = n
        self.expand = expand
        self.scene_at = scene_at
        self.H = H
        if self.C.get("tail_loop_at"):
            self.tail = float(self.C["tail_loop_at"])
        else:
            self.tail = float((expand[-1] if expand else 0)
                              + float(self.C.get("tail_pad", 5)))

        T = self.T
        main = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 {H}" '
                f'style="display:block;width:100%;line-height:0;">',
                self.rect(0, 0, 1080, H, T["bg"])]
        for i, sc in enumerate(scenes):
            self.cur_idx = i
            fn = getattr(self, "s_" + sc["type"], None)
            if fn is None:
                raise ValueError(f"未知场景类型: {sc['type']}（在 generator.py 里加 s_{sc['type']} 即可）")
            main.append(fn(sc, i * self.sh, scene_at[i]))
        main.append(self.fade(self.line(512, H - 100, 568, H - 100, T["accent"],
                                       T["rule_w_accent"]), self.tail, 0.9))
        main.append("</svg>")

        sp = ['<svg xmlns="http://www.w3.org/2000/svg" '
              f'viewBox="0 0 1080 {self.sh}" width="100%" '
              'style="display:block;max-width:none!important;pointer-events:none;">']
        if self.static:
            sp = [f'<svg xmlns="http://www.w3.org/2000/svg" '
                  f'viewBox="0 0 1080 {self.sh}" width="{n * 100}%" '
                  'style="display:block;max-width:none!important;pointer-events:none;">']
        else:
            prev = 100
            for t in expand:
                a = (f'<animate attributeName="width" values="{prev}%;{prev + 100}%" '
                     f'begin="{num(t)}s" dur="0.9s" fill="freeze" restart="never" {self.ease()}/>')
                sp.append(a)
                self.n_anim += 1
                prev += 100
        sp.append("</svg>")

        guide = ("下面这段会自己一段一段往下展开，点一下也能接着看，不点也会播完。"
                 if not self.static else
                 "下面是完整图文，不用等动画，直接往下看就行。")
        frag = (
            f'<section style="overflow:hidden;line-height:0;text-align:center;background-color:{T["bg"]};">\n'
            '<section style="height:0;overflow:visible;line-height:0;width:100%;">\n'
            + "\n".join(main) + "\n</section>\n"
            + "\n".join(sp) + "\n</section>\n"
            f'<p style="text-align:center;font-size:14px;color:#888888;margin:24px 0 8px;">'
            f'<span>{esc(guide)}</span></p>'
        )
        self.frag = frag
        return frag

    def stats(self):
        return {
            "段数": self.n_scene,
            "画布高度": self.H,
            "展开时刻": self.expand,
            "自动播完约": self.tail,
            "动画元素总数": self.n_anim,
            "触发模式": self.mode,
            "设计语言": self.T.get("name", "—"),
            "动效预设": self.MOT.get("name", "静默递进"),
            "版式预设": self.LAY.get("name", "仪器说明书"),
        }


# ---------- 微信净化形态归一化 ----------
def wechat_normalize(frag):
    """把标准 SVG 写法转成「公众号线上文章被净化后的真实 DOM 形态」。

    依据：原文 js_content.html（线上确实能播放）里 281 个 animate、111 个
    animatetransform、170 个 <tspan leaf=""> 全部是小写标签名与小写属性名，
    空元素也都被展开成显式闭合。Chrome 实测：HTML 内联 SVG 被解析时会自动
    把 animatetransform / attributename / repeatcount / calcmode / keytimes /
    keysplines / viewbox / pathlength 修正回驼峰，SMIL 动画照常启动与渲染。
    """
    s = frag
    # 1) 标签名全小写：animateTransform -> animatetransform
    s = re.sub(r'(</?)([A-Za-z][\w:-]*)',
               lambda m: m.group(1) + m.group(2).lower(), s)
    # 2) 属性名全小写：attributeName -> attributename，repeatCount -> repeatcount ...
    s = re.sub(r'(\s)([A-Za-z][\w:-]*)=',
               lambda m: m.group(1) + m.group(2).lower() + '=', s)
    # 3) 所有 tspan 补 leaf，避免被当叶子节点清洗
    s = re.sub(r'<tspan(?![^>]*\bleaf=)([^>]*)>', r'<tspan leaf=""\1>', s)
    # 4) 自闭合空元素展开成显式闭合，与微信净化后的 DOM 一致
    s = re.sub(r'<([a-zA-Z][\w:-]*)([^>]*?)\s*/>',
               lambda m: f'<{m.group(1)}{m.group(2)}></{m.group(1)}>', s)
    return s


LOCATOR_JS = r'''// ---------- 正文编辑区定位：绝不把 SVG 写进标题 / 作者 / 摘要 ----------
function wbText(el) { return ((el && (el.innerText || el.textContent)) || '').trim(); }
function wbSig(el) {
  if (!el || !el.getAttribute) return '';
  var c = (typeof el.className === 'string') ? el.className : String(el.className || '');
  return [el.id || '', c, el.getAttribute('data-placeholder') || '',
          el.getAttribute('placeholder') || '', el.getAttribute('aria-label') || '',
          el.getAttribute('name') || ''].join(' ').toLowerCase();
}
function wbTitleLike(el) {
  if (!el || !el.getAttribute) return true;
  if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return true;
  if (/title|author|digest|abstract|subtitle|标题|作者|摘要|昵称/.test(wbSig(el))) return true;
  var ml = parseInt(el.getAttribute('maxlength') || '0', 10);
  if (ml > 0 && ml < 100) return true;
  var p = el.parentElement, hop = 0;
  while (p && hop++ < 2) {
    var ps = [(p.id || ''), (typeof p.className === 'string' ? p.className : '')].join(' ').toLowerCase();
    if (/js_?title|title_?input|article_?title|author_?input|digest_?input/.test(ps)) return true;
    p = p.parentElement;
  }
  return false;
}
function wbEditors() {
  var out = [], docs = [document], fr = document.querySelectorAll('iframe'), i, j;
  for (i = 0; i < fr.length; i++) {
    try { if (fr[i].contentDocument) docs.push(fr[i].contentDocument); } catch (e) {}
  }
  for (i = 0; i < docs.length; i++) {
    var list = docs[i].querySelectorAll('[contenteditable="true"],body[contenteditable]');
    for (j = 0; j < list.length; j++) if (out.indexOf(list[j]) < 0) out.push(list[j]);
  }
  return out;
}
function wbRoot(el) {
  var n = el;
  while (n && n.nodeType === 1) {
    if (n.getAttribute && (n.getAttribute('contenteditable') || '').toLowerCase() === 'true') return n;
    n = n.parentElement;
  }
  return null;
}
function wbScore(el) {
  var s = 0, t = wbText(el);
  if (el.ownerDocument !== document) s += 40;
  if (el.querySelectorAll('p,section,div').length) s += 15;
  if (el.querySelectorAll('p').length > 1) s += 10;
  if (/editor|content|body|prosemirror|ueditor/.test(wbSig(el))) s += 15;
  s += Math.min(t.length, 3000) / 100;
  return s;
}
function wbReport(list, picked) {
  var rows = [];
  for (var i = 0; i < list.length; i++) {
    var e = list[i];
    rows.push({
      '序号': i, '标签': e.tagName.toLowerCase(), 'id': e.id || '-',
      'class': ((typeof e.className === 'string') ? e.className : '').slice(0, 36) || '-',
      '疑似标题': wbTitleLike(e) ? '是' : '否',
      '文本长度': wbText(e).length, '开头': wbText(e).slice(0, 16) || '(空)',
      '本次目标': e === picked ? 'YES' : ''
    });
  }
  try { console.table(rows); } catch (e) { console.log(rows); }
}
function wbPick() {
  var list = wbEditors(), note = '', anchor = null;
  try { if (window.__wbTarget && window.__wbTarget.nodeType) anchor = window.__wbTarget; } catch (e) {}
  if (!anchor) { try { if (typeof $0 !== 'undefined' && $0) anchor = $0; } catch (e) {} }
  if (anchor) {
    var root = wbRoot(anchor.nodeType === 1 ? anchor : anchor.parentElement);
    if (root && !wbTitleLike(root)) return { el: root, list: list, note: '锚定自 Elements 面板当前选中的元素（$0）' };
    note = '当前选中的元素落在标题/作者区或不在可编辑区，已忽略；';
  }
  var ok = [], i;
  for (i = 0; i < list.length; i++) if (!wbTitleLike(list[i])) ok.push(list[i]);
  if (!ok.length) return { el: null, list: list, note: note + '没找到非标题的可编辑容器' };
  ok.sort(function (a, b) { return wbScore(b) - wbScore(a); });
  if (ok[1] && wbScore(ok[0]) - wbScore(ok[1]) < 8)
    return { el: null, list: list, note: note + '多个容器分数接近，不自动选，请先在 Elements 点一下正文' };
  return { el: ok[0], list: list, note: note + '自动筛选（排除标题后按正文特征打分）' };
}
function wbCleanStray() {
  var marks = ['LAOMA VISION', '老马智能眼镜', '下面这段会自己', '下面这段是纯 SVG 动画',
               '抬眼就够了', '不用再低头了'];
  var list = wbEditors(), extra = document.querySelectorAll('input,textarea'), i, n = 0;
  for (i = 0; i < extra.length; i++) list.push(extra[i]);
  for (i = 0; i < list.length; i++) {
    var e = list[i], t = (e.value !== undefined ? e.value : '') + ' ' + wbText(e), hit = 0;
    for (var k = 0; k < marks.length; k++) if (t.indexOf(marks[k]) >= 0) hit++;
    var sig = wbSig(e) + ' ' + (e.tagName || '');
    if (hit >= 2 && /input|textarea|title|author|digest|标题|作者|摘要/i.test(sig) && t.length > 80) {
      if (e.value !== undefined) e.value = ''; else e.innerHTML = '';
      try { e.dispatchEvent(new (e.ownerDocument.defaultView || window).InputEvent('input', { bubbles: true })); } catch (x) {}
      n++;
    }
  }
  console.log('[清理] 已清空 ' + n + ' 处标题/作者区里的误注入文字，正文里的 SVG 未被触碰。');
  console.log('若 n=0，请直接点进标题框 Ctrl/Cmd+A 手动删除那一大串文字。');
  return n;
}'''


INJECT_TPL = r'''// 若 Console 弹黄色警告 "Don't paste code into the DevTools Console..."：
// 那是 Chrome 的 Self-XSS 防护拦住了「粘贴」这个动作，不是本代码报错，代码一行都没执行。
// allow pasting 是 DevTools 的解锁口令，不是 JS 代码：先粘贴本文件触发黄色警告，
// 再用键盘手打 allow pasting 并回车解锁，然后重新粘贴本文件；每次重开 DevTools 都要重走一遍。
// 没触发警告就直接执行这行字，会报 Uncaught SyntaxError: Unexpected identifier 'pasting'，与本代码无关。
// 也可以改用 DevTools → Sources → Snippets 代码段运行本文件，不受该拦截限制。
//
// 【2026-11-08 定位修正】旧版用 document.querySelector('.ProseMirror') 取第一个匹配，
// 公众号后台的标题框也是 contenteditable / .ProseMirror，于是 SVG 被写进标题、标签被清洗、
// 只剩一堆 tspan 文字。新版改为：先在 Elements 点一下正文 → $0 锚定 → 排除标题/作者/摘要
// → 写入后校验 SVG 数量 → 不合格自动回滚，绝不再静默写错容器。
(function () {
  var B64 = "@@B64@@";
  function decode(b64) {
    var bin = atob(b64), bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder('utf-8').decode(bytes);
  }
  var code = decode(B64);
  @@LOCATOR@@
  window.__wbCleanStray = wbCleanStray;
  window.__wbUndo = function () {
    if (!window.__wbTargetUsed || typeof window.__wbBackupHTML !== 'string') {
      console.warn('[回滚] 本次会话还没有成功注入过'); return;
    }
    window.__wbTargetUsed.innerHTML = window.__wbBackupHTML;
    console.log('[回滚] 已恢复注入前的正文');
  };

  var pick = wbPick();
  wbReport(pick.list, pick.el);
  console.log('[定位] ' + pick.note);
  if (!pick.el) {
    console.error('[SVG注入] 已中止，没有写入任何内容（避免再次跑进标题）。');
    console.log('① 最稳：F12 → Elements → 点一下正文编辑区里的文字 → 回 Console 重新运行本段代码。');
    console.log('② 或先在 Console 执行 window.__wbTarget = document.querySelector("正文容器选择器"); 再重跑。');
    console.log('③ 或直接改用方式 1（F12 → Edit as HTML），不需要定位。');
    console.log('④ 清掉上次误注入到标题的文字：执行 window.__wbCleanStray()');
    return;
  }
  var ed = pick.el;
  console.log('%c[定位] 目标 = <' + ed.tagName.toLowerCase() + '> id=' + (ed.id || '-') +
              ' class=' + ((typeof ed.className === 'string' ? ed.className : '').slice(0, 60) || '-'),
              'color:#06c;font-weight:bold');
  var backup = ed.innerHTML;
  ed.innerHTML = (window.__wbReplace === true ? '' : backup) + code;
  var ps = ed.querySelectorAll('p'), removed = 0;
  for (var j = 0; j < ps.length; j++) {
    var p = ps[j], t = (p.textContent || '').trim();
    if ((t === '' || t === '\u00a0' || p.innerHTML === '<br>') && !p.querySelector('svg,img')) {
      p.parentNode && p.parentNode.removeChild(p); removed++;
    }
  }
  try {
    var IE = (ed.ownerDocument.defaultView || window).InputEvent;
    ed.dispatchEvent(new IE('input', { bubbles: true, inputType: 'insertHTML', data: code }));
  } catch (e) {}
  var nSvg = ed.querySelectorAll('svg').length;
  var nA = ed.querySelectorAll('animate').length;
  var nT = ed.querySelectorAll('animateTransform, animatetransform').length;
  if (nSvg === 0 || nA === 0) {
    ed.innerHTML = backup;
    console.error('%c[SVG注入] 已自动回滚：这个容器把 SVG 标签清洗掉了（标题/摘要框就会这样），正文未改动。',
                  'color:#c33;font-weight:bold');
    console.log('请先在 Elements 点一下正文编辑区再重跑；或改用方式 1（Edit as HTML）。');
    return;
  }
  window.__wbBackupHTML = backup;
  window.__wbTargetUsed = ed;
  console.log('%c[SVG注入] 成功：svg=' + nSvg + '  animate=' + nA + '  animateTransform=' + nT +
              '  清理空段落=' + removed, 'color:#0a8;font-size:14px;font-weight:bold');
  console.log('下一步：保存为草稿 → 预览发到手机。编辑器里画面静止是正常的。');
  console.log('清理残留执行 window.__wbCleanStray()；回滚执行 window.__wbUndo()。');
})();'''


CHECK_JS = r'''(function () {
  @@LOCATOR@@
  window.__wbCleanStray = window.__wbCleanStray || wbCleanStray;
  var ed = window.__wbTargetUsed;
  if (!ed) { var p = wbPick(); wbReport(p.list, p.el); ed = p.el; }
  if (!ed) { console.error('[自检] 没定位到正文编辑区，请先在 Elements 面板点一下正文'); return; }
  var q = function (s) { return ed.querySelectorAll(s).length; };
  var hidden = 0, gs = ed.querySelectorAll('g');
  for (var i = 0; i < gs.length; i++) if (gs[i].getAttribute('opacity') === '0') hidden++;
  console.table({
    'SVG 个数': q('svg'),
    'animate': q('animate'),
    'animateTransform': q('animateTransform, animatetransform'),
    'tspan': q('tspan'),
    'opacity=0 的 g': hidden,
    '正文 HTML 长度': ed.innerHTML.length
  });
  if (q('animate') > 0) {
    console.log('%c✅ 动画标签还在 → 保存为草稿，用手机预览判定效果', 'color:#0a8;font-weight:bold');
  } else {
    console.log('%c❌ 动画标签已被剥离 → 这次是通过「粘贴」进来的，或被写进了标题区，删掉重做',
                'color:#c33;font-weight:bold');
    console.log('先执行 window.__wbCleanStray() 清理标题残留，再按方式 1 / 方式 2 重新注入。');
  }
})();'''


CLEAN_JS = r'''(function () {
  @@LOCATOR@@
  window.__wbCleanStray = wbCleanStray;
  var n = wbCleanStray();
  if (n === 0) console.log('没找到可自动清理的残留；请直接点进标题框 Ctrl/Cmd+A 手动删除那一大串文字。');
})();'''


def build_inject_js(frag):
    b64 = base64.b64encode(frag.encode("utf-8")).decode("ascii")
    return (INJECT_TPL.replace("@@B64@@", b64)
                      .replace("@@LOCATOR@@", LOCATOR_JS))


def build_check_js():
    return CHECK_JS.replace("@@LOCATOR@@", LOCATOR_JS)


def build_clean_js():
    return CLEAN_JS.replace("@@LOCATOR@@", LOCATOR_JS)


# ---------- 输出页面 ----------
def preview_page(frag, title, stats):
    info = " · ".join(f"{k}={v}" for k, v in stats.items() if k not in ("展开时刻",))
    return f'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(title)} · 本地预览</title>
<style>
 body{{margin:0;background:#eef1f6;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:#1f2937}}
 .wrap{{max-width:430px;margin:0 auto;padding:18px 14px 60px;box-sizing:border-box}}
 .hint{{background:#fff;border:1px solid #dbe3ee;border-radius:12px;padding:14px 16px;font-size:13px;line-height:1.8;margin-bottom:16px}}
 .hint b{{color:#0b4a86}}
 .phone{{width:390px;max-width:100%;margin:0 auto;background:#050B18;border-radius:18px;overflow:hidden;box-shadow:0 12px 40px rgba(16,42,80,.22)}}
 .phone p{{background:#ffffff!important;margin:0!important;padding:14px 10px!important}}
 .phone p span{{color:#555555!important}}
 .foot{{text-align:center;font-size:12px;color:#7b8794;margin-top:18px;line-height:1.8}}
</style></head><body><div class="wrap">
<div class="hint"><b>本地预览</b><br>页面高度会按时间轴一段段长出来，往下滚就能看到后续内容。这是浏览器预览，不是微信公众号环境，但 SVG 与 SMIL 代码与导入件完全一致。<br><span style="color:#6b7280">{esc(info)}</span></div>
<div class="phone">{frag}</div>
<div class="foot">刷新页面可重新播放 · 文件仅用于本地检查</div>
</div></body></html>'''


def importer_page(frag, static_frag, title, stats):
    """导入助手：只提供能保住 SMIL 动画标签的代码注入路径。"""
    info = " · ".join(f"{k}={v}" for k, v in stats.items() if k not in ("展开时刻",))
    tpl = r'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>@@TITLE@@ · 代码导入助手</title>
<style>
 body{margin:0;background:#eef1f6;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;color:#1f2937}
 .wrap{max-width:460px;margin:0 auto;padding:18px 14px 60px;box-sizing:border-box}
 .panel{background:#fff;border:1px solid #dbe3ee;border-radius:12px;padding:16px;margin-bottom:16px;font-size:13px;line-height:1.85}
 .panel h1{font-size:17px;margin:0 0 10px;color:#0b4a86}
 .panel h2{font-size:14px;margin:16px 0 6px;color:#0b4a86}
 .panel ol{padding-left:20px;margin:6px 0}
 .warn{background:#fff4f2;border:1px solid #f3b4a6;border-radius:12px;padding:14px 16px;margin-bottom:16px;font-size:13px;line-height:1.85;color:#8a2b18}
 .warn b{font-size:15px}
 .ok{background:#eef8f2;border:1px solid #a8d8bd;border-radius:12px;padding:14px 16px;margin-bottom:16px;font-size:13px;line-height:1.85;color:#145c37}
 .alert{background:#fff8e6;border:2px solid #e0a020;border-radius:12px;padding:14px 16px;margin-bottom:16px;font-size:13px;line-height:1.9;color:#6b4a06}
 .alert b{font-size:15px;color:#8a5a00}
 .alert.red{background:#fff1ee;border-color:#d8604a;color:#7a2b18}
 .alert.red b{color:#a3341c}
 .kbd{display:inline-block;background:#fff;border:1px solid #d8a63a;border-bottom-width:2px;border-radius:5px;padding:1px 7px;font-family:Menlo,Consolas,monospace;font-size:13px;color:#7a4b00}
 button{display:block;width:100%;margin:9px 0;padding:13px 16px;border:0;border-radius:10px;
   background:#0b4a86;color:#fff;font-size:15px;font-weight:600;cursor:pointer;text-align:left}
 button.alt{background:#e8eef7;color:#0b4a86}
 button.warnbtn{background:#f6e7e3;color:#8a2b18}
 button:active{opacity:.85}
 #toast{position:fixed;left:50%;bottom:28px;transform:translateX(-50%);background:#0b2a4a;color:#fff;
   padding:10px 18px;border-radius:20px;font-size:13px;opacity:0;transition:opacity .25s;pointer-events:none;z-index:99}
 .phone{width:390px;max-width:100%;margin:0 auto;background:#050B18;border-radius:18px;overflow:hidden;box-shadow:0 12px 40px rgba(16,42,80,.22)}
 .phone p{background:#ffffff!important;margin:0!important;padding:14px 10px!important}
 .phone p span{color:#555555!important}
 .meta{text-align:center;font-size:12px;color:#7b8794;margin-top:14px;line-height:1.8}
 code{background:#f1f5fa;padding:2px 5px;border-radius:4px;font-size:12px}
</style></head><body><div class="wrap">

<div class="alert red"><b>⚠️ 注入内容跑进标题里了？先看这里</b><br>
旧脚本用 <code>.ProseMirror</code> 取「<strong>第一个</strong>」可编辑容器，而公众号后台的<strong>标题框本身也是 contenteditable</strong>，
于是 SVG 被写进标题、标签被编辑器清洗，只剩一长串文字连在一起（就是截图里的样子）。<br>
新版已改成：<strong>先在 Elements 面板点一下正文</strong> → 脚本锚定这个位置 → 排除标题 / 作者 / 摘要 →
写入后校验 SVG 数量 → 不合格<strong>自动回滚</strong>，绝不静默写错容器。<br>
① 先点「⑤ 复制清理代码」在 Console 跑一次（或手动进标题框 <code>Ctrl/Cmd+A</code> 删掉那串字）；<br>
② 再按方式 2 的「第 0 步」点选正文，重新注入。<br>
最省事的是直接用 <b>方式 1（Edit as HTML）</b>：亲手选中的节点就是正文，物理上不可能跑进标题。</div>

<div class="alert"><b>⚠️ Console 粘贴被拦？先做第 0 步（Chrome 必做）</b><br>
看到黄色警告 <code>Don't paste code into the DevTools Console...</code> 时，
<strong>注入代码并没有报错，是 Chrome 120+ 的 Self-XSS 防护在粘贴前就拦下了 Ctrl+V</strong>，代码一行都没执行。<br>
① 先在 Console 里<b>粘贴一次注入代码</b>，让黄色警告弹出来（这次粘贴不会执行）；<br>
② 保持这个状态，<strong>用键盘一个字母一个字母敲</strong> <span class="kbd">allow pasting</span>（千万别用粘贴），然后按回车；<br>
③ 看到解锁成功的提示后，再粘贴「② 复制注入代码」并回车；<br>
④ <strong>每次关闭 / 重开 DevTools、或刷新页面后，都要重新走一遍</strong>；已经解锁过就别再敲第二次，直接粘代码。<br>
<b>常见误区：</b><span class="kbd">allow pasting</span> 是 DevTools 的解锁口令，<b>不是 JavaScript 代码</b>。没有那次被拦的粘贴、或把它复制进 Console 当代码执行，Chrome 会按普通 JS 解析，报 <code>Uncaught SyntaxError: Unexpected identifier &#x27;pasting&#x27;</code> —— 这行报错跟 SVG、跟注入脚本都无关，代码一行都没跑。<br>
不想敲就直接走 <b>方式 1（Edit as HTML）</b> 或 <b>方式 2B（Snippets 代码段）</b>，这两条完全不经过 Console 输入框，也就不会触发拦截。</div>

<div class="warn"><b>⚠️ 不要把源码 Ctrl+V 粘到正文里</b><br>
微信公众号后台的<strong>粘贴过滤器会剥掉 <code>&lt;animate&gt;</code> / <code>&lt;animatetransform&gt;</code></strong>，
粘进去只剩一张静态图。您截图里「只有蓝色眼镜、没有文字」的画面，正是因为所有文字都以
<code>opacity="0"</code> 起始、靠动画淡入，动画标签被剥掉后就永远隐藏了。<br>
SVG 交互图文<strong>必须走代码注入</strong>（F12 改 DOM 或 Console 注入），
这是公众号平台的通行规则，不是 SVG 写法的问题。本页已不再提供富文本粘贴按钮。</div>

<div class="panel"><h1>导入到微信公众号后台</h1>

<h2>方式 1 · F12 / Edit as HTML（首选，最稳）</h2>
<ol>
<li>用 <b>Chrome</b> 打开公众号后台新建图文，标题、作者、封面先填好，正文里随便打一个字母 <code>A</code>。</li>
<li>按 <code>F12</code>，点开发者工具左上角的选择箭头，点一下正文里那个 <code>A</code>。</li>
<li>Elements 面板里右键高亮的那行 → <code>Edit as HTML</code>。</li>
<li>点下面「复制 HTML 源码」，在编辑框里 <code>Ctrl/Cmd+A</code> 全选后整段替换，再点旁边空白处失焦。</li>
<li>关掉开发者工具，<b>先点「保存为草稿」</b>，再点「预览」发到手机上看。</li>
</ol>

<h2>方式 2 · Console 注入（自动，省手）</h2>
<ol>
<li><b>第 0 步 · 先定位正文（本次修正的重点）</b>：<code>F12</code> → <code>Elements</code> 面板 → 用左上角选择箭头
<b>点一下正文编辑区里的文字</b>，千万别点到标题 / 作者 / 摘要。脚本会锚定这个位置，不再猜选择器。</li>
<li><b>第 1 步 · 解锁粘贴（Chrome 必做）</b>：切到 <code>Console</code>，<b>先粘贴一次注入代码把黄色警告引出来</b>，再保持这个状态用键盘一个字母一个字母敲
<span class="kbd">allow pasting</span> 并回车。这是 DevTools 的解锁口令，<b>不是 JS 代码</b>，没有待确认的警告时敲它会报 <code>Unexpected identifier &#x27;pasting&#x27;</code>。切换面板不会改变上一步选中的元素。</li>
<li>点「② 复制注入代码」，回到 Console 再次粘贴并回车。</li>
<li>脚本会先打印一张<b>候选编辑区清单</b>和 <code>[定位] 目标 = ...</code>，瞄一眼确认是正文；
成功时打印 <code>[SVG注入] 完成：animate=…</code>，这个数字不为 0 就说明动画标签保住了。若打印「已自动回滚」，说明目标不对，重做第 0 步。</li>
<li>同样<b>先「保存为草稿」</b>，再手机预览。</li>
</ol>
<p style="margin:4px 0;color:#6b7280">想清空正文后写入（而不是追加）：先在 Console 执行
<code>window.__wbReplace = true</code>。默认保留原有正文。</p>

<h2>方式 2B · Sources → Snippets（不想解锁粘贴就用这个）</h2>
<p style="margin:4px 0;color:#7a2b18"><b>同样要先在 Elements 面板点一下正文</b>，脚本靠这个位置锚定正文容器。</p>
<ol>
<li><code>F12</code> → <code>Sources</code>（源代码）→ 左侧 <code>Snippets</code>（代码段，被折叠就点 <code>»</code>）→ <code>+ New snippet</code>。</li>
<li>把「② 复制注入代码」的内容粘进右侧代码编辑器。<b>这里是普通代码编辑器，不走 Console 的 Self-XSS 粘贴拦截</b>。</li>
<li>按 <code>Ctrl/Cmd + Enter</code> 运行（或右键 <code>Run</code>），输出结果回到 Console 面板看。</li>
</ol>
<p style="margin:4px 0;color:#6b7280">方式 3 的自检代码同样要先解锁，也可以照 2B 放进 Snippets 跑。</p>

<h2>方式 3 · 自检（判断到底有没有被过滤）</h2>
<ol><li>复制「自检代码」，在公众号后台 Console 里跑一次（先 <code>allow pasting</code> 解锁，或走方式 2B）。
成功注入过一次后，自检会直接复用那次记录的正文容器，不会再猜。</li>
<li><code>animate = 0</code> → 这次内容是被「粘贴」进来的，动画已被剥离，删掉重做方式 1 或 2。</li>
<li><code>animate &gt; 0</code> → 标签还在，问题只出在预览环节，看下面判定标准。</li></ol>

<h2>方式 4 · 第三方编辑器同步（备选）</h2>
<p style="margin:4px 0">iPaiban Pro 小助手插件、135 / 秀米 / E2 编辑器都提供「一键同步到公众号草稿箱」，
本质也是走接口写入 DOM，比手工粘贴可靠。有账号的话可以直接用。</p>
</div>

<div class="ok"><b>判定标准（很重要）</b><br>
· 后台编辑器里画面<strong>静止不动是正常的</strong>，编辑器本来就不播 SMIL，不要在编辑页点击触发交互，否则会让交互错乱。<br>
· 一切以「<strong>保存为草稿 → 手机预览</strong>」为准，建议 iOS / 安卓各看一次。<br>
· 手机上如果还是不动：先跑方式 3 自检；标签为 0 就重做注入，标签在却不动再考虑平台清洗，此时可改用「静态兜底版」保证内容可读。<br>
· Console 若打印 <code>[SVG注入] 已自动回滚</code> 或 <code>已中止</code>，说明正文没定位对，回方式 2 第 0 步重新点选正文；反复粘贴不会变好。<br>
· 若正文还有别的内容，先把别的排好版，<strong>最后</strong>再导入这段 SVG。</div>

<div class="panel">
<button id="code">① 复制 HTML 源码（方式 1 · Edit as HTML）</button>
<button id="inject" class="alt">② 复制注入代码（Console / Snippets 通用）</button>
<button id="check" class="alt">③ 复制自检代码（方式 3）</button>
<button id="static" class="warnbtn">④ 复制静态兜底版源码（动画被清空时的保险）</button>
<button id="clean" class="warnbtn">⑤ 复制清理代码（清掉误注入到标题的那串文字）</button>
<button id="reload" class="alt">↻ 重新播放下方预览</button>
<div class="meta">@@INFO@@</div>
</div>

<div class="phone" id="phone">@@FRAG@@</div>
<div class="meta">下方是本地实时预览；复制的是源码本身，不受播放进度影响。</div>
</div>
<div id="toast"></div>
<script>
const CODE=@@CODE@@;
const CODE_STATIC=@@CODE_STATIC@@;
const INJECT=@@INJECT@@;
const CHECK=@@CHECK@@;
const CLEAN=@@CLEAN@@;
function toast(m){const t=document.getElementById('toast');t.textContent=m;t.style.opacity=1;clearTimeout(window._tt);window._tt=setTimeout(()=>t.style.opacity=0,2800);}
async function copy(text,msg){
  try{ await navigator.clipboard.writeText(text); toast(msg); }
  catch(e){
    const ta=document.createElement('textarea');ta.value=text;
    ta.style.cssText='position:fixed;left:-99999px;top:0;';
    document.body.appendChild(ta);ta.select();
    let ok=false;try{ok=document.execCommand('copy');}catch(x){}
    ta.remove();toast(ok?msg:'复制失败，请直接打开对应的 .html 文件全选复制');
  }
}
document.getElementById('code').onclick=()=>copy(CODE,'源码已复制，去 F12 → Edit as HTML 整段替换');
document.getElementById('inject').onclick=()=>copy(INJECT,'已复制。先让粘贴触发黄色警告，再手打 allow pasting 回车解锁（口令不是 JS），最后重新粘贴');
document.getElementById('check').onclick=()=>copy(CHECK,'自检代码已复制；Console 若被拦，先触发警告再手打 allow pasting 回车');
document.getElementById('static').onclick=()=>copy(CODE_STATIC,'静态兜底版源码已复制');
document.getElementById('clean').onclick=()=>copy(CLEAN,'清理代码已复制；在公众号后台 Console 跑一次即可清掉标题残留');
document.getElementById('reload').onclick=()=>location.reload();
</script></body></html>'''
    return (tpl.replace("@@CODE_STATIC@@", json.dumps(static_frag, ensure_ascii=False))
               .replace("@@INJECT@@", json.dumps(build_inject_js(frag), ensure_ascii=False))
               .replace("@@CHECK@@", json.dumps(build_check_js(), ensure_ascii=False))
               .replace("@@CLEAN@@", json.dumps(build_clean_js(), ensure_ascii=False))
               .replace("@@CODE@@", json.dumps(frag, ensure_ascii=False))
               .replace("@@FRAG@@", frag)
               .replace("@@TITLE@@", esc(title))
               .replace("@@INFO@@", esc(info)))


# ---------- 预设解析 ----------
def preset_file(name, kind):
    p = Path(name)
    cands = [
        p,
        HERE / "presets" / p.name,
        HERE / "presets" / (kind + "." + str(name) + ".json"),
        HERE / "presets" / (str(name) + ".json"),
    ]
    for c in cands:
        if c.is_file():
            return c
    raise FileNotFoundError("找不到预设: %s (%s)，用 --list 看全部可用项" % (name, kind))


def resolve_path(v, for_out=False):
    p = Path(v)
    if p.is_absolute():
        return p
    cand = HERE / p
    return cand if (for_out or cand.exists()) else p


def load_json(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def theme_path(name):
    """主题既可以写文件名，也可以写短名（blueblack / 蓝黑）或绝对路径。"""
    if not name:
        return HERE / "theme.blueblack.json"
    p = Path(name)
    cands = [p, HERE / p.name, HERE / ("theme." + str(name) + ".json"),
             HERE / (str(name) + ".json")]
    if not p.is_absolute():
        for f in sorted(HERE.glob("theme.*.json")):
            j = load_json(f)
            if str(name) in (f.stem, f.stem[6:], j.get("name", "")):
                cands.append(f)
    for c in cands:
        if c.is_file():
            return c
    raise FileNotFoundError("找不到配色主题: %s（用 --list 看全部）" % name)


def list_presets():
    d = HERE / "presets"
    print("可用预设\n")
    print("[配色风格 theme]  --theme 名字或文件名")
    for f in sorted(HERE.glob("theme.*.json")):
        j = load_json(f)
        print("  %-24s %-14s %s" % (f.stem[6:], j.get("name", ""),
                                    j.get("corner", "")))
    print()
    for pref, label in (("scene.", "题材场景 scene"),
                        ("motion.", "动效 motion"),
                        ("layout.", "版式 layout"),
                        ("recipe.", "配方 recipe")):
        print("[%s]" % label)
        for f in sorted(d.glob(pref + "*.json")):
            j = load_json(f)
            key = f.stem[len(pref):]
            desc = j.get("character") or j.get("feel") or ""
            print("  %-22s %-12s %s" % (key, j.get("name", ""), desc))
        print()
    print("组合示例：")
    print("  python3 build.py --article 文章.md --scene product --out 输出目录   # 一键出片（推荐）")
    print("  python3 generator.py --scene science --content 内容.json --out 输出/正文.html")
    print("  python3 generator.py --recipe B-writing-magazine --content 内容.json --out 输出/正文.html")
    print("  python3 generator.py --motion writing --layout magazine --theme paper-editorial --content 内容.json --out 输出/正文.html")
    print("  python3 generator.py --list")
    print("\n三层（风格 / 动效 / 版式）互相正交，可任意交叉；内容 JSON 决定分屏与文案。")


def main():
    ap = argparse.ArgumentParser(
        description="微信公众号 SVG 交互动画生成器 · 风格 x 动效 x 版式")
    ap.add_argument("--theme", default=None, help="风格配置（文件名或路径）")
    ap.add_argument("--content", default=None, help="内容配置")
    ap.add_argument("--choreo", default=str(HERE / "choreography.json"),
                    help="时间轴骨架配置")
    ap.add_argument("--motion", default=None,
                    help="动效预设名：quiet / page-turn / writing / cadence / telegraph")
    ap.add_argument("--layout", default=None,
                    help="版式预设名：manual / magazine / dossier")
    ap.add_argument("--recipe", default=None,
                    help="一键配方名，如 B-writing-magazine（用 --list 看全部）")
    ap.add_argument("--scene", default=None,
                    help="题材场景预设名，如 product / science（自动带出推荐三层组合）")
    ap.add_argument("--out", default=None, help="正文片段输出路径")
    ap.add_argument("--list", action="store_true", help="列出全部预设与组合示例")
    ap.add_argument("--camel", action="store_true",
                    help="输出标准驼峰写法（仅供本地调试；导入微信请用默认的净化形态）")
    args = ap.parse_args()

    if args.list:
        list_presets()
        return

    recipe = {}
    if args.scene:
        recipe.update(load_json(preset_file(args.scene, "scene")))
    if args.recipe:   # 显式配方优先级最高，覆盖场景里的默认组合
        recipe.update(load_json(preset_file(args.recipe, "recipe")))

    theme_p = theme_path(args.theme or recipe.get("theme"))
    content_p = resolve_path(args.content or recipe.get("content")
                             or "../assets/示例内容.通用屏型演示.json")
    choreo_p = resolve_path(args.choreo)
    out = resolve_path(args.out or recipe.get("out") or "../输出/SVG动画正文.html", True)

    motion = None
    if args.motion or recipe.get("motion"):
        motion = load_json(preset_file(args.motion or recipe["motion"], "motion"))
    layout = None
    if args.layout or recipe.get("layout"):
        layout = load_json(preset_file(args.layout or recipe["layout"], "layout"))

    theme = load_json(theme_p)
    content = load_json(content_p)
    choreo = load_json(choreo_p)

    b = Builder(theme, choreo, layout=layout, motion=motion)
    raw = b.build(content)
    frag = raw if args.camel else wechat_normalize(raw)

    bs = Builder(theme, choreo, layout=layout, motion=motion, static=True)
    raw_static = bs.build(content)
    static_frag = raw_static if args.camel else wechat_normalize(raw_static)

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(frag, encoding="utf-8")
    (out.parent / "静态兜底版.html").write_text(static_frag, encoding="utf-8")

    title = recipe.get("name") or content.get("name", "SVG 动画")
    st = b.stats()
    (out.parent / "预览.html").write_text(preview_page(frag, title, st), encoding="utf-8")
    (out.parent / "导入助手.html").write_text(
        importer_page(frag, static_frag, title, st), encoding="utf-8")
    (out.parent / "注入代码.txt").write_text(build_inject_js(frag), encoding="utf-8")

    print("生成完成")
    for k, v in st.items():
        print("  %s: %s" % (k, v))
    print("  正文片段(微信形态): %s (%s 字符)" % (out, len(frag)))
    print("  静态兜底版        : %s (%s 字符)" % (out.parent / "静态兜底版.html", len(static_frag)))
    print("  预览页            : %s" % (out.parent / "预览.html"))
    print("  导入助手          : %s" % (out.parent / "导入助手.html"))
    print("  Console 注入代码  : %s" % (out.parent / "注入代码.txt"))
    print("  提醒 1：绝不能用「复制富文本 → Ctrl+V」，必须用 F12 Edit as HTML / Console 注入 / Snippets。")
    print("  提醒 2：Console 若弹 Self-XSS 黄色警告，先手打 allow pasting 回车解锁，再粘贴代码；该口令不是 JS，别单独执行。")
    print("  提醒 3：注入前先在 Elements 面板点一下正文，脚本靠 $0 锚定；写错容器会自动回滚。")


if __name__ == "__main__":
    main()
