#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""可选工具：在浏览器里实测所有 <text> 有没有越出 1080 画布右边界。

改过文案、边距、density、字号之后跑一次，比截图抽查可靠得多。
需要本机装有 Chrome / Chromium；没装就直接跳过（不影响出片）。

    python3 check_overflow.py /绝对路径/SVG动画正文.html
"""
import html
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

CANDIDATES = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
]


def find_chrome():
    for p in CANDIDATES:
        if Path(p).is_file():
            return p
    for name in ("google-chrome", "chromium", "chromium-browser", "chrome",
                 "microsoft-edge"):
        p = shutil.which(name)
        if p:
            return p
    return None


def main():
    frag_path = (Path(sys.argv[1]) if len(sys.argv) > 1
                 else Path(__file__).resolve().parent / ".." / "输出" / "SVG动画正文.html")
    frag_path = frag_path.resolve()
    if not frag_path.is_file():
        print("找不到正文文件：%s" % frag_path)
        return 2
    chrome = find_chrome()
    if not chrome:
        print("未找到 Chrome / Chromium，跳过越界检查（这不影响生成与导入）")
        return 0

    frag = frag_path.read_text(encoding="utf-8")
    page = f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<title>overflow check</title><style>body{{margin:0;background:#888}}
.phone{{width:390px;margin:0 auto}}</style></head><body>
<div class="phone">{frag}</div><pre id="result">pending</pre><script>
const svgs=[...document.querySelectorAll('svg')];
svgs.forEach(s=>{{try{{s.pauseAnimations();s.setCurrentTime(999);}}catch(e){{}}}});
const svg=svgs[0], box=svg.getBoundingClientRect(), lines=[];
let bad=0,total=0;
document.querySelectorAll('svg text').forEach(function(el){{
  total++; const r=el.getBoundingClientRect(); if(r.width===0) return;
  const dl=box.left-r.left, dr=r.right-box.right;
  if(dl>1||dr>1){{ bad++;
    if(lines.length<20) lines.push((el.textContent||'').trim().slice(0,24)
      +'  左溢出='+dl.toFixed(1)+'px  右溢出='+dr.toFixed(1)+'px'); }}
}});
lines.unshift('文本总数 = '+total);
lines.unshift('越界文本数 = '+bad);
lines.unshift('画布边界 = '+box.left.toFixed(1)+' .. '+box.right.toFixed(1));
lines.push(bad===0?'结论: PASS 全篇文字均在画布内':'结论: FAIL 存在裁切');
document.getElementById('result').textContent=lines.join('\\n');
</script></body></html>'''

    with tempfile.TemporaryDirectory(prefix="wb-svg-overflow-") as tmp:
        t = Path(tmp)
        p = t / "page.html"
        p.write_text(page, encoding="utf-8")
        cmd = [chrome, "--headless=new", "--disable-gpu", "--no-sandbox",
               "--hide-scrollbars", "--no-first-run", "--disable-extensions",
               "--disable-background-networking", "--window-size=430,1700",
               "--virtual-time-budget=1800", f"--user-data-dir={t / 'profile'}",
               "--dump-dom", p.resolve().as_uri()]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
        except Exception as e:
            print("浏览器检查未能完成：%s（不影响生成）" % e)
            return 0
        m = re.search(r'<pre id="result">(.*?)</pre>', r.stdout, re.S)
        text = html.unescape(m.group(1)) if m else "NO RESULT"
    print("检测文件: %s" % frag_path.name)
    print(text)
    return 0 if "结论: PASS" in text else 1


if __name__ == "__main__":
    sys.exit(main())
