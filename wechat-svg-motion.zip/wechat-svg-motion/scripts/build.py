#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一键出片：给一篇文章 + 一个场景，产出可直接导入公众号的 SVG 动画全套文件。

    python3 build.py --article 文章.md --scene product --out ./输出/我的文章
    python3 build.py --article 文章.md --scene science --theme plum-night --motion telegraph
    python3 build.py --content 内容.json --scene brand --out ./输出/品牌篇

输出目录里会有：
    SVG动画正文.html       微信净化形态的正文源码（F12 / Console 注入用）
    静态兜底版.html        动画被平台清空时仍可完整阅读的保险版
    预览.html              本地手机宽度预览
    导入助手.html          带复制按钮的注入工具 + 完整图文教程
    注入代码.txt           Console / Snippets 注入代码
    导入教程.md / .html    可单独发给同事的导入说明
    内容.json              本次分屏文案，改这里再 --content 重跑即可
    校验结果.txt           微信白名单兼容性自检
    本次生成说明.md        参数、屏型、下一步
"""
import argparse
import html
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent
REF = SKILL / "references"
TUTORIAL_MD = REF / "导入公众号编辑器.md"

MAIN_NAME = "SVG动画正文.html"


def run(script, args, capture=True, check=True):
    cmd = [sys.executable, str(HERE / script)] + [str(a) for a in args]
    p = subprocess.run(cmd, cwd=str(HERE), capture_output=capture, text=True)
    out = (p.stdout or "") + (p.stderr or "")
    if check and p.returncode != 0:
        print(out, file=sys.stderr)
        raise SystemExit("[FAIL] %s 执行失败" % script)
    return out


def md_inline(s):
    s = html.escape(s)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', s)
    return s


def md_to_html(md, title):
    """把教程 md 转成一份可离线打开的清爽 HTML（单一真相仍是那份 md）。"""
    out, in_code, in_list, para = [], False, False, []
    css = """
 body{margin:0;background:#f4f6f9;color:#1f2937;font:15px/1.9 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif}
 .wrap{max-width:780px;margin:0 auto;padding:32px 22px 80px}
 h1{font-size:26px;margin:0 0 22px;color:#0f2d52;letter-spacing:1px}
 h2{font-size:19px;margin:34px 0 12px;padding-left:12px;border-left:4px solid #0b4a86;color:#0b4a86}
 h3{font-size:16px;margin:22px 0 8px;color:#243b55}
 p{margin:10px 0}
 ol,ul{padding-left:24px;margin:10px 0}
 li{margin:6px 0}
 code{background:#eef2f8;border:1px solid #dbe3ee;border-radius:4px;padding:1px 5px;font:13px Menlo,Consolas,monospace;color:#8a4b00}
 pre{background:#101a26;color:#e6edf5;border-radius:10px;padding:14px 16px;overflow:auto;font:13px/1.7 Menlo,Consolas,monospace}
 pre code{background:none;border:0;color:inherit;padding:0}
 blockquote{margin:14px 0;padding:12px 16px;background:#fff8e6;border:1px solid #e6c268;border-radius:10px;color:#6b4a06}
 blockquote.warn{background:#fff1ee;border-color:#e39b8c;color:#7a2b18}
 .foot{margin-top:40px;padding-top:16px;border-top:1px solid #dbe3ee;color:#7b8794;font-size:13px}
"""

    def flush_para():
        nonlocal para
        if para:
            out.append("<p>" + md_inline(" ".join(para)) + "</p>")
            para = []

    def close_list():
        nonlocal in_list
        if in_list:
            out.append("</ol>" if in_list == "ol" else "</ul>")
            in_list = False

    for line in md.split("\n"):
        s = line.rstrip()
        if s.startswith("```"):
            flush_para()
            close_list()
            out.append("<pre><code>" if not in_code else "</code></pre>")
            in_code = not in_code
            continue
        if in_code:
            out.append(html.escape(s) + "\n")
            continue
        if not s.strip():
            flush_para()
            close_list()
            continue
        m = re.match(r"^(#{1,3})\s+(.+)$", s)
        if m:
            flush_para()
            close_list()
            lv = len(m.group(1))
            out.append("<h%d>%s</h%d>" % (lv, md_inline(m.group(2)), lv))
            continue
        if s.startswith(">"):
            flush_para()
            close_list()
            body = md_inline(s.lstrip("> ").strip())
            cls = "warn" if ("⚠" in body or "不要" in body or "禁止" in body) else ""
            out.append('<blockquote class="%s">%s</blockquote>' % (cls, body))
            continue
        m = re.match(r"^\s*(\d+)[.、)]\s+(.+)$", s)
        if m:
            flush_para()
            if in_list != "ol":
                close_list()
                out.append("<ol>")
                in_list = "ol"
            out.append("<li>" + md_inline(m.group(2)) + "</li>")
            continue
        m = re.match(r"^\s*[-*]\s+(.+)$", s)
        if m:
            flush_para()
            if in_list != "ul":
                close_list()
                out.append("<ul>")
                in_list = "ul"
            out.append("<li>" + md_inline(m.group(1)) + "</li>")
            continue
        para.append(s.strip())
    flush_para()
    close_list()
    if in_code:
        out.append("</code></pre>")
    return ("<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>%s</title><style>%s</style></head><body><div class=\"wrap\">"
            "%s<div class=\"foot\">本页由 wechat-svg-motion 生成 · 与「导入助手.html」内容一致</div>"
            "</div></body></html>" % (html.escape(title), css, "\n".join(out)))


def main():
    ap = argparse.ArgumentParser(
        description="公众号 SVG 动画文章一键生成（文章 -> 分屏 -> 渲染 -> 教程 -> 校验）")
    ap.add_argument("--article", help="文章文件（.md / .txt / .html）")
    ap.add_argument("--text", help="直接粘贴的文章全文")
    ap.add_argument("--content", help="已有的内容 JSON（跳过自动切分）")
    ap.add_argument("--scene", default="general", help="题材场景：general/product/science/industry/story/data/event/howto/brand")
    ap.add_argument("--theme", default=None, help="覆盖配色，如 blueblack / paper-editorial / clay-warm")
    ap.add_argument("--motion", default=None, help="覆盖动效：quiet / writing / page-turn / cadence / telegraph")
    ap.add_argument("--layout", default=None, help="覆盖版式：manual / magazine / dossier")
    ap.add_argument("--recipe", default=None, help="一键配方名，优先级高于场景")
    ap.add_argument("--title", default="", help="覆盖文章标题")
    ap.add_argument("--max-screens", type=int, default=9, help="最多几屏（4-12）")
    ap.add_argument("--out", default=None, help="输出目录；默认 ./输出/<文章名>_<场景>")
    ap.add_argument("--no-validate", action="store_true", help="跳过兼容性校验（不推荐）")
    args = ap.parse_args()

    if not (args.article or args.text or args.content):
        ap.error("必须给 --article / --text / --content 之一")

    if args.article:
        art_name = Path(args.article).stem
    elif args.title.strip():
        art_name = args.title.strip()[:12]
    elif args.content:
        art_name = Path(args.content).stem
    else:
        art_name = "公众号文章"
    out_dir = Path(args.out).resolve() if args.out else (
        Path.cwd() / "输出" / ("%s_%s" % (art_name, args.scene))).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    content_p = out_dir / "内容.json"

    print("[1/5] 文章 -> 分屏内容")
    if args.content:
        src = Path(args.content).resolve()
        if src != content_p:
            shutil.copy2(src, content_p)
        print("  使用已有内容 JSON：%s" % src)
    else:
        a = ["--scene", args.scene, "--title", args.title,
             "--max-screens", args.max_screens, "--out", content_p]
        if args.article:
            a += ["--article", str(Path(args.article).resolve())]
        else:
            a += ["--text", args.text]
        print(run("article_to_content.py", a).strip())

    content = json.loads(content_p.read_text(encoding="utf-8"))
    scenes = content.get("scenes", [])
    if not scenes:
        raise SystemExit("[FAIL] 内容 JSON 里没有 scenes")

    print("[2/5] 渲染 SVG 动画正文与交付页")
    g = ["--scene", args.scene, "--content", content_p,
         "--out", out_dir / MAIN_NAME]
    for flag, val in (("--theme", args.theme), ("--motion", args.motion),
                      ("--layout", args.layout), ("--recipe", args.recipe)):
        if val:
            g += [flag, val]
    gen_out = run("generator.py", g)
    stats = {}
    for line in gen_out.splitlines():
        if ":" in line and line.startswith("  "):
            k, v = line.strip().split(":", 1)
            stats[k.strip()] = v.strip()

    print("[3/5] 附导入教程与使用说明")
    if TUTORIAL_MD.is_file():
        md = TUTORIAL_MD.read_text(encoding="utf-8")
        (out_dir / "导入教程.md").write_text(md, encoding="utf-8")
        (out_dir / "导入教程.html").write_text(
            md_to_html(md, "导入微信公众号后台 · 图文教程"), encoding="utf-8")
    else:
        print("  警告：找不到 references/导入公众号编辑器.md，教程文件未生成", file=sys.stderr)

    used = {
        "配色": args.theme or "场景推荐值",
        "动效": args.motion or "场景推荐值",
        "版式": args.layout or "场景推荐值",
    }
    if args.recipe:
        used["配方"] = args.recipe
    lines = [
        "# 本次生成说明", "",
        "- 文章：%s" % (args.article or args.content or "直接粘贴的文本"),
        "- 场景：%s%s" % (args.scene, "（组合已被 --recipe 覆盖）" if args.recipe else ""),
        "- 用户覆盖：" + " / ".join("%s=%s" % (k, v) for k, v in used.items()),
        "- 屏数：%d" % len(scenes),
        "- 屏型：" + " → ".join(s.get("type", "?") for s in scenes),
        "- 自动播完约：%s 秒" % stats.get("自动播完约", "—"),
        "- 动画元素：%s 个" % stats.get("动画元素总数", "—"),
        "", "## 文件清单", "",
        "- `SVG动画正文.html`：导入微信的正文源码（必须用注入方式，不能 Ctrl+V 粘贴）",
        "- `静态兜底版.html`：动画被平台清空时的保险版，内容完整可读",
        "- `预览.html`：本地手机宽度预览，刷新可重播",
        "- `导入助手.html`：五个复制按钮 + 完整导入步骤（首选看这个）",
        "- `注入代码.txt`：Console / Snippets 注入代码",
        "- `导入教程.md` / `导入教程.html`：可以单独发给同事的图文教程",
        "- `内容.json`：本次分屏文案。改完文案后用 `build.py --content 内容.json` 重新生成即可",
        "- `校验结果.txt`：微信白名单兼容性自检结果",
        "", "## 下一步", "",
        "1. 双击打开 `预览.html`，从头到尾看一遍节奏与文字有没有越界。",
        "2. 打开 `导入助手.html`，按方式 1（F12 Edit as HTML）或方式 2（Console 注入）操作。",
        "3. 在公众号后台「保存为草稿」，再用手机预览判定，编辑器里画面静止是正常的。",
        "4. 手机上若不动，先跑助手里的自检代码；仍不行就换静态兜底版。",
        "", "> 判定只认「保存草稿 → 手机预览」。后台编辑器不播 SMIL，不要在编辑页反复点测试。",
    ]
    (out_dir / "本次生成说明.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("[4/5] 微信白名单兼容性自检")
    if args.no_validate:
        (out_dir / "校验结果.txt").write_text("已按 --no-validate 跳过\n", encoding="utf-8")
        ok = True
    else:
        # 校验失败时也要把结果写进文件，方便用户直接看 校验结果.txt 排障
        v = run("validate.py", [out_dir / MAIN_NAME, out_dir / "静态兜底版.html"],
                check=False)
        (out_dir / "校验结果.txt").write_text(v, encoding="utf-8")
        ok = "[PASS]" in v
        print("  " + ("PASS - 代码层符合微信白名单与净化形态" if ok else "FAIL - 见 校验结果.txt"))

    print("[5/5] 完成")
    print("  输出目录：%s" % out_dir)
    print("  先看 预览.html，再打开 导入助手.html 按步骤导入。")
    print("  教程：导入教程.html（可直接发给同事）")
    if not ok:
        raise SystemExit("[FAIL] 兼容性校验未通过，请查看 校验结果.txt")
    return 0


if __name__ == "__main__":
    main()
