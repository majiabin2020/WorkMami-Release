#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""成品兼容性自检：每次生成后跑一遍，卡住微信编辑器会过滤的写法。

同时校验「微信净化形态」：标签名/属性名全小写、tspan 带 leaf、无 <line>、
无自闭合、动画 attributeName 与 animateTransform type 都在官方白名单内。
依据见 ../references/设计规范与兼容白名单.md。

用法：python3 validate.py <正文.html> [静态兜底版.html]
"""
import re
import sys
import collections
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
# 不做任何「默认成品路径」假设：skill 是自包含的，静态兜底版一律取正文同目录。
DEFAULT = None
STATIC_DEFAULT = None

# 《融媒体SVG交互设计技术规范》T/CASME 1609—2024 / 微信 SVG AttributeName 白名单
ATTR_WHITELIST = {
    "x", "y", "width", "height", "opacity", "d", "points",
    "stroke-width", "stroke-linecap", "stroke-dashoffset", "fill",
    "visibility", "transform", "path",
}
TRANSFORM_TYPES = {"translate", "scale", "rotate", "skewx", "skewy"}

FORBIDDEN = [
    (r"<script", "出现 <script>（微信一律过滤）"),
    (r"<style", "出现 <style> 标签（微信一律过滤，只能内联 style=\"\"）"),
    (r"@keyframes|@media|animation\s*:", "出现 CSS 规则（微信不支持 CSS 动画）"),
    (r"var\(--|calc\(", "出现 CSS 变量 / calc()（微信不认）"),
    (r"\sid\s*=", "出现 id 属性（微信会清掉，且不支持 id.click）"),
    (r"\sclass\s*=", "出现 class 属性（微信一律过滤）"),
    (r"<defs\b|<marker\b|<use\b|<embed\b", "出现 defs/marker/use/embed（微信禁用）"),
    (r"xlink:href|\shref\s*=", "出现 href 引用（微信会清空图片地址）"),
    (r"clipPath|clip-path|linearGradient|radialGradient", "出现渐变/裁剪引用（微信禁用）"),
    (r"foreignObject|foreignobject", "出现 foreignObject（保留性不稳定）"),
    (r"begin=\"[^\"]*\.click", "出现 id.click 引用触发（微信不支持，只能用 begin=\"click\"）"),
    (r"<image\b", "出现外部图片（微信会转存，且需图床地址）"),
    (r"<line\b", "出现 <line>（微信客户端会剥离其内动画，一律改用 <path>/<rect>）"),
    (r"/>", "出现自闭合标签（微信净化后会展开，统一输出显式闭合）"),
]


class Pair(HTMLParser):
    VOID = {"rect", "circle", "line", "path", "animate", "animatetransform",
            "set", "use", "br", "img", "mp-style-type", "hr", "input"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.errors = []
        self.tags = collections.Counter()

    def handle_starttag(self, tag, attrs):
        self.tags[tag.lower()] += 1
        if tag.lower() not in self.VOID:
            self.stack.append(tag.lower())

    def handle_startendtag(self, tag, attrs):
        self.tags[tag.lower()] += 1

    def handle_endtag(self, tag):
        t = tag.lower()
        if t in self.VOID:
            return
        if not self.stack:
            self.errors.append(f"多余的闭合标签 </{t}>")
            return
        if self.stack[-1] != t:
            self.errors.append(f"标签不配对: 期望 </{self.stack[-1]}>，实际 </{t}>")
            if t in self.stack:
                while self.stack and self.stack.pop() != t:
                    pass
        else:
            self.stack.pop()


def main():
    if len(sys.argv) < 2:
        print("用法：python3 validate.py <正文.html> [静态兜底版.html]")
        sys.exit(2)
    p = Path(sys.argv[1])
    s = p.read_text(encoding="utf-8")
    print(f"校验文件: {p}  ({len(s):,} 字符)")
    fails = []

    for pat, msg in FORBIDDEN:
        if re.search(pat, s, re.I):
            fails.append(msg)

    pair = Pair()
    pair.feed(s)
    if pair.errors:
        fails.append("标签配对问题: " + "; ".join(pair.errors[:5]))
    if pair.stack:
        fails.append(f"未闭合标签: {pair.stack[:5]}")

    if s.count('xmlns="http://www.w3.org/2000/svg"') < 2:
        fails.append("主画布 / 撑高 SVG 缺少 xmlns")
    if 'overflow:hidden' not in s or 'height:0;overflow:visible' not in s:
        fails.append("缺少三层容器（外层裁剪 + 内层零高溢出）")

    # 动画参数合法性
    anims = re.findall(r'<(animate|animatetransform|set|animatemotion)\b([^>]*)>', s, re.I)
    bad = []
    for tag, raw in anims:
        a = dict((k.lower(), v) for k, v in re.findall(r'([\w:-]+)="([^"]*)"', raw))
        if not a.get("begin"):
            bad.append(f"{tag} 缺 begin")
        if tag.lower() != "set" and not a.get("dur"):
            bad.append(f"{tag} 缺 dur")
        an = a.get("attributename", "")
        if an and an not in ATTR_WHITELIST:
            bad.append(f"attributeName 超出微信白名单: {an}")
        if tag.lower() == "animatetransform" and a.get("type", "").lower() not in TRANSFORM_TYPES:
            bad.append(f"animateTransform type 超出白名单: {a.get('type')}")
        vals = a.get("values", "")
        kt = a.get("keytimes", "")
        ks = a.get("keysplines", "")
        if vals and kt and len(kt.split(";")) != len(vals.split(";")):
            bad.append(f"keyTimes 与 values 段数不符: {vals} / {kt}")
        if ks and len(ks.split(";")) != len(vals.split(";")) - 1:
            bad.append(f"keySplines 段数不符: {vals} / {ks}")
        if a.get("calcmode") == "spline" and not ks:
            bad.append("calcMode=spline 但未给 keySplines")
    if bad:
        fails.append("动画参数: " + "; ".join(bad[:6]))

    # 结构数量
    m = re.search(r'viewbox="0 0 1080 (\d+)"', s, re.I)
    H = int(m.group(1)) if m else 0
    width_anims = len(re.findall(r'attributename="width"', s, re.I))
    screens = H // 1920
    if width_anims != screens - 1:
        fails.append(f"撑高动画数({width_anims}) 应等于 段数-1({screens - 1})")

    # ---- 微信净化形态（与线上可播放的原文 DOM 一致）----
    camel_tags = sorted({t for t in re.findall(r'<\s*([A-Za-z][\w:-]*)', s) if t != t.lower()})
    camel_attrs = sorted({a for a in re.findall(r'\s([A-Za-z][\w:-]*)=', s) if a != a.lower()})
    if camel_tags:
        fails.append(f"标签名仍是驼峰（微信会小写化）: {camel_tags}")
    if camel_attrs:
        fails.append(f"属性名仍是驼峰（微信会小写化）: {camel_attrs}")
    tspans = re.findall(r'<tspan\b[^>]*>', s)
    no_leaf = sum(1 for t in tspans if "leaf=" not in t)
    if no_leaf:
        fails.append(f"{no_leaf} 个 <tspan> 缺 leaf=\"\"（文字可能被当叶子节点清洗）")
    # 电报硬切动效靠 <set visibility> 入场，全篇本来就没有 animateTransform；
    # 只有「既没有 transform 也没有 set」才算编排不完整。
    if (not re.search(r'<animatetransform\b', s, re.I)
            and not re.search(r'<set\b', s, re.I)):
        fails.append("缺少 animateTransform / set（编排不完整）")

    # ---- 静态兜底版 ----
    p2 = Path(sys.argv[2]) if len(sys.argv) > 2 else (p.parent / "静态兜底版.html")
    static_ok = "未生成"
    if p2.exists():
        ss = p2.read_text(encoding="utf-8")
        n_anim = len(re.findall(r'<(animate|animatetransform|set|animatemotion)\b', ss, re.I))
        n_hidden = ss.count('opacity="0"')
        w = re.search(r'<svg[^>]*width="(\d+%)"', ss)
        static_ok = (f"动画标签={n_anim}  隐藏基态={n_hidden}  撑高宽度={w.group(1) if w else '?'}"
                     f"  ({len(ss)} 字符)")
        if n_anim or n_hidden or not w:
            fails.append("静态兜底版不合格：应无动画标签、无 opacity=0、撑高 SVG 需给最终宽度")

    # ---- 导入说明：Chrome Self-XSS 解锁提示不能丢（用户实测卡在这一步）----
    helper = p.parent / "导入助手.html"
    inject = p.parent / "注入代码.txt"
    guide_ok = "未生成"
    if helper.exists() and inject.exists():
        hs = helper.read_text(encoding="utf-8")
        js = inject.read_text(encoding="utf-8")
        need = ["allow pasting", "Snippets", "Self-XSS", "Unexpected identifier",
                "先在 Elements", "⑤ 复制清理代码", "已自动回滚"]
        need_js = ["allow pasting", "Unexpected identifier",
                   "wbPick", "wbTitleLike", "wbRoot",
                   "已自动回滚", "__wbCleanStray", "__wbUndo"]
        miss = [k for k in need if k not in hs]
        miss_js = [k for k in need_js if k not in js]
        guide_ok = (f"导入说明齐全={not miss}  注入定位守卫齐全={not miss_js}  "
                    f"清理按钮={'const CLEAN' in hs}")
        if miss:
            fails.append(f"导入助手缺少 Console 解锁 / 正文定位 / 清理说明: {miss}")
        if miss_js:
            fails.append(f"注入代码.txt 缺少正文定位或回滚守卫: {miss_js}")
        if "const CLEAN" not in hs:
            fails.append("导入助手缺少清理代码常量")
    else:
        guide_ok = "缺失（导入助手或注入代码未生成）"
        fails.append("缺少导入助手.html 或 注入代码.txt")

    print("\n--- 统计 ---")
    print(f"画布高度: {H}  段数: {screens}  展开动画: {width_anims}")
    print(f"动画元素: {len(anims)}  标签分布: {dict(pair.tags.most_common(10))}")
    attr = collections.Counter(a.get("attributename", "") for _, a in
                               [(t, dict((k.lower(), v) for k, v in
                                         re.findall(r'([\w:-]+)="([^"]*)"', raw)))
                                for t, raw in anims])
    print(f"动画属性: {dict(attr)}")
    tr = collections.Counter(
        a.get("type", "") for _, a in
        [(t, dict((k.lower(), v) for k, v in re.findall(r'([\w:-]+)="([^"]*)"', raw)))
         for t, raw in anims if t.lower() == "animatetransform"])
    print(f"transform 类型: {dict(tr)}")
    print(f"点击+时间双触发: {len(re.findall(r'begin=\"click', s))}")
    print(f"无限循环: {len(re.findall(r'repeatcount=\"indefinite\"', s, re.I))}")
    print(f"微信形态: 标签/属性全小写={not camel_tags and not camel_attrs}  "
          f"tspan leaf 覆盖={len(tspans) - no_leaf}/{len(tspans)}  <line>=0")
    print(f"静态兜底版: {static_ok}")
    print(f"导入说明  : {guide_ok}")

    print("\n--- 结论 ---")
    if fails:
        for f in fails:
            print("  [FAIL]", f)
        sys.exit(1)
    print("  [PASS] 标签/属性/动画参数均符合微信白名单与净化形态。")
    print("  重要：本脚本只校验代码层。公众号后台没有「导入源码」按钮，")
    print("        且【复制富文本 → Ctrl+V 会剥离全部 animate 标签】，")
    print("        必须用 F12 Edit as HTML / Console 注入 / Snippets 代码段，保存草稿后用手机预览判定。")
    print("        Console 若弹 Self-XSS 黄色警告：先手打 allow pasting 回车解锁，再粘贴代码；该口令不是 JS，单独执行会报 Unexpected identifier 'pasting'。")


if __name__ == "__main__":
    main()
