#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把一篇公众号文章（md / txt / html / 直接粘贴的文本）切成结构化分屏内容 JSON。

核心原则：**只搬运原文，不编造事实**。每一种屏型都从原文里找得到素材，
找不到就跳过那一屏，绝不塞占位数据；结构性引导语（如「点一下也能接着播」）
属于交互提示，不属于内容。生成的 JSON 仍可交给 agent 手工润色。

解析按原文小节分组：小标题跟它下面的段落、列表项是绑在一起的，
所以「三个毛病」那组列表不会跑到「四步就能改」那一屏去。
派生型屏（数字 / 问答 / 时间线 / 对照）用到的段落会被标记，
正文屏优先取没被用过的段落，避免同一段话在两屏里重复出现。

用法：
    python3 article_to_content.py --article 文章.md --scene product --out 输出/内容.json
    python3 article_to_content.py --text "标题\n\n正文..." --scene science --out 内容.json

内容 JSON 的完整字段说明见 ../references/内容结构说明.md。
"""
import argparse
import html as htmllib
import json
import re
from html.parser import HTMLParser
from pathlib import Path

HERE = Path(__file__).resolve().parent
PRESETS = HERE / "presets"

BLOCK_TAGS = {"p", "div", "section", "article", "br", "li", "h1", "h2", "h3",
              "h4", "h5", "h6", "blockquote", "tr", "td"}
SKIP_TAGS = {"script", "style", "noscript", "svg"}


class ArticleParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in SKIP_TAGS:
            self.skip += 1
        if tag in BLOCK_TAGS:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in SKIP_TAGS and self.skip:
            self.skip -= 1
        if tag in BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def html_to_text(raw):
    p = ArticleParser()
    p.feed(raw)
    return "".join(p.parts)


def clean(s):
    s = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", s)
    s = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", s)
    s = re.sub(r"[*_`~>#]+", "", s)
    s = re.sub(r"&nbsp;|&#160;", " ", s)
    s = htmllib.unescape(s)
    return re.sub(r"[ \t]+", " ", s).strip()


def split_sentences(text):
    return [p.strip() for p in re.split(r"(?<=[。！？；!?;])", text) if p.strip()]


def cut(s, n=24):
    """按句子边界收短文本，不在半句话中间硬砍。"""
    s = clean(s)
    if len(s) <= n:
        return s
    out = ""
    for one in split_sentences(s):
        if len(out) + len(one) > n:
            break
        out += one
    return out or s[:n]


def parse_article(raw, title_override=""):
    """返回 标题 / 小节 / 扁平段落 / 扁平列表 / 引用 / 小标题 / 段落->小标题映射。"""
    sections = [{"head": "", "paras": [], "items": [], "quotes": []}]
    cur = sections[0]
    buf = ""

    def flush():
        nonlocal buf
        t = clean(buf)
        if t:
            cur["paras"].append(t)
        buf = ""

    for line in raw.replace("\r\n", "\n").split("\n"):
        s = line.strip()
        if not s:
            flush()
            continue
        if re.match(r"^!\[[^\]]*\]\([^)]*\)$", s):
            continue
        m = re.match(r"^(#{1,6})\s*(.+)$", s)
        if m:
            flush()
            t = clean(m.group(2))
            if len(m.group(1)) >= 2 and t:
                cur = {"head": t, "paras": [], "items": [], "quotes": []}
                sections.append(cur)
            continue
        if s.startswith(">"):
            flush()
            t = clean(s)
            if t:
                cur["quotes"].append(t)
            continue
        m = re.match(r"^(?:[-*•]\s+|\d+[.、)]\s*|第[一二三四五六七八九十]+步[:：]?\s*)(.+)$", s)
        if m:
            flush()
            t = clean(m.group(1))
            if t:
                cur["items"].append(t)
            continue
        buf += s
        if len(buf) >= 100:
            flush()
    flush()

    title = title_override.strip()
    if not title:
        m = re.search(r"^#\s+(.+)$", raw, re.M)
        if m:
            title = clean(m.group(1))
    if not title:
        for sec in sections:
            for p in sec["paras"]:
                if len(p) >= 4:
                    title = cut(p, 18)
                    break
            if title:
                break
    if not title:
        title = "一篇值得慢慢看的文章"
    # 首段若就是标题，不再重复排进正文
    if sections[0]["paras"] and clean(sections[0]["paras"][0]) == clean(title):
        sections[0]["paras"].pop(0)

    flat_paras = [p for sec in sections for p in sec["paras"]]
    flat_items = [t for sec in sections for t in sec["items"]]
    flat_quotes = [q for sec in sections for q in sec["quotes"]]
    flat_heads = [sec["head"] for sec in sections if sec["head"]]
    para_head = {p: sec["head"] for sec in sections for p in sec["paras"]}
    return title, sections, flat_paras, flat_items, flat_quotes, flat_heads, para_head


NUM_RE = re.compile(
    r"(?<![\w])([0-9]+(?:\.[0-9]+)?)\s?"
    r"(%|％|亿|万|千|人次|人|次|个|小时|分钟|天|年|月|日|元|块|g|kg|km|米|岁|倍|条|家|款|台|秒|s|ms|G|M|K|W|px|字|屏|步)")
TIME_RE = re.compile(
    r"(\d{4}\s*年|\d{1,2}\s*月\s*\d{1,2}\s*日|\d{1,2}[:：]\d{2}|"
    r"[上中下]午|晚[上间]|周[一二三四五六日天]|第[一二三四]季度)")
STEP_WORDS = ("首先", "先", "第一步", "接着", "然后", "再", "其次", "最后", "第二步", "第三步")


def find_numbers(paras, items, limit=3):
    out, seen, used = [], set(), []
    for text in paras + items:
        for m in NUM_RE.finditer(text):
            raw = m.group(0)
            val = (m.group(1) + m.group(2)).strip()
            if val in seen:
                continue
            seen.add(val)
            sent = next((s for s in split_sentences(text) if m.group(1) in s), text)
            pos = sent.find(m.group(1))
            prefix = clean(sent[:pos]) if pos >= 0 else ""
            lab = (prefix[-10:] if len(prefix) >= 3
                   else cut(clean(sent.replace(raw, "")), 10)) or "原文数据"
            out.append([val, lab, "原文数据"])
            if text in paras and text not in used:
                used.append(text)
            if len(out) >= limit:
                return out, used
    return out, used


def find_qa(paras, items, limit=2):
    out, used = [], []
    seq = paras + items
    for i, p in enumerate(seq):
        ss = split_sentences(p)
        for j, s in enumerate(ss):
            if not (s.endswith(("？", "?")) and 4 <= len(s) <= 40):
                continue
            after = ss[j + 1] if j + 1 < len(ss) else (
                cut(seq[i + 1], 60) if i + 1 < len(seq) else "")
            if after and len(after) >= 6:
                out.append([cut(s, 20), cut(after, 56)])
                if p in paras and p not in used:
                    used.append(p)
            if len(out) >= limit:
                return out, used
    return out, used


def find_timeline(paras, items, limit=4):
    out, used = [], []
    for text in paras + items:
        for s in split_sentences(text):
            m = TIME_RE.search(s)
            if not m:
                continue
            body = clean(s.replace(m.group(0), "", 1))
            out.append([clean(m.group(0)), cut(body, 16) or "原文记载", cut(body, 22)])
            if text in paras and text not in used:
                used.append(text)
            if len(out) >= limit:
                return out, used
    return out, used


def find_compare(paras, items):
    old, new, used = [], [], []
    for text in paras + items:
        for s in split_sentences(text):
            s = clean(s)
            if len(s) < 6:
                continue
            if re.search(r"以前|过去|从前|原来|以往|传统上", s) and len(old) < 4:
                old.append(cut(s, 14))
                if text in paras and text not in used:
                    used.append(text)
            if re.search(r"现在|如今|后来|这次|改成|改为|变成|于是", s) and len(new) < 4:
                new.append(cut(s, 14))
                if text in paras and text not in used:
                    used.append(text)
    if old and new:
        return ({"left": {"title": "从前", "tag": "原文里的旧做法", "points": old[:4]},
                 "right": {"title": "后来", "tag": "原文里的新做法", "points": new[:4]}},
                used)
    return None, used


def find_conclusion(paras):
    """从原文里摘一句结论，给「点击揭晓」用；绝不自己造结论。"""
    if not paras:
        return ""
    cands = []
    for p in paras:
        for s in split_sentences(p):
            if re.search(r"所以|于是|结果|结论|说到底|其实|这就是|可以看出|归根", s) \
                    and 8 <= len(s) <= 60:
                cands.append(cut(s, 24))
    if cands:
        return cands[-1]
    last = split_sentences(paras[-1])
    return cut(last[-1], 24) if last else cut(paras[-1], 24)


def find_steps(sections, paras):
    groups = [(sec["head"], sec["items"]) for sec in sections if sec["items"]]
    step_like = [g for g in groups
                 if re.search(r"步|流程|照着做|怎么改", g[0])
                 or any(t.lstrip().startswith(STEP_WORDS) for t in g[1])]
    src = step_like[0][1] if step_like else []
    rows = [[cut(t, 12), cut(t, 24)] for t in src[:5]]
    if len(rows) < 2:
        for text in paras:
            for s in split_sentences(text):
                if s.lstrip().startswith(STEP_WORDS) and len(s) >= 8:
                    body = re.sub(r"^(首先|第一步|第二步|第三步|接着|然后|其次|最后|先|再)[，,、:：]?\s*", "", s)
                    rows.append([cut(body, 12), cut(body, 24)])
                    if len(rows) >= 5:
                        break
            if len(rows) >= 5:
                break
    return rows[:5], []


def item_groups(sections):
    return [(sec["head"], sec["items"]) for sec in sections if sec["items"]]


def make_hero(title, paras, scene, numbers):
    sub = cut(paras[0], 22) if paras else ""
    return {
        "type": "hero",
        "glyph": scene.get("glyph", "orbit"),
        "glyph_label": scene.get("name", "").split(" / ")[0],
        "kicker": scene.get("kicker", "阅读 · 笔记"),
        "headline": cut(title, 16),
        "sub": sub,
        "note": "往下看，内容会自己一段段展开，点一下也能接着播",
        "stats": numbers[:3],
    }


def make_closing(title, paras, disclaimer):
    tail = split_sentences(paras[-1]) if paras else []
    cta = [cut(s, 10) for s in tail[:3] if s]
    return {
        "type": "closing",
        "kicker": "最后",
        "title": cut(paras[-1], 16) if paras else "就写到这儿",
        "logo": cut(title, 12),
        "footer": "原文整理 · SVG 动画版",
        "cta": cta,
        "disclaimer": disclaimer,
    }


def make_screen(typ, ctx):
    """按屏型从原文素材里取内容；取不到返回 None，由调用方跳过该屏。"""
    P, heads, used = ctx["paras"], ctx["heads"], ctx["used"]
    kicker = ctx["kicker"]

    def head_for(texts):
        # 只用「这一段原本属于哪个小节」，不猜下一个小标题，
        # 否则会出现标题写着甲节、内容却是乙节的错配。
        for t in texts:
            h = ctx["para_head"].get(t, "")
            if h and h not in ctx["consumed_heads"]:
                return h
        return "接着往下说"

    def take_conclusion():
        # 原文里摘出来的结论只给第一个需要的屏，避免几屏重复同一句
        return ctx["conclusions"].pop(0) if ctx["conclusions"] else ""

    if typ == "prose":
        order = ([p for p in P if p not in used]
                 + [p for p in P if p in used])
        picked, take = [], []
        for s in order:
            if len(take) >= 3:
                break
            if s in P:
                P.remove(s)
            picked.append(s)
            take.append(cut(s, 100))
        if not take:
            return None
        title = head_for(picked)
        ctx["consumed_heads"].add(title)   # 同一小节分到第二屏时不再重复标题
        return {"type": "prose", "kicker": kicker, "title": title,
                "paragraphs": take, "note": ""}
    if typ == "chapter":
        sec = next((s for s in ctx["sections"] if s["head"]), None)
        if not sec:
            return None
        sub = ""
        if sec["paras"]:
            raw = sec["paras"][0]
            sub = cut(raw, 60)
            if raw in P:
                P.remove(raw)
        ctx["consumed_heads"].add(sec["head"])
        return {"type": "chapter", "kicker": kicker, "title": sec["head"],
                "sub": sub, "note": ""}
    if typ == "list":
        groups = item_groups(ctx["sections"])
        step_like = [g for g in groups if re.search(r"步|流程|照着做|怎么改", g[0])]
        plain = [g for g in groups if g not in step_like]
        pick = plain[0] if plain else (groups[0] if groups else None)
        if pick:
            rows = [[cut(t, 12), cut(t, 22)] for t in pick[1][:5]]
            title = pick[0] or "原文里提到的几件事"
        else:
            rows = [[cut(t, 12), cut(t, 22)] for t in ctx["items"][:5]]
            title = head_for(ctx["items"][:5]) if ctx["items"] else "原文里提到的几件事"
        rows = [r for r in rows if r[0]]
        if not rows:
            return None
        return {"type": "list", "kicker": "几个要点", "title": title,
                "items": rows, "note": ""}
    if typ == "quote":
        q = ""
        if ctx["quotes"]:
            q = cut(ctx["quotes"].pop(0), 24)
        else:
            for p in list(P):
                for s in split_sentences(p):
                    if re.search(r"不是.{1,12}而是|其实|真正的|最重要的|说到底", s) and 8 <= len(s) <= 40:
                        q = cut(s, 24)
                        break
                if q:
                    break
        if not q:
            return None
        return {"type": "quote", "kicker": "原文一句", "quote": q,
                "source": "摘自原文", "note": ""}
    if typ == "numbers":
        if not ctx["numbers"]:
            return None
        return {"type": "numbers", "kicker": "先看数",
                "title": "原文里的几个数字",
                "items": ctx["numbers"][:4],
                "source": "数字与口径均来自原文，发布前请核对", "conclusion": take_conclusion()}
    if typ == "compare":
        if not ctx["compare"]:
            return None
        return {"type": "compare", "kicker": "两种做法",
                "title": "原文里的前后对照",
                "left": ctx["compare"]["left"], "right": ctx["compare"]["right"],
                "conclusion": take_conclusion()}
    if typ == "steps":
        if not ctx["steps"]:
            return None
        groups = item_groups(ctx["sections"])
        step_head = next((g[0] for g in groups
                          if re.search(r"步|流程|照着做|怎么改", g[0])), "")
        return {"type": "steps", "kicker": "照着做",
                "title": step_head or "原文里的步骤",
                "items": ctx["steps"][:5], "conclusion": take_conclusion()}
    if typ == "timeline":
        if not ctx["timeline"]:
            return None
        return {"type": "timeline", "kicker": "时间线",
                "title": "原文里的时间线",
                "items": ctx["timeline"][:5], "note": ""}
    if typ == "qa":
        if not ctx["qa"]:
            return None
        return {"type": "qa", "kicker": "常被问到",
                "title": "常被问到的几个问题",
                "items": ctx["qa"][:3]}
    return None


def build_content(raw, scene, title_override="", max_screens=9, disclaimer=None):
    (title, sections, paras, items, quotes, heads, para_head) = parse_article(
        raw, title_override)
    numbers, u1 = find_numbers(paras, items)
    qa, u2 = find_qa(paras, items)
    timeline, u3 = find_timeline(paras, items)
    compare, u4 = find_compare(paras, items)
    steps, u5 = find_steps(sections, paras)
    ctx = {
        "paras": list(paras), "items": list(items), "quotes": list(quotes),
        "heads": list(heads), "sections": sections, "para_head": para_head,
        "consumed_heads": set(),
        "used": set(u1 + u2 + u3 + u4 + u5),
        "numbers": numbers, "compare": compare, "steps": steps,
        "timeline": timeline, "qa": qa,
        "conclusions": [find_conclusion(paras)] if paras else [],
        "kicker": scene.get("kicker", "阅读 · 笔记"),
    }
    structure = [x for x in scene.get("structure", ["hero", "prose", "closing"])
                 if x not in ("hero", "closing")]
    scenes = [make_hero(title, paras, scene, numbers)]
    for typ in structure:
        if len(scenes) >= max_screens - 1:
            break
        sc = make_screen(typ, ctx)
        if sc:
            scenes.append(sc)
    while ctx["paras"] and len(scenes) < max_screens - 1:
        sc = make_screen("prose", ctx)
        if not sc:
            break
        scenes.append(sc)
    scenes.append(make_closing(
        title, paras,
        disclaimer or "内容与数据均来自原文，发布前请核对；动画效果以手机预览为准"))
    return {
        "name": title,
        "version": "3.0",
        "disclaimer": disclaimer or "内容与数据均来自原文，发布前请核对",
        "source_note": "由 article_to_content.py 从原文自动切分，未改写事实；可手工润色本文件后重新生成",
        "scenes": scenes,
    }, len("".join(ctx["paras"]))


def load_scene(name):
    p = PRESETS / ("scene.%s.json" % name)
    if not p.is_file():
        p = PRESETS / (str(name) + ".json")
    if not p.is_file():
        raise FileNotFoundError("找不到场景预设 %s，用 generator.py --list 看全部" % name)
    return json.loads(p.read_text(encoding="utf-8"))


def main():
    ap = argparse.ArgumentParser(description="公众号文章 -> SVG 分屏内容 JSON")
    ap.add_argument("--article", help="文章文件（.md / .txt / .html）")
    ap.add_argument("--text", help="直接粘贴的文章文本")
    ap.add_argument("--scene", default="general", help="题材场景预设名")
    ap.add_argument("--title", default="", help="覆盖文章标题")
    ap.add_argument("--max-screens", type=int, default=9, help="最多几屏（4-12）")
    ap.add_argument("--out", required=True, help="输出内容 JSON 路径")
    args = ap.parse_args()

    if not args.article and not args.text:
        ap.error("必须给 --article 或 --text")
    raw = args.text if args.text else Path(args.article).read_text(
        encoding="utf-8", errors="ignore")
    if args.article and Path(args.article).suffix.lower() in (".html", ".htm"):
        raw = html_to_text(raw)
    scene = load_scene(args.scene)
    content, left = build_content(raw, scene, args.title,
                                  max(4, min(12, args.max_screens)))
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(content, ensure_ascii=False, indent=2) + "\n",
                   encoding="utf-8")
    print("切分完成：%d 屏 → %s" % (len(content["scenes"]), out))
    print("  屏型：" + " / ".join(s["type"] for s in content["scenes"]))
    print("  标题：%s" % content["name"])
    if left:
        print("  注意：还有约 %d 字没排进去，可提高 --max-screens 或分上下篇" % left)


if __name__ == "__main__":
    main()
