---
name: wechat-svg-motion
description: 把一篇公众号文章一键做成可导入微信公众号后台的 SVG 交互动画长图（逐屏展开、点击揭晓、描边生长、打字机）。提供 9 种题材场景、8 套配色、5 套动效、3 套版式的自由组合，自动切分文章为分屏文案，输出正文源码、静态兜底版、本地预览、导入助手、注入代码和完整导入教程。当用户要求生成公众号 SVG 动画文章、交互图文、点击展开图文、SMIL 动画排版，或需要把文章做成公众号后台能用的动画长图时使用。
agent_created: true
---

# 微信公众号 SVG 动画文章生成器

## 用途

把用户给的任意一篇公众号文章，转成一套可以直接写进微信公众号后台编辑器的 SVG 交互动画正文：页面按时间轴一屏屏长出来，点一下也能接着播，线条会自己描出来，答案会揭晓。生成器遵守微信客户端的动画标签白名单，输出的是公众号线上真实 DOM 的净化形态，不是仅供浏览器观赏的演示稿。

四层可以独立选择，共 9 × 8 × 5 × 3 种组合：题材场景决定分屏骨架与推荐组合，配色决定风格，动效决定元素怎么进来，版式决定骨架与对齐。场景只是推荐值，用户可以单独覆盖任意一层。

## 何时使用

- 用户给了一篇文章（文件、粘贴的文本、公众号链接），要求做成带动画的公众号图文。
- 用户说「SVG 动画」「交互图文」「点击展开」「逐屏动画」「公众号排版」「做成动画长图」。
- 用户想换风格、换动效、换版式，或把已有文章重新出一版。
- 用户问怎么把 SVG 动画导入公众号后台、为什么粘贴进去不播放。

## 资源

- `scripts/build.py`：一键入口。文章 → 分屏 → 渲染 → 教程 → 校验，全部打包到输出目录。
- `scripts/article_to_content.py`：文章解析与自动分屏，可单独运行。
- `scripts/generator.py`：SVG 渲染引擎，支持 `--scene` / `--theme` / `--motion` / `--layout` / `--recipe` / `--content`。
- `scripts/validate.py`：微信白名单与净化形态自检。
- `scripts/check_overflow.py`：可选工具，装了 Chrome 时实测所有文字有没有越出画布右边界；改过文案或边距后跑一次。
- `scripts/theme.*.json`：8 套配色；`scripts/presets/`：9 场景、5 动效、3 版式、5 配方；`scripts/choreography.json`：时间轴骨架。
- `assets/示例文章_把会开短一点.md` 与 `assets/示例内容.通用屏型演示.json`：可直接拿来做演示或改造成用户自己的内容。
- `references/选择指南.md`：四层选项的对照与推荐，问用户选择时照它列。
- `references/内容结构说明.md`：分屏 JSON 的完整字段与所有屏型，精修文案时读它。
- `references/导入公众号编辑器.md`：完整导入教程，构建时会自动复制并转成 HTML 随成品交付。
- `references/设计规范与兼容白名单.md`：设计语言、微信动画标签白名单、验证方法。
- `references/常见问题.md`：排障速查。

## 工作流

### 第 1 步 · 拿到文章

- 用户给本地文件：直接把路径传给 `build.py --article`。支持 `.md` / `.txt` / `.html`。
- 用户粘贴全文：写成一个 UTF-8 的 `.md` 文件再传路径，避免命令行超长与转义问题。
- 用户给公众号文章链接：先抓取正文（保留标题、小标题、列表、引用），存成 `.md` 再用；抓取不到就请用户粘贴全文，不要凭空补写。
- 用户已有分屏 JSON：直接用 `--content`，跳过自动切分。
- 若文章特别长（超过约 1500 字），提醒一次：默认 9 屏，超出的内容不会排进去；可加 `--max-screens 12`，或拆成上下两篇。

### 第 2 步 · 确认四个选择

用户只给文章、没提偏好时，直接用场景默认值出片，不要反复追问。用户明确说「让我选」「换个风格」时，用提问工具一次问清下面四项，每项给 2 到 4 个最常见选项，并说明第一项是推荐值：

1. 题材场景：`general` 通用长文、`product` 产品发布、`science` 深度科普、`industry` 行业观察、`story` 人物故事、`data` 数据报告、`event` 活动预告、`howto` 教程指南、`brand` 品牌叙事。
2. 配色：8 套见 `references/选择指南.md`，深色与浅色各半。
3. 动效：`quiet` 静默递进、`writing` 书写显现、`page-turn` 纸页翻动、`cadence` 节拍错落、`telegraph` 电报硬切。
4. 版式：`manual` 仪器说明书、`magazine` 杂志画报、`dossier` 档案报表。

场景已经自带推荐的三层组合，用户只选场景时不需要再问后三项。四层可任意交叉，覆盖值用 `--theme` / `--motion` / `--layout` 传入。

### 第 3 步 · 一键生成

在 skill 的 `scripts/` 目录下执行（所有路径写成绝对路径最稳妥）：

```bash
python3 build.py --article /绝对路径/文章.md --scene product --out /绝对路径/输出/我的文章
```

常用变体：

```bash
# 只选场景，配色动效版式全用推荐值（最常用）
python3 build.py --article 文章.md --scene science --out 输出/科普篇

# 场景 + 单独覆盖配色与动效
python3 build.py --article 文章.md --scene brand --theme clay-warm --motion telegraph --out 输出/品牌篇

# 已有精修过的内容 JSON，重新渲染
python3 build.py --content 输出/内容.json --scene industry --layout dossier --out 输出/第二版

# 查看全部可用预设
python3 generator.py --list
```

构建脚本会依次完成：切分文章 → 生成 `内容.json` → 渲染正文与四个交付页 → 复制并转换导入教程 → 跑 `validate.py`。校验不通过会以非零状态退出，此时读 `校验结果.txt` 修问题，不要直接把不合格的源码交给用户。

### 第 4 步 · 交付与导入

用文件展示工具把输出目录里这些文件呈现给用户，优先级从高到低：`预览.html`、`导入助手.html`、`导入教程.html`、`SVG动画正文.html`、`静态兜底版.html`、`内容.json`、`本次生成说明.md`。同时在回复里说明本次用了哪个场景、配色、动效、版式，共几屏、约多少秒播完。

导入环节必须把下面四条讲清楚，详细步骤在 `references/导入公众号编辑器.md` 和成品里的 `导入教程.html`：

1. **绝不能复制源码 Ctrl+V 粘进正文**，微信粘贴过滤器会剥掉全部 `animate` 标签。只能走 F12 `Edit as HTML`、Console 注入、或 Sources → Snippets。
2. Console 首次粘贴会被 Chrome 的 Self-XSS 黄色警告拦下，那不是代码报错；要先让这次被拦的粘贴把警告引出来，再用键盘逐字敲 `allow pasting` 回车解锁，重开开发者工具要重走一遍。**该口令是 DevTools 的解锁口令，不是 JavaScript**：黄色警告没弹出（或已解锁）时单独执行它，会报 `Uncaught SyntaxError: Unexpected identifier 'pasting'`，与 SVG 和注入代码无关。怕麻烦直接走 F12 `Edit as HTML` / Sources → Snippets，不用这个口令。
3. Console 注入前必须先在 Elements 面板点一下正文，脚本靠 `$0` 锚定，并排除标题／作者／摘要；写错容器会自动回滚。首选方式一是手动选中节点，物理上不会跑进标题。
4. 后台编辑器里画面静止是正常的，**判定只认「保存为草稿 → 手机预览」**；手机上不动就跑自检代码，再不行换静态兜底版。

若用户要实现「更多动画效果」，优先新增 `scripts/presets/motion.*.json`，不要改渲染逻辑；新增配色复制任一 `theme.*.json` 并保证 token 齐全；新增屏型在 `generator.py` 里加 `s_xxx` 方法，并在 `references/内容结构说明.md` 补字段说明。

## 安装与分享

本技能是自包含的，只依赖 Python 3 标准库，不需要 pip 安装任何包，也不依赖原项目里的任何文件。把分发包 `wechat-svg-motion.zip` 解压到 `~/.workbuddy/skills/`（Windows 为用户目录下的 `.workbuddy/skills/`），解压后目录里应当直接看到 `SKILL.md`、`scripts/`、`references/`、`assets/`，重启一次会话即可被识别。项目级共享则放到对应仓库的 `.workbuddy/skills/` 下。

分享时一并附上成品目录里的 `导入教程.html`：那是给不懂代码的同事看的图文步骤，可以脱离技能单独打开。示例文章与示例内容 JSON 在 `assets/`，第一次使用可以直接拿它们跑通全流程。

## 硬性规则

- 内容只搬运原文，不编造事实、参数、数据与来源。自动切分找不到素材的屏型会跳过，不要为凑屏数塞占位数据；需要补充文案时先征得用户同意。
- 生成稿里标注「原文数据」「示例」「发布前请核对」的地方，交付时提醒用户核对真实信息。
- SVG 成品不含 `script`、`style` 标签、CSS 动画、`id`、`class`、`href` 引用、渐变、外部图片、`<line>`；标签与属性全小写，`<tspan leaf="">` 带 leaf，空元素显式闭合。改动渲染代码后必须重跑 `validate.py`。
- 微信服务端可能对个别标签做二次清洗，本地无法完全模拟，尤其 `<set visibility>` 硬切动效（`telegraph`）。因此每次交付都要附静态兜底版，并明确「发布前手机预览」这一步不可省。
- 不在用户已有的线上应用、已发布文章或他人后台上做实验；所有操作都在用户自己新建的草稿里进行。
