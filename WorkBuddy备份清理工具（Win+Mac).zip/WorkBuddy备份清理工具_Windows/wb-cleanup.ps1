﻿#requires -Version 5.1
<#
.SYNOPSIS
    WorkBuddy 备份清理工具（Windows 版）
.DESCRIPTION
    三种模式：
      scan     只读扫描备份占用（默认，绝不改动）
      clean    清理备份副本到回收站或永久删除（重点功能，默认预演）
      migrate  把整个 workspace 迁到别的盘并建 Junction（可选，低频）

    安全设计：只处理白名单目录名、默认预演、跳过软链(ReparsePoint)、
    保留最近 N 天、检测进程、生成恢复清单。
    会话正文在 ~/.workbuddy/projects/*.jsonl，与备份物理分离，清理不影响聊天记录。
#>
[CmdletBinding()]
param(
    [ValidateSet('scan','clean','migrate')][string]$Mode = 'scan',
    [switch]$Apply,                 # 真正执行（不加则预演）
    [int]$KeepDays = 7,             # 保留最近 N 天；0 = 全清
    [switch]$Permanent,             # 永久删除（快，适合海量小文件）；不加则移入回收站
    [string]$SessionsDir,           # 会话目录，默认自动探测
    [string]$TargetRoot,            # migrate 的目标盘根目录
    [int]$Sample = 64,              # migrate 校验抽样数
    [string]$Report                 # 报告另存文件
)

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$WHITE = @('modify_backup', 'modify_backup_v2', '.modify_backup_meta')

function Write-Log {
    param([string]$Msg, [string]$Level = 'INFO')
    $line = '[{0}] [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Msg
    Write-Host $line
    if ($Report) { try { Add-Content -LiteralPath $Report -Value $line -Encoding UTF8 } catch { } }
}
function Fail($msg) { Write-Log $msg 'ERROR'; throw $msg }
function Human($bytes) {
    if ($bytes -ge 1GB) { return ('{0:N2} GB' -f ($bytes / 1GB)) }
    if ($bytes -ge 1MB) { return ('{0:N1} MB' -f ($bytes / 1MB)) }
    return ('{0:N0} KB' -f ($bytes / 1KB))
}

# ---------- 编译 C# 扫描/校验辅助类（仅统计用，不加速删除） ----------
$cs = Join-Path $PSScriptRoot 'MigrationIO.cs'
if (-not (Test-Path -LiteralPath $cs)) { Fail "缺少 MigrationIO.cs，请确认几个文件放在同一文件夹: $cs" }
if (-not ('MigrationIO' -as [type])) {
    try { Add-Type -Path $cs -ErrorAction Stop }
    catch { Fail "编译 MigrationIO.cs 失败: $($_.Exception.Message)" }
}

# ---------- 探测会话目录 ----------
if ([string]::IsNullOrWhiteSpace($SessionsDir)) {
    $cands = @(
        (Join-Path $env:USERPROFILE '.workbuddy\workspace\sessions'),
        (Join-Path $env:USERPROFILE '.workbuddy-ai\workspace\sessions')
    )
    $found = @($cands | Where-Object { Test-Path -LiteralPath $_ })
    if ($found.Count -eq 0) { Fail ('未找到会话目录，尝试过: ' + ($cands -join ' ; ') + '。可用 -SessionsDir 指定。') }
    # 两个会话根都要扫：备份可能堆积在 .workbuddy 或 .workbuddy-ai，
    # 只取第一个会把真正占空间的那批整个漏掉（曾导致"C盘满却扫出0项"）。
    $script:SessionDirs = @($found | ForEach-Object { [System.IO.Path]::GetFullPath($_).TrimEnd('\') })
    $SessionsDir = $script:SessionDirs[0]
} else {
    $SessionsDir = [System.IO.Path]::GetFullPath($SessionsDir).TrimEnd('\')
    if (-not (Test-Path -LiteralPath $SessionsDir)) { Fail "会话目录不存在: $SessionsDir" }
    $script:SessionDirs = @($SessionsDir)
}

# ---------- 进程检测 ----------
function Test-WbRunning {
    $p = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match 'WorkBuddy|CodeBuddy' })
    return $p
}

# ---------- 收集备份项（白名单 + 跳过软链 + 时间判断） ----------
function Get-BackupItems {
    $script:EmptySkipped = 0
    $items = @()
    foreach ($root in $script:SessionDirs) {
        $tag = if ($root -like '*.workbuddy-ai*') { 'ai' } else { 'main' }
        foreach ($s in Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue) {
            foreach ($name in $WHITE) {
                $p = Join-Path $s.FullName $name
                if (-not (Test-Path -LiteralPath $p)) { continue }
                $di = Get-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue
                if (-not $di) { continue }
                # 安全闸门：软链/目录联接一律跳过，防止把链接指向的真实目录删掉
                if (($di.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                $st = [MigrationIO]::Scan($p)
                # 空壳目录（0 文件 0 字节，常见于 editor-sdk 会话）不列入清理清单，
                # 否则满屏 0 KB 徒增困惑；单独计数在报告里说明。
                if ($st.Files -eq 0 -and $st.Bytes -eq 0) { $script:EmptySkipped++; continue }
                $old = ($KeepDays -le 0) -or ($di.LastWriteTime -lt (Get-Date).AddDays(-$KeepDays))
                $items += [pscustomobject]@{
                    Sid = $s.Name; Name = $name; Path = $p; Root = $tag
                    Bytes = $st.Bytes; Files = $st.Files; Old = $old
                    LastWrite = $di.LastWriteTime
                }
            }
        }
    }
    return $items
}

function Guard-Process {
    $p = Test-WbRunning
    if ($p.Count -gt 0) {
        Write-Log ('检测到 WorkBuddy 仍在运行: ' + (($p | ForEach-Object { $_.ProcessName } | Select-Object -Unique) -join ', ')) 'WARN'
        Fail '请先从托盘完全退出 WorkBuddy（以及 CodeBuddy），再执行写操作。'
    }
}

# ============================================================ scan
function Do-Scan {
    Write-Log '===== WorkBuddy 备份占用扫描（只读） ====='
    foreach ($root in $script:SessionDirs) {
        Write-Log ("会话目录: " + $root)
        Write-Log ("  会话数: " + @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue).Count)
    }
    Write-Log ("保留策略: 最近 $KeepDays 天")
    $items = @(Get-BackupItems)
    $totB = 0; $totF = 0; $clB = 0; $clF = 0; $protB = 0; $protF = 0
    foreach ($i in $items) {
        $totB += $i.Bytes; $totF += $i.Files
        if ($i.Old) { $clB += $i.Bytes; $clF += $i.Files }
        else { $protB += $i.Bytes; $protF += $i.Files }
    }
    Write-Log ("备份项数: $($items.Count)")
    if ($script:EmptySkipped -gt 0) { Write-Log ("空壳目录（0字节，已忽略）: $($script:EmptySkipped) 个") }
    Write-Log ("全部备份: $(Human $totB) / $totF 个文件")
    Write-Log ("可清理（旧于 $KeepDays 天）: $(Human $clB) / $clF 个文件")
    if ($protB -gt 0) {
        Write-Log ("受保护（最近 $KeepDays 天，默认不删）: $(Human $protB) / $protF 个文件") 'WARN'
        Write-Log '  这些是近期备份，默认保留以防误删。要连它们一起清，用菜单 5 预演、菜单 6 执行。' 'WARN'
    }
    Write-Log ''
    Write-Log '---- 占用最大的 12 项 ----'
    $items | Sort-Object Bytes -Descending | Select-Object -First 12 | ForEach-Object {
        $ageTxt = if ($_.Old) { '旧-可清' } else { '新-保护' }
        Write-Log ("  {0,10}  [{1}] {2}/{3}  {4} 文件  {5}" -f (Human $_.Bytes), $_.Root, $_.Sid, $_.Name, $_.Files, $ageTxt)
    }
    Write-Log ''
    Write-Log '提示: 聊天记录在 ~/.workbuddy/projects/ 下，与备份分离，清理不影响历史会话。'
}

# ============================================================ clean
function Do-Clean {
    if ($Apply) { Guard-Process }
    $all = @(Get-BackupItems)
    $items = @($all | Where-Object { $_.Old })
    $protected = @($all | Where-Object { -not $_.Old })
    $totB = ($items | Measure-Object -Property Bytes -Sum).Sum
    $totF = ($items | Measure-Object -Property Files -Sum).Sum

    $modeTxt = if ($Apply) { if ($Permanent) { '执行（永久删除）' } else { '执行（移入回收站）' } } else { '预演（DRY-RUN，不动任何文件）' }
    Write-Log '===== WorkBuddy 备份清理 ====='
    Write-Log ("执行时间: " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    foreach ($root in $script:SessionDirs) { Write-Log ("会话目录: " + $root) }
    Write-Log ("保留策略: 最近 $KeepDays 天   模式: $modeTxt")
    Write-Log ("符合条件: $($items.Count) 项 / $(Human $totB) / $totF 个文件")
    if ($script:EmptySkipped -gt 0) { Write-Log ("另有 $($script:EmptySkipped) 个空壳目录（0字节）已忽略，无需清理") }
    if ($items.Count -eq 0) {
        if ($protected.Count -gt 0) {
            $pB = ($protected | Measure-Object -Property Bytes -Sum).Sum
            $pF = ($protected | Measure-Object -Property Files -Sum).Sum
            Write-Log ("没有旧于 $KeepDays 天的备份。但检测到 $($protected.Count) 项 / $(Human $pB) / $pF 个文件属于最近 $KeepDays 天，被保留策略挡住了。") 'WARN'
            Write-Log '若确认要连这些近期备份一起清理：先用菜单 5「全清预演」查看清单，确认后用菜单 6「全清执行」永久删除。' 'WARN'
        } else {
            Write-Log '没有需要清理的备份，结束。'
        }
        return
    }

    if (-not $Apply) {
        Write-Log ''
        Write-Log '这是预演，什么都没删。将清理的目录:'
        $items | Sort-Object Bytes -Descending | Select-Object -First 20 | ForEach-Object {
            Write-Log ("  {0,10}  [{1}] {2}" -f (Human $_.Bytes), $_.Root, $_.Path)
        }
        Write-Log "（仅列出前 20 项，共 $($items.Count) 项）"
        Write-Log '确认无误后加 -Apply 执行。'
        return
    }

    # 执行删除
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $listFile = Join-Path $env:USERPROFILE ("wb-cleanup-list-$stamp.txt")
    $useRecycle = -not $Permanent
    if ($useRecycle) {
        try { Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction Stop }
        catch { Fail "加载 Microsoft.VisualBasic 失败，无法送入回收站。可改用 -Permanent 永久删除: $($_.Exception.Message)" }
        Write-Log '删除方式: 移入回收站（可恢复）。注意：海量小文件会拖慢回收站，见说明。' 'WARN'
    } else {
        Write-Log '删除方式: 永久删除（robocopy 空目录镜像，快，不可恢复）' 'WARN'
        $empty = Join-Path $env:TEMP ('wb_empty_' + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $empty -Force | Out-Null
    }

    $okN = 0; $failN = 0
    foreach ($i in $items) {
        # 二次校验：白名单 + 非软链，防止遍历期间被改动
        if ($WHITE -notcontains $i.Name) { Write-Log "白名单校验失败，跳过: $($i.Path)" 'WARN'; $failN++; continue }
        $di = Get-Item -LiteralPath $i.Path -Force -ErrorAction SilentlyContinue
        if (-not $di -or ($di.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            Write-Log "目标已变化或为软链，跳过: $($i.Path)" 'WARN'; $failN++; continue
        }
        try {
            if ($useRecycle) {
                [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory(
                    $i.Path,
                    [Microsoft.VisualBasic.FileIO.UIOption]::OnlyErrorDialogs,
                    [Microsoft.VisualBasic.FileIO.RecycleOption]::SendToRecycleBin)
            } else {
                & robocopy $empty $i.Path /MIR /MT:32 /R:0 /W:0 /NFL /NDL /NJH /NJS /NP | Out-Null
                if ($LASTEXITCODE -ge 8) { throw "robocopy 返回 $LASTEXITCODE" }
                Remove-Item -LiteralPath $i.Path -Recurse -Force -ErrorAction SilentlyContinue
            }
            $okN++
            Add-Content -LiteralPath $listFile -Value ("原位置: " + $i.Path + "  |  " + (Human $i.Bytes) + " / " + $i.Files + " 文件") -Encoding UTF8
        } catch {
            $failN++
            Write-Log ("清理失败（可能被占用）: " + $i.Path + " -> " + $_.Exception.Message) 'WARN'
        }
    }
    if (-not $useRecycle) { Remove-Item -LiteralPath $empty -Recurse -Force -ErrorAction SilentlyContinue }

    Write-Log ''
    Write-Log ("完成: 成功 $okN 项，失败/跳过 $failN 项")
    if ($useRecycle) {
        Write-Log '恢复: 打开回收站，按删除时间找到对应会话目录，右键还原。'
    } else {
        Write-Log '永久删除不可恢复。删除清单（供核对）: ' + $listFile
    }
    Write-Log '建议启动 WorkBuddy 打开几条历史会话确认正常。'
}

# ============================================================ migrate（可选）
function Do-Migrate {
    if (-not (Test-Path -LiteralPath $PSScriptRoot)) { Fail '脚本目录异常' }
    $workspace = Split-Path -Parent $SessionsDir        # .../workspace
    if (-not (Test-Path -LiteralPath $workspace)) { Fail "找不到 workspace: $workspace" }
    $wsItem = Get-Item -LiteralPath $workspace -Force
    if (($wsItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { Fail "$workspace 已经是链接，可能迁移过了" }

    $running = Test-WbRunning
    if ($running.Count -gt 0) { Guard-Process }

    if ([string]::IsNullOrWhiteSpace($TargetRoot)) {
        $sys = $env:SystemDrive.TrimEnd('\')
        $disks = Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' |
                 Where-Object { $_.DeviceID -ne ($sys + ':') } | Sort-Object FreeSpace -Descending
        if (-not $disks -or $disks.Count -eq 0) {
            Fail '没有找到非系统盘，迁移需要另一个盘。可用 -TargetRoot 指定目录。'
        }
        $TargetRoot = (Join-Path (($disks | Select-Object -First 1).DeviceID + '\') 'WorkBuddyData')
    }
    $TargetRoot = [System.IO.Path]::GetFullPath($TargetRoot)
    $target = Join-Path $TargetRoot 'workspace'
    if (Test-Path -LiteralPath $target) {
        if (@(Get-ChildItem -LiteralPath $target -Force -ErrorAction SilentlyContinue).Count -gt 0) {
            Fail "目标目录非空，停止以免覆盖: $target"
        }
    }

    $st = [MigrationIO]::Scan($workspace)
    Write-Log '===== workspace 迁移（可选模式） ====='
    Write-Log ("源: $workspace  ($($st.Files) 文件 / $(Human $st.Bytes))")
    Write-Log ("目标: $target")
    if (-not $Apply) { Write-Log '预演结束。加 -Apply 执行复制+建 Junction。'; return }

    Write-Log '复制中，海量文件需要几分钟……'
    $copied = [MigrationIO]::CopyTree($workspace, $target)
    Write-Log "复制完成: $copied 文件。开始校验……"
    $vr = [MigrationIO]::Verify($workspace, $target, $Sample)
    if (-not $vr.Ok) {
        Write-Log ("校验未通过: 源 $($vr.SrcFiles)/$($vr.SrcBytes) 目标 $($vr.DstFiles)/$($vr.DstBytes) 不一致数 $($vr.Mismatches)") 'ERROR'
        Fail '校验失败，源未改动。目标目录保留待人工确认。'
    }
    Write-Log '校验通过。改名源并建立 Junction……'
    $bak = $workspace + '.wbmove-backup'
    if (Test-Path -LiteralPath $bak) { Fail "备份目录已存在，可能上次未完成: $bak" }
    try {
        Rename-Item -LiteralPath $workspace -NewName ([IO.Path]::GetFileName($bak)) -ErrorAction Stop
        $mk = & cmd.exe /c mklink /J $workspace $target 2>&1
        $ok = ($LASTEXITCODE -eq 0)
        if ($ok) {
            $created = Get-Item -LiteralPath $workspace -Force -ErrorAction SilentlyContinue
            if (-not $created -or ($created.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) { $ok = $false }
        }
        if (-not $ok) { throw ('mklink 失败: ' + ($mk | Out-String)) }
    } catch {
        if (-not (Test-Path -LiteralPath $workspace) -and (Test-Path -LiteralPath $bak)) {
            Rename-Item -LiteralPath $bak -NewName ([IO.Path]::GetFileName($workspace)) -ErrorAction SilentlyContinue
            Write-Log '已回滚目录名。' 'WARN'
        }
        Fail "Junction 阶段失败: $($_.Exception.Message)"
    }
    Write-Log 'Junction 建立成功。请启动 WorkBuddy 验证历史会话和任务产物。'
    Write-Log ("验证正常后，手动删除备份释放空间: $bak")
    Write-Log '如需回退: 删除该 Junction（cmd 里 rmdir 不带 /S），再把 .wbmove-backup 改回 workspace。'
}

# ============================================================ 入口
Write-Host '============================================================' -ForegroundColor Cyan
Write-Host ' WorkBuddy 备份清理工具（Windows 版）' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor Cyan
switch ($Mode) {
    'scan'    { Do-Scan }
    'clean'   { Do-Clean }
    'migrate' { Do-Migrate }
}
