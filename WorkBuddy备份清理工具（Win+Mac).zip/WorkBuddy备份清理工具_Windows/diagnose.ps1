﻿#requires -Version 5.1
<#
.SYNOPSIS
    C 盘空间诊断：找出 WorkBuddy 备份在哪、空间被谁占了
.DESCRIPTION
    只读，不删任何东西。用 MigrationIO.cs 快速统计文件数/字节。
#>
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

function FmtSize($b) {
    if ($null -eq $b) { return '0 KB' }
    if ($b -ge 1GB) { return ('{0:N2} GB' -f ($b / 1GB)) }
    if ($b -ge 1MB) { return ('{0:N1} MB' -f ($b / 1MB)) }
    return ('{0:N0} KB' -f ($b / 1KB))
}

$cs = Join-Path $PSScriptRoot 'MigrationIO.cs'
if (-not ('MigrationIO' -as [type])) {
    if (-not (Test-Path -LiteralPath $cs)) { Write-Host "缺少 MigrationIO.cs" -ForegroundColor Red; exit 1 }
    try { Add-Type -Path $cs -ErrorAction Stop } catch { Write-Host ("编译失败: " + $_.Exception.Message) -ForegroundColor Red; exit 1 }
}

Write-Host '============================================================' -ForegroundColor Cyan
Write-Host ' C 盘空间诊断（只读，不删任何东西）' -ForegroundColor Cyan
Write-Host '============================================================' -ForegroundColor Cyan

# 1) 磁盘概览
Write-Host ''
Write-Host '---- 磁盘空间 ----'
try {
    $c = Get-PSDrive C -ErrorAction Stop
    Write-Host ("  C 盘: 已用 {0} / 剩余 {1}" -f (FmtSize $c.Used), (FmtSize $c.Free))
} catch { Write-Host '  读取 C 盘信息失败' }

# 2) 所有 .workbuddy* 目录
Write-Host ''
Write-Host '---- WorkBuddy 相关目录（用户主目录下所有 .workbuddy*）----'
$wbDirs = @(Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '.workbuddy*' })
if ($wbDirs.Count -eq 0) {
    Write-Host '  未找到任何 .workbuddy* 目录'
} else {
    foreach ($w in $wbDirs) {
        $st = [MigrationIO]::Scan($w.FullName)
        $sess = Join-Path $w.FullName 'workspace\sessions'
        $sessNote = if (Test-Path -LiteralPath $sess) {
            $ss = [MigrationIO]::Scan($sess)
            ("sessions: {0}/{1}文件" -f (FmtSize $ss.Bytes), $ss.Files)
        } else { '无 sessions 子目录' }
        Write-Host ("  {0,10}  {1,9} 文件  {2}" -f (FmtSize $st.Bytes), $st.Files, $w.FullName)
        Write-Host ("               └─ {0}" -f $sessNote)
    }
}

# 3) 用户主目录下各顶层目录占用 Top 15
Write-Host ''
Write-Host '---- 用户主目录下占用最大的目录 Top 15 ----'
Write-Host '  （扫描可能较慢，请稍候；AppData 通常最大属正常）'
$rows = @()
foreach ($d in (Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -Force -ErrorAction SilentlyContinue)) {
    $st = [MigrationIO]::Scan($d.FullName)
    $rows += [pscustomobject]@{ Bytes = $st.Bytes; Files = $st.Files; Path = $d.FullName }
}
$rows | Sort-Object Bytes -Descending | Select-Object -First 15 | ForEach-Object {
    Write-Host ("  {0,10}  {1,9} 文件  {2}" -f (FmtSize $_.Bytes), $_.Files, $_.Path)
}

# 4) 回收站
Write-Host ''
Write-Host '---- 回收站（备份文件常被删到这里）----'
$recycle = 'C:\$Recycle.Bin'
if (Test-Path -LiteralPath $recycle) {
    $st = [MigrationIO]::Scan($recycle)
    Write-Host ("  {0}  {1} 个文件  {2}" -f (FmtSize $st.Bytes), $st.Files, $recycle)
    if ($st.Files -gt 100000) {
        Write-Host '  警告: 回收站文件数超过 10 万，会导致清空卡死。' -ForegroundColor Yellow
        Write-Host '  可用 robocopy 空目录镜像法快速清空（见使用说明）。' -ForegroundColor Yellow
    }
} else {
    Write-Host '  无法访问回收站（可能需要管理员权限）'
}

Write-Host ''
Write-Host '诊断结束。把以上结果截图发回，即可判断空间去向。' -ForegroundColor Cyan
