﻿#requires -Version 5.1
<#
.SYNOPSIS
    WorkBuddy 备份清理工具 - 交互式菜单（UTF-8，中文全程保留）
.DESCRIPTION
    菜单与子脚本同处 PowerShell/UTF-8 环境，避免 bat(GBK) 与 ps1(UTF-8) 争抢控制台代码页导致中文乱码。
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$cleanupScript = Join-Path $PSScriptRoot 'wb-cleanup.ps1'
if (-not (Test-Path -LiteralPath $cleanupScript)) {
    Write-Host ("找不到主脚本: " + $cleanupScript) -ForegroundColor Red
    $null = Read-Host '按回车键退出'
    exit 1
}

function Invoke-Cleanup {
    param([hashtable]$Params)
    try {
        & $cleanupScript @Params
    } catch {
        Write-Host ''
        Write-Host ('发生错误: ' + $_.Exception.Message) -ForegroundColor Red
    }
}

while ($true) {
    try { Clear-Host } catch { }
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ' WorkBuddy 备份清理工具（Windows 版）' -ForegroundColor Cyan
    Write-Host '============================================================' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '  1) 扫描占用（只读，安全，先看这个）'
    Write-Host '  2) 预演清理（不删，列出将清理什么）'
    Write-Host '  3) 执行清理 - 移入回收站（可恢复）'
    Write-Host '  4) 执行清理 - 永久删除（快，适合海量小文件）'
    Write-Host '  5) 全清预演（含最近7天，不删）'
    Write-Host '  6) 全清执行 - 永久删除（含最近7天）'
    Write-Host '  7) 迁移到别的盘（可选，需管理员，见说明）'
    Write-Host '  8) 诊断空间占用（只读，查 C 盘空间去哪了）'
    Write-Host '  0) 退出'
    Write-Host ''
    $choice = (Read-Host ' 请选择 [0-8]').Trim()
    switch ($choice) {
        '1' { Invoke-Cleanup @{ Mode = 'scan' } }
        '2' { Invoke-Cleanup @{ Mode = 'clean' } }
        '3' { Invoke-Cleanup @{ Mode = 'clean'; Apply = $true } }
        '4' { Invoke-Cleanup @{ Mode = 'clean'; Apply = $true; Permanent = $true } }
        '5' { Invoke-Cleanup @{ Mode = 'clean'; KeepDays = 0 } }
        '6' { Invoke-Cleanup @{ Mode = 'clean'; KeepDays = 0; Apply = $true; Permanent = $true } }
        '7' { Invoke-Cleanup @{ Mode = 'migrate'; Apply = $true } }
        '8' {
            $diag = Join-Path $PSScriptRoot 'diagnose.ps1'
            if (Test-Path -LiteralPath $diag) {
                try { & $diag } catch { Write-Host ('诊断出错: ' + $_.Exception.Message) -ForegroundColor Red }
            } else { Write-Host '缺少 diagnose.ps1，请确认文件齐全。' -ForegroundColor Red }
        }
        '0' { exit }
        default { Write-Host ' 无效选择，请重新输入。' -ForegroundColor Yellow }
    }
    Write-Host ''
    $null = Read-Host ' 按回车键继续'
}
