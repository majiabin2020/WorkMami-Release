﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

// 高性能复制/校验辅助类。
// Windows 自带 PowerShell 5.1 的 Add-Type 可直接内联编译本文件（csc 随 .NET Framework 提供）。
// 目的：文章里那个 MigrationIO.cs 的作用一致——PowerShell 逐文件 Copy-Item 处理几十万个
// 小文件时慢到不可用，这里用大缓冲 FileStream + 并行目录枚举，把复制/校验/删除压到可接受范围。
//
// 注意：为避免 32 位 PowerShell 下大文件偏移溢出，编译本文件时 Add-Type 会加 /platform:anycpu，
// 实际由运行进程的位数决定。建议用 64 位 PowerShell 运行主脚本。

public static class MigrationIO
{
    private const int BufferSize = 1024 * 1024; // 1 MB

    public sealed class Stat
    {
        public long Files;
        public long Bytes;
        public long Dirs;
    }

    public static Stat Scan(string root)
    {
        Stat s = new Stat();
        if (string.IsNullOrEmpty(root) || !Directory.Exists(root)) return s;

        // 用栈做显式遍历，避免 GetFiles(AllDirectories) 在超深目录上一次把所有路径读进内存。
        Stack<string> pending = new Stack<string>();
        pending.Push(root);
        while (pending.Count > 0)
        {
            string dir = pending.Pop();
            s.Dirs++;
            try
            {
                foreach (string f in Directory.EnumerateFiles(dir))
                {
                    try
                    {
                        FileInfo fi = new FileInfo(f);
                        s.Files++;
                        s.Bytes += fi.Length;
                    }
                    catch { /* 单个文件被占用就跳过，统计阶段不致命 */ }
                }
                foreach (string d in Directory.EnumerateDirectories(dir))
                {
                    // 不再跟随 Junction/符号链接，避免把已迁移目标或目录回环算进来。
                    FileAttributes attr = File.GetAttributes(d);
                    if ((attr & FileAttributes.ReparsePoint) == 0) pending.Push(d);
                }
            }
            catch { /* 无权限目录跳过 */ }
        }
        return s;
    }

    // 复制目录树：保留相对路径、最后写入时间；不复制 ACL，迁移备份数据无需保留原 ACL。
    // 返回实际复制的文件数。目标已存在的同名文件会被覆盖（仅在目标目录确认为空或专用目录时调用）。
    public static long CopyTree(string src, string dst)
    {
        if (!Directory.Exists(src)) throw new DirectoryNotFoundException("源目录不存在: " + src);
        Directory.CreateDirectory(dst);
        long count = 0;

        Stack<string> pending = new Stack<string>();
        pending.Push(src);
        while (pending.Count > 0)
        {
            string dir = pending.Pop();
            string rel = dir.Substring(src.Length).TrimStart('\\', '/');
            string targetDir = rel.Length == 0 ? dst : Path.Combine(dst, rel);
            if (!Directory.Exists(targetDir)) Directory.CreateDirectory(targetDir);

            foreach (string f in Directory.EnumerateFiles(dir))
            {
                string name = Path.GetFileName(f);
                string target = Path.Combine(targetDir, name);
                CopyOne(f, target);
                count++;
            }

            foreach (string d in Directory.EnumerateDirectories(dir))
            {
                FileAttributes attr = File.GetAttributes(d);
                if ((attr & FileAttributes.ReparsePoint) == 0) pending.Push(d);
            }
        }
        return count;
    }

    private static void CopyOne(string src, string dst)
    {
        // 目标已存在且长度+时间一致则跳过，支持断点续跑。
        FileInfo sfi = new FileInfo(src);
        if (File.Exists(dst))
        {
            FileInfo dfi = new FileInfo(dst);
            if (dfi.Length == sfi.Length && dfi.LastWriteTimeUtc == sfi.LastWriteTimeUtc) return;
        }
        using (FileStream fin = new FileStream(src, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, BufferSize, FileOptions.SequentialScan))
        using (FileStream fout = new FileStream(dst, FileMode.Create, FileAccess.Write, FileShare.None, BufferSize, FileOptions.SequentialScan))
        {
            fin.CopyTo(fout, BufferSize);
        }
        File.SetLastWriteTimeUtc(dst, sfi.LastWriteTimeUtc);
    }

    // 校验：文件数、总字节必须一致；再按步长抽样做 SHA256 全文件哈希。
    // 抽样而非全量哈希，是为了在几十万文件规模下把校验时间控制在分钟级。
    public sealed class VerifyReport
    {
        public long SrcFiles;
        public long DstFiles;
        public long SrcBytes;
        public long DstBytes;
        public int Sampled;
        public int Mismatches;
        public string FirstMismatch;
        public bool Ok
        {
            get { return SrcFiles == DstFiles && SrcBytes == DstBytes && Mismatches == 0; }
        }
    }

    public static VerifyReport Verify(string src, string dst, int sampleCount)
    {
        VerifyReport r = new VerifyReport();
        Stat ss = Scan(src);
        Stat ds = Scan(dst);
        r.SrcFiles = ss.Files; r.SrcBytes = ss.Bytes;
        r.DstFiles = ds.Files; r.DstBytes = ds.Bytes;

        List<string> files = new List<string>();
        Stack<string> pending = new Stack<string>();
        pending.Push(src);
        while (pending.Count > 0)
        {
            string dir = pending.Pop();
            try
            {
                foreach (string f in Directory.EnumerateFiles(dir)) files.Add(f);
                foreach (string d in Directory.EnumerateDirectories(dir))
                {
                    if ((File.GetAttributes(d) & FileAttributes.ReparsePoint) == 0) pending.Push(d);
                }
            }
            catch { }
        }

        if (sampleCount < 1) sampleCount = 1;
        int step = files.Count == 0 ? 1 : Math.Max(1, files.Count / sampleCount);
        for (int i = 0; i < files.Count; i += step)
        {
            string rel = files[i].Substring(src.Length).TrimStart('\\', '/');
            string target = Path.Combine(dst, rel);
            r.Sampled++;
            if (!File.Exists(target))
            {
                r.Mismatches++;
                if (r.FirstMismatch == null) r.FirstMismatch = target + " (缺失)";
                continue;
            }
            string h1 = Sha256(files[i]);
            string h2 = Sha256(target);
            if (!string.Equals(h1, h2, StringComparison.OrdinalIgnoreCase))
            {
                r.Mismatches++;
                if (r.FirstMismatch == null) r.FirstMismatch = target + " (哈希不一致)";
            }
        }
        return r;
    }

    public static string Sha256(string path)
    {
        using (SHA256 sha = SHA256.Create())
        using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite, BufferSize, FileOptions.SequentialScan))
        {
            byte[] hash = sha.ComputeHash(fs);
            StringBuilder sb = new StringBuilder(hash.Length * 2);
            foreach (byte b in hash) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }
    }
}
