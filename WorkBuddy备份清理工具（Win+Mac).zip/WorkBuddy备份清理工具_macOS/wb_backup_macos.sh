#!/bin/bash
# WorkBuddy 备份清理工具（macOS 版）
# ----------------------------------------------------------------------------
# 背景：WorkBuddy 在改/删文件前会把原文件完整复制一份到会话目录的
#       modify_backup / modify_backup_v2 / .modify_backup_meta 下。
#       这些副本会持续累积，吃掉系统盘空间。
# 事实：会话正文（聊天记录）在 ~/.workbuddy/projects/*.jsonl，
#       与 workspace/sessions 下的备份副本物理分离——清理备份不影响历史会话。
#
# 与 Windows 版的差异：Windows 用 Junction 把目录挪到 D 盘；macOS 这里默认
#       没有第二块盘可迁，所以主打「安全清理」。迁移模式留给已外接硬盘的场景。
#
# 安全设计：
#   1) 只处理白名单目录名，绝不碰 sessions 下的其他内容
#   2) 默认 dry-run（只报告不删除），必须显式加 --apply 才真删
#   3) 软删除：移到废纸篓而不是 rm，可恢复；并记录恢复清单
#   4) 检测 WorkBuddy 进程，运行中拒绝清理
#   5) --keep-days N 默认保留最近 7 天的备份，保护正在用的会话
#   6) 跳过 0 字节空壳目录、跳过符号链接
#
# 兼容 macOS 自带 bash 3.2，不依赖任何第三方工具（用 find/du/mv/date 等系统命令）。
# ----------------------------------------------------------------------------

set -u

WB_HOME="${HOME}/.workbuddy"
# 两个会话根都要扫：备份可能堆积在 .workbuddy 或 .workbuddy-ai，
# 只扫一个会把真正占空间的那批整个漏掉（Windows 版踩过这个坑）。
WB_HOMES=("${HOME}/.workbuddy" "${HOME}/.workbuddy-ai")
SESSION_ROOTS=()          # 元素格式 "tag|path"，如 "main|/Users/xx/.workbuddy/workspace/sessions"
TRASH="${HOME}/.Trash"
# 只处理这些精确目录名；其他任何目录/文件一律不碰
BACKUP_NAMES=(modify_backup modify_backup_v2 .modify_backup_meta)

MODE="scan"          # scan | clean | migrate | diagnose
APPLY=0              # 0=预演 1=执行
KEEP_DAYS=7          # 保留最近 N 天
MIGRATE_TARGET=""
REPORT_FILE=""

log(){ printf '%s\n' "$*"; }
die(){ printf '[错误] %s\n' "$*" >&2; exit 1; }

usage(){
  cat <<'EOF'
WorkBuddy 备份清理工具（macOS 版）

用法:
  wb_backup_macos.sh [模式] [选项]

模式:
  scan                    只读扫描并报告占用（默认，绝不改动任何文件）
  clean                   清理备份副本到废纸篓（默认预演，需 --apply 才真删）
  migrate <目标目录>       把整个 workspace 迁到外接盘并用软链接接回（高级，见说明）
  diagnose                只读诊断空间占用：磁盘、各 .workbuddy* 目录、主目录 Top15、废纸篓

选项:
  --apply                 真正执行（不加则只预演）
  --keep-days N           保留最近 N 天的备份（默认 7；0 表示全清）
  --report FILE           把扫描结果同时写入 FILE
  -h, --help              显示本帮助

示例:
  ./wb_backup_macos.sh scan                       # 看看占了多少，只读
  ./wb_backup_macos.sh clean                      # 预演：列出将要清理的内容
  ./wb_backup_macos.sh clean --apply              # 真删（移到废纸篓）
  ./wb_backup_macos.sh clean --keep-days 0 --apply# 全清（含最近 7 天）
  ./wb_backup_macos.sh diagnose                   # 查空间到底被谁占了
  ./wb_backup_macos.sh migrate /Volumes/SSD/wbdata --apply
EOF
}

# ---------- 参数解析 ----------
while [ $# -gt 0 ]; do
  case "$1" in
    scan|clean|migrate|diagnose) MODE="$1"; shift ;;
    --apply) APPLY=1; shift ;;
    --keep-days) KEEP_DAYS="${2:-}"; shift 2 || die "--keep-days 需要一个数字" ;;
    --report) REPORT_FILE="${2:-}"; shift 2 || die "--report 需要文件名" ;;
    -h|--help) usage; exit 0 ;;
    *)
      # migrate 模式的位置参数
      if [ "$MODE" = "migrate" ] && [ -z "$MIGRATE_TARGET" ]; then
        MIGRATE_TARGET="$1"; shift
      else
        die "无法识别的参数: $1"
      fi
      ;;
  esac
done

report(){ log "$1"; if [ -n "$REPORT_FILE" ]; then printf '%s\n' "$1" >> "$REPORT_FILE"; fi; }

# ---------- 前置检查：构建会话根列表 ----------
# 只保留实际存在的根，并打上 main / ai 标记。两个根都要扫——
# Windows 版曾因只扫第一个根，把真正堆积在 .workbuddy-ai 的备份整个漏掉。
for h in "${WB_HOMES[@]}"; do
  d="${h}/workspace/sessions"
  [ -d "$d" ] || continue
  case "$h" in
    */.workbuddy-ai) tag="ai" ;;
    *) tag="main" ;;
  esac
  SESSION_ROOTS+=("${tag}|${d}")
done
[ ${#SESSION_ROOTS[@]} -gt 0 ] || die "找不到会话目录，尝试过: ${WB_HOMES[*]}（WorkBuddy 是否装在这台机器？）"

# 检测 WorkBuddy 进程（只读扫描时不强制，清理时强制）
wb_running(){
  # 只返回 PID，不打印命令行。macOS 上主进程名是 "WorkBuddy Helper"，
  # 精确名 WorkBuddy 反而不存在；用 -x 精确匹配 Helper，避免误伤其他进程。
  pgrep -x "WorkBuddy Helper" 2>/dev/null | head -5
}

# ---------- 工具函数 ----------
# 判断目录是否旧于 KEEP_DAYS 天（macOS find 支持 -mtime +N）
is_old_enough(){
  local dir="$1"
  [ "$KEEP_DAYS" -le 0 ] && return 0
  find "$dir" -maxdepth 0 -mtime +"$KEEP_DAYS" 2>/dev/null | grep -q . && return 0
  return 1
}

dir_size_kb(){ du -sk "$1" 2>/dev/null | awk '{print $1}'; }
file_count(){ find "$1" -type f 2>/dev/null | wc -l | tr -d ' '; }

human_size(){
  local kb="${1:-0}"
  awk -v k="$kb" 'BEGIN{
    if(k>=1048576) printf "%.2f GB", k/1048576;
    else if(k>=1024) printf "%.1f MB", k/1024;
    else printf "%s KB", k;
  }'
}

# ========== 扫描 / 清理 共用的遍历 ==========
# 输出格式：tag|会话ID|备份名|完整路径|KB|文件数|是否够旧(1/0)
# 空壳目录（0 文件 0 字节）也照常输出，由调用方跳过并计数——
# 这样空壳计数留在主进程，不必跨子 shell 传变量（兼容 bash 3.2）。
collect_backups(){
  local rootspec tag sessions session name target kb cnt old
  for rootspec in "${SESSION_ROOTS[@]}"; do
    tag="${rootspec%%|*}"
    sessions="${rootspec#*|}"
    for session in "$sessions"/*/; do
      [ -d "$session" ] || continue
      for name in "${BACKUP_NAMES[@]}"; do
        target="${session}${name}"
        [ -e "$target" ] || continue
        # 安全闸门：只处理普通目录，符号链接一律跳过（防止 symlink 攻击把别处删掉）
        [ -d "$target" ] && [ ! -L "$target" ] || continue
        kb=$(dir_size_kb "$target")
        cnt=$(file_count "$target")
        old=0; is_old_enough "$target" && old=1
        printf '%s|%s|%s|%s|%s|%s|%s\n' "$tag" "$(basename "$session")" "$name" "$target" "$kb" "$cnt" "$old"
      done
    done
  done
}

do_scan(){
  report "===== WorkBuddy 备份占用扫描（只读） ====="
  report "扫描时间: $(date '+%Y-%m-%d %H:%M:%S')"
  local rs sessions
  for rs in "${SESSION_ROOTS[@]}"; do
    sessions="${rs#*|}"
    report "会话目录 [${rs%%|*}]: $sessions"
    report "  会话数: $(find "$sessions" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')"
  done
  report "保留策略: 最近 ${KEEP_DAYS} 天"
  report ""

  local total_kb=0 total_files=0 clean_kb=0 clean_files=0 prot_kb=0 prot_files=0 n=0 empty=0
  local tag sid name path kb cnt old
  while IFS='|' read -r tag sid name path kb cnt old; do
    [ -n "$sid" ] || continue
    if [ "$kb" -eq 0 ] && [ "$cnt" -eq 0 ]; then empty=$((empty+1)); continue; fi
    n=$((n+1))
    total_kb=$((total_kb+kb)); total_files=$((total_files+cnt))
    if [ "$old" = "1" ]; then
      clean_kb=$((clean_kb+kb)); clean_files=$((clean_files+cnt))
    else
      prot_kb=$((prot_kb+kb)); prot_files=$((prot_files+cnt))
    fi
  done < <(collect_backups)

  report "备份项数: $n"
  [ "$empty" -gt 0 ] && report "空壳目录（0字节，已忽略）: $empty 个"
  report "全部备份占用: $(human_size $total_kb)（$total_files 个文件）"
  report "可清理（旧于 ${KEEP_DAYS} 天）: $(human_size $clean_kb)（$clean_files 个文件）"
  if [ "$prot_kb" -gt 0 ]; then
    report "受保护（最近 ${KEEP_DAYS} 天，默认不删）: $(human_size $prot_kb)（$prot_files 个文件）"
    report "  这些是近期备份，默认保留以防误删。要连它们一起清，用菜单 4 预演、菜单 5 执行。"
  fi
  report ""
  report "---- 占用最大的 12 项 ----"
  collect_backups | awk -F'|' '$5!=0 || $6!=0 {age=($7=="1")?"旧-可清":"新-保护"; printf "%s|%s\n",$5,"["$1"] "$2"/"$3"  "$6" 文件  "age}' | sort -rn | head -12 | while IFS='|' read -r kb label; do
    report "  $(human_size "$kb")  $label"
  done
  report ""
  report "提示: 聊天记录在 ~/.workbuddy/projects/ 下，与这些备份分离，清理不影响历史会话。"
}

do_clean(){
  local running
  running=$(wb_running)
  if [ -n "$running" ]; then
    report "[中止] 检测到 WorkBuddy 仍在运行:"
    report "$running"
    report "请先完全退出 WorkBuddy，再执行清理。"
    exit 1
  fi

  local stamp="$(date '+%Y%m%d-%H%M%S')"
  local trash_dir="${TRASH}/WorkBuddy备份清理_${stamp}"
  local manifest="${trash_dir}/_恢复清单.txt"

  report "===== WorkBuddy 备份清理 ====="
  report "执行时间: $(date '+%Y-%m-%d %H:%M:%S')"
  local rs sessions
  for rs in "${SESSION_ROOTS[@]}"; do
    sessions="${rs#*|}"
    report "会话目录: $sessions"
  done
  report "保留策略: 最近 ${KEEP_DAYS} 天"
  if [ "$APPLY" -eq 1 ]; then
    report "模式: 真实执行（移动到废纸篓）"
    report "废纸篓目录: $trash_dir"
  else
    report "模式: 预演（DRY-RUN，不会删除任何文件）"
  fi
  report ""

  local total_kb=0 total_files=0 n=0 empty=0 prot_n=0 prot_kb=0 prot_files=0
  local tag sid name path kb cnt old src dst
  while IFS='|' read -r tag sid name path kb cnt old; do
    [ -n "$sid" ] || continue
    if [ "$kb" -eq 0 ] && [ "$cnt" -eq 0 ]; then empty=$((empty+1)); continue; fi
    if [ "$old" != "1" ]; then
      prot_n=$((prot_n+1)); prot_kb=$((prot_kb+kb)); prot_files=$((prot_files+cnt)); continue
    fi
    n=$((n+1))
    total_kb=$((total_kb+kb)); total_files=$((total_files+cnt))
    src="$path"
    dst="${trash_dir}/${tag}/${sid}/${name}"
    if [ "$APPLY" -eq 1 ]; then
      mkdir -p "$(dirname "$dst")" || die "无法创建目录: $(dirname "$dst")"
      # 安全闸门二次校验：来源必须仍在白名单内且是真实目录
      case "$name" in
        modify_backup|modify_backup_v2|.modify_backup_meta) ;;
        *) die "白名单校验失败，拒绝移动: $src" ;;
      esac
      if [ -d "$src" ] && [ ! -L "$src" ]; then
        mv "$src" "$dst" 2>/dev/null || report "[警告] 移动失败（可能被占用）: $src"
      fi
      printf '原位置: %s\n废纸篓: %s\n大小: %s / %s 文件\n\n' "$src" "$dst" "$(human_size $kb)" "$cnt" >> "$manifest"
    fi
  done < <(collect_backups)

  report "符合条件: $n 项, $(human_size $total_kb)（$total_files 个文件）"
  [ "$empty" -gt 0 ] && report "另有 $empty 个空壳目录（0字节）已忽略，无需清理"
  if [ "$n" -eq 0 ]; then
    if [ "$prot_n" -gt 0 ]; then
      report "没有旧于 ${KEEP_DAYS} 天的备份。但检测到 $prot_n 项 / $(human_size $prot_kb)（$prot_files 个文件）属于最近 ${KEEP_DAYS} 天，被保留策略挡住了。"
      report "若确认要连这些近期备份一起清理：用菜单 4『全清预演』查看清单，确认后用菜单 5『全清执行』。"
    else
      report "没有需要清理的备份，结束。"
    fi
    return
  fi

  if [ "$APPLY" -eq 0 ]; then
    report ""
    report "这是预演，什么都没删。将清理的目录（占用最大的前 20 项）:"
    collect_backups | awk -F'|' '($5!=0 || $6!=0) && $7=="1" {printf "%s|%s\n",$5,"["$1"] "$4}' | sort -rn | head -20 | while IFS='|' read -r kb label; do
      report "  $(human_size "$kb")  $label"
    done
    report "（仅列出前 20 项，共 $n 项）"
    report "确认无误后用菜单 3 执行，或加 --apply。"
  else
    report "恢复清单: $manifest"
    report "恢复方法: 按清单里的「废纸篓」路径 mv 回「原位置」，或在访达废纸篓里手动放回。"
    report ""
    report "完成。建议启动 WorkBuddy 打开几条历史会话确认正常后再清空废纸篓。"
  fi
}

do_migrate(){
  [ -n "$MIGRATE_TARGET" ] || die "migrate 需要指定目标目录，例如: migrate /Volumes/SSD/wbdata"
  local running
  running=$(wb_running)
  if [ -n "$running" ]; then
    die "请先完全退出 WorkBuddy 再执行迁移。检测到: $(echo "$running" | head -1)"
  fi
  local src="${WB_HOME}/workspace"
  [ -d "$src" ] || die "找不到源目录: $src"
  [ ! -L "$src" ] || die "$src 已经是软链接，可能迁移过了"

  # 拒绝迁到自身内部
  case "$MIGRATE_TARGET" in
    "$src"/*|"$WB_HOME"/*) die "目标目录不能在 WorkBuddy 数据目录内部" ;;
  esac

  local dst="${MIGRATE_TARGET%/}/workspace"
  local bak="${src}.wbmove-backup"

  report "===== workspace 迁移（外接盘场景） ====="
  report "源: $src"
  report "目标: $dst"
  report "占用: $(human_size $(dir_size_kb "$src"))"
  if [ -e "$dst" ] && [ "$(find "$dst" -mindepth 1 -maxdepth 1 2>/dev/null | wc -l | tr -d ' ')" != "0" ]; then
    die "目标目录非空，为避免覆盖已停止: $dst"
  fi
  if [ "$APPLY" -eq 0 ]; then
    report "预演结束。加 --apply 才真正执行复制+建软链。"
    exit 0
  fi

  report "开始复制（cp -a，请耐心等待）..."
  mkdir -p "$dst" || die "无法创建目标目录"
  cp -a "$src"/. "$dst"/ || die "复制失败，源目录未改动"
  report "复制完成。校验文件数..."
  local sf df
  sf=$(find "$src" -type f 2>/dev/null | wc -l | tr -d ' ')
  df=$(find "$dst" -type f 2>/dev/null | wc -l | tr -d ' ')
  report "源文件数=$sf 目标文件数=$df"
  [ "$sf" = "$df" ] || die "文件数不一致，已保留源目录，请人工检查（目标: $dst）"

  report "改名源目录并建立软链接..."
  mv "$src" "$bak" || die "改名失败"
  if ! ln -s "$dst" "$src"; then
    mv "$bak" "$src"; die "建软链失败，已回滚"
  fi
  report "完成。请启动 WorkBuddy 验证历史会话和任务产物都正常。"
  report "验证无误后，手动删除备份目录以释放空间: $bak"
  report "如需回退: rm \"$src\" && mv \"$bak\" \"$src\""
}

# ========== 诊断（只读）==========
do_diagnose(){
  report "============================================================"
  report " 磁盘空间诊断（只读，不删任何东西）"
  report "============================================================"
  report ""
  report "---- 磁盘空间 ----"
  df -h / /System/Volumes/Data 2>/dev/null | awk 'NR==1 || /Volume|\/System\/Volumes\/Data|^Filesystem/ {print "  "$0}'

  report ""
  report "---- WorkBuddy 相关目录（主目录下所有 .workbuddy*）----"
  local found=0 d sz sess ssz scnt
  for d in "${HOME}"/.workbuddy*; do
    [ -d "$d" ] || continue
    found=1
    sz=$(dir_size_kb "$d")
    sess="${d}/workspace/sessions"
    if [ -d "$sess" ]; then
      ssz=$(dir_size_kb "$sess")
      scnt=$(file_count "$sess")
      report "  $(human_size $sz)  $d"
      report "               └─ sessions: $(human_size $ssz) / $scnt 文件"
    else
      report "  $(human_size $sz)  $d"
      report "               └─ 无 sessions 子目录"
    fi
  done
  [ "$found" -eq 0 ] && report "  未找到任何 .workbuddy* 目录"

  report ""
  report "---- 主目录下占用最大的目录 Top 15 ----"
  report "  （扫描可能较慢，请稍候；Library 通常最大属正常）"
  du -sk "${HOME}"/* "${HOME}"/.[!.]* 2>/dev/null | sort -rn | head -15 | while IFS="$(printf '\t')" read -r kb path; do
    report "  $(human_size "$kb")  $path"
  done

  report ""
  report "---- 废纸篓（备份文件常被删到这里）----"
  if [ -d "$TRASH" ]; then
    local tsz tc
    tsz=$(dir_size_kb "$TRASH")
    tc=$(file_count "$TRASH")
    report "  $(human_size $tsz)  $tc 个文件  $TRASH"
    if [ "$tc" -gt 100000 ]; then
      report "  警告: 废纸篓文件数超过 10 万，清空时可能很慢。"
    fi
  else
    report "  无法访问废纸篓"
  fi
  report ""
  report "诊断结束。把以上结果截图发回，即可判断空间去向。"
}

# ========== 主入口 ==========
case "$MODE" in
  scan) do_scan ;;
  clean) do_clean ;;
  migrate) do_migrate ;;
  diagnose) do_diagnose ;;
esac
