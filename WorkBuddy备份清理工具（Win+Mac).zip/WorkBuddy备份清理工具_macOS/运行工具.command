#!/bin/bash
# 双击运行入口：macOS 的 .command 文件会在终端打开
cd "$(dirname "$0")"

# 检查主脚本是否存在
if [ ! -f ./wb_backup_macos.sh ]; then
  echo "[错误] 找不到 wb_backup_macos.sh，请确认几个文件放在同一个文件夹。"
  echo "按回车键退出..."
  read -r _
  exit 1
fi
chmod +x ./wb_backup_macos.sh 2>/dev/null

while true; do
  clear
  echo "============================================================"
  echo " WorkBuddy 备份清理工具（macOS 版）"
  echo "============================================================"
  echo ""
  echo "  1) 扫描占用（只读，安全，先看这个）"
  echo "  2) 预演清理（不删，列出将清理什么）"
  echo "  3) 执行清理（移到废纸篓，可恢复）"
  echo "  4) 全清预演（含最近7天，不删）"
  echo "  5) 全清执行（含最近7天，移到废纸篓）"
  echo "  6) 诊断空间占用（只读，查磁盘空间去哪了）"
  echo "  0) 退出"
  echo ""
  printf " 请选择 [0-6]: "
  read -r choice
  case "$choice" in
    1) ./wb_backup_macos.sh scan ;;
    2) ./wb_backup_macos.sh clean ;;
    3) ./wb_backup_macos.sh clean --apply ;;
    4) ./wb_backup_macos.sh clean --keep-days 0 ;;
    5) ./wb_backup_macos.sh clean --keep-days 0 --apply ;;
    6) ./wb_backup_macos.sh diagnose ;;
    0) exit 0 ;;
    *) echo " 无效选择，请重新输入。" ;;
  esac
  echo ""
  printf "按回车键继续..."
  read -r _
done
