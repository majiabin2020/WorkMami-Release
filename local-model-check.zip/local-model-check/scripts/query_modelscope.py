#!/usr/bin/env python3
"""Query ModelScope for a model, its weights, and community quantized derivatives.

Standard library only. Never downloads model weights. Prints one JSON object.

Usage:
  python3 query_modelscope.py --model "MiniMax H3 Image"
  python3 query_modelscope.py --model "Qwen3-VL" --model-id Qwen/Qwen3-VL
  python3 query_modelscope.py --model "FLUX.2" --max-derivatives 16
"""

import argparse
import concurrent.futures
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = "https://www.modelscope.cn"
OPENAPI = BASE + "/openapi/v1/models"
FILES_API = BASE + "/api/v1/models/{mid}/repo/files?Recursive=true"
README_API = BASE + "/models/{mid}/resolve/{rev}/README.md"
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120 Safari/537.36"

VENDOR_WORDS = {
    "minimax", "qwen", "alibaba", "qwenlm", "deepseek", "tencent", "hunyuan",
    "meta", "llama", "google", "mistral", "zhipu", "baichuan", "internlm",
    "stability", "blackforestlabs", "flux", "openai", "microsoft", "nvidia",
    "baidu", "ernie", "moonshot", "kimi", "stepfun", "01ai", "yi",
}
QUANT_HINTS = [
    "gguf", "q4", "q5", "q8", "4bit", "8bit", "int4", "int6", "int8",
    "fp4", "fp8", "nvfp4", "gptq", "awq", "mlx", "quant", "prun",
    "distill", "lite", "low-vram", "lowvram", "16g", "8g", "small", "tiny",
]
WEIGHT_EXT = (".safetensors", ".gguf", ".bin", ".pt", ".pth", ".ckpt", ".onnx", ".sft")
NOISE = ["模型", "开源", "权重", "本地部署", "能不能跑", "能跑吗", "跑得动", "想跑",
         "部署", "最新版", "这个", "一下", "帮我说说"]


def fetch(url, timeout=20, raw_limit=300000):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read(raw_limit)
    return data.decode("utf-8", "replace")


def fetch_json(url, timeout=20):
    return json.loads(fetch(url, timeout=timeout))


def normalize(text):
    s = text.strip()
    for junk in NOISE:
        s = s.replace(junk, " ")
    s = re.sub(r"\s+", " ", s).strip()
    ascii_parts = re.findall(r"[A-Za-z0-9][A-Za-z0-9._\-]*", s)
    joined = " ".join(ascii_parts)
    if len(joined) >= 3:
        return joined
    return s or text.strip()


def build_terms(user_input):
    clean = normalize(user_input)
    parts = [p for p in re.split(r"[\s\-_]+", clean) if p]
    if not parts:
        parts = [clean or "model"]
    primary = "-".join(parts)
    if len(parts) >= 3 and parts[0].lower() in VENDOR_WORDS:
        key = parts[1:]
    else:
        key = parts
    short = "-".join(key) if key else primary
    terms = [primary]
    for candidate in [short, short + "-GGUF", short + "-FP8", short + "-MLX"]:
        if candidate.lower() not in [t.lower() for t in terms]:
            terms.append(candidate)
    return clean, terms, key


def is_relevant(model_id, key_tokens):
    if not key_tokens:
        return True
    low_id = model_id.lower()
    norm = re.sub(r"[^a-z0-9]", "", low_id)
    need = key_tokens if len(key_tokens) <= 2 else key_tokens[-2:]
    for token in need:
        token = token.lower()
        clean_token = re.sub(r"[^a-z0-9]", "", token)
        if clean_token:
            if clean_token not in norm:
                return False
        elif token not in low_id:
            return False
    return True


def hints_for(model):
    text = (model.get("id", "") + " " + " ".join(model.get("tags", []))).lower()
    return [h for h in QUANT_HINTS if h in text]


def search(term):
    url = OPENAPI + "?" + urllib.parse.urlencode(
        {"search": term, "page_size": 40, "sort": "downloads"})
    try:
        data = fetch_json(url)
        return data.get("data", {}).get("models", []) or []
    except Exception as exc:
        return {"_error": str(exc)}


def compact(model):
    return {
        "id": model.get("id", ""),
        "display_name": model.get("display_name", ""),
        "file_size_gb": round(model.get("file_size", 0) / 1e9, 2),
        "params_b": round(model.get("params", 0) / 1e9, 1),
        "downloads": model.get("downloads", 0),
        "likes": model.get("likes", 0),
        "created_at": model.get("created_at", ""),
        "last_modified": model.get("last_modified", ""),
        "license": model.get("license", ""),
        "tasks": model.get("tasks", []),
        "quant_hints": hints_for(model),
        "url": BASE + "/models/" + model.get("id", ""),
    }


def file_summary(mid):
    url = FILES_API.format(mid=mid)
    try:
        data = fetch_json(url, timeout=25)
        files = data.get("Data", {}).get("Files", []) or []
    except Exception as exc:
        return {"checked": False, "error": str(exc)}
    blobs = [f for f in files if f.get("Type") == "blob"]
    weights = [f for f in blobs
               if f.get("Path", "").lower().endswith(WEIGHT_EXT)
               and f.get("Size", 0) > 50_000_000]
    big = sorted(blobs, key=lambda f: f.get("Size", 0), reverse=True)[:12]
    folder_bytes = {}
    for f in blobs:
        path = f.get("Path", "")
        top = path.split("/")[0] if "/" in path else "(根目录)"
        folder_bytes[top] = folder_bytes.get(top, 0) + f.get("Size", 0)
    sorted_weights = sorted(weights, key=lambda f: -f.get("Size", 0))
    return {
        "checked": True,
        "total_files": len(blobs),
        "total_gb": round(sum(f.get("Size", 0) for f in blobs) / 1e9, 2),
        "weight_file_count": len(weights),
        "weight_gb": round(sum(f.get("Size", 0) for f in weights) / 1e9, 2),
        "has_weights": len(weights) > 0,
        "largest_files": [
            {"path": f.get("Path", ""), "gb": round(f.get("Size", 0) / 1e9, 2)}
            for f in big
        ],
        "folders": sorted({f.get("Path", "").split("/")[0]
                           for f in blobs if "/" in f.get("Path", "")}),
        "folder_sizes_gb": {
            k: round(v / 1e9, 2)
            for k, v in sorted(folder_bytes.items(), key=lambda x: -x[1])
        },
        "weight_files": [
            {"path": f.get("Path", ""), "gb": round(f.get("Size", 0) / 1e9, 2)}
            for f in sorted_weights[:20]
        ],
        "weight_files_truncated": len(sorted_weights) > 20,
    }


def read_readme(mid, limit):
    for rev in ("master", "main"):
        try:
            text = fetch(README_API.format(mid=mid, rev=rev), timeout=20,
                         raw_limit=limit * 3)
            if text and "404" not in text[:200]:
                return text[:limit]
        except Exception:
            continue
    return ""


REPACK_OWNERS = {"comfy-org", "unsloth", "gguf-org", "diffsynth-studio",
                 "ai-modelscope", "atomicchat", "prithivmlmods"}
NOT_FULL_BUILD = ("adapter", "lora", "primer", "patch", "training", "dataset",
                  "docker", "demo", "studio", "canvas", "config", "scripts",
                  "release", "template", "workflow", "test", "sample", "hybrid")
AUXILIARY_RE = re.compile(
    r"(^|[-_])(pe|mtp|repack(ed)?|prompt|expander|expansion|encoder|vae|tokenizer)([-_]|$)",
    re.I)


def pick_official(models, clean, vendor_hint=""):
    target = re.sub(r"[^a-z0-9]", "", clean.lower()) or clean.lower()
    exact = [m for m in models
             if re.sub(r"[^a-z0-9]", "", m["display_name"].lower()) == target]
    pool = exact or models
    plain = [m for m in pool if not m["quant_hints"]]
    pool = plain or pool
    if vendor_hint:
        by_owner = [m for m in pool
                    if m["id"].split("/")[0].lower() == vendor_hint.lower()]
        if by_owner:
            return max(by_owner, key=lambda m: m["downloads"])
    native = [m for m in pool
              if m["id"].split("/")[0].lower() not in REPACK_OWNERS]
    return max(native or pool, key=lambda m: m["downloads"])


def full_build_candidates(derivatives, official_size):
    floor = max(0.3, official_size * 0.04) if official_size else 0.3
    kept = []
    for m in derivatives:
        name = m["id"].lower()
        short = name.split("/")[-1]
        if any(bad in name for bad in NOT_FULL_BUILD):
            continue
        if AUXILIARY_RE.search(short):
            continue
        if m["file_size_gb"] < floor:
            continue
        kept.append(m)
    return sorted(kept, key=lambda m: m["file_size_gb"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, help="Model name as the user said it")
    ap.add_argument("--model-id", default="", help="Known ModelScope repo id, optional")
    ap.add_argument("--max-derivatives", type=int, default=14)
    ap.add_argument("--readme-chars", type=int, default=14000)
    args = ap.parse_args()

    clean, terms, key_tokens = build_terms(args.model)
    vendor_hint = terms[0].split("-")[0] if terms else ""
    warnings = []
    results = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        for term, outcome in zip(terms, pool.map(search, terms)):
            if isinstance(outcome, dict):
                warnings.append("搜索词 " + term + " 失败: " + outcome.get("_error", "unknown"))
                continue
            for m in outcome:
                results[m.get("id", "")] = m

    if args.model_id and args.model_id not in results:
        one = search(args.model_id)
        if isinstance(one, list):
            for m in one:
                results[m.get("id", "")] = m

    models = [compact(m) for m in results.values() if m.get("id")]
    filtered = [m for m in models if is_relevant(m["id"], key_tokens)]
    if filtered:
        models = filtered
    elif models:
        warnings.append("相关性过滤后没有剩余，已保留原始搜索结果，需要人工确认是不是同一个模型。")
    models.sort(key=lambda m: -m["downloads"])

    if not models:
        warnings.append("魔搭没搜到匹配的模型，建议换关键词，或用网页搜索确认模型的准确名字与发布方。")

    official = pick_official(models, clean, vendor_hint) if models else None
    official_id = official["id"] if official else ""
    derivatives = [m for m in models if m["id"] != official_id]

    # Verify real weight files on the official repo and the smallest full builds.
    candidates = full_build_candidates(
        derivatives, official["file_size_gb"] if official else 0)
    small_pool = candidates[:5]
    check_ids = ([official_id] if official_id else []) + [m["id"] for m in small_pool]
    summaries = {}
    if check_ids:
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for mid, summary in zip(check_ids, pool.map(file_summary, check_ids)):
                summaries[mid] = summary

    smallest = sorted(
        [m for m in small_pool if summaries.get(m["id"], {}).get("has_weights")],
        key=lambda m: m["file_size_gb"])[:3]
    if not smallest and models:
        warnings.append("没找到体积明显更小且确认带完整权重的第三方版本，结论里别把以后会有精简版说得太确定。")

    weights_released = bool(official_id and summaries.get(official_id, {}).get("has_weights"))
    if not weights_released:
        weights_released = any(summaries.get(m["id"], {}).get("has_weights")
                               for m in candidates)

    readme = read_readme(official_id, args.readme_chars) if official_id else ""
    if not readme:
        warnings.append("没读到官方模型卡正文，硬件要求需要用网页搜索补充。")

    out = {
        "query": args.model,
        "normalized_query": clean,
        "checked_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "search_terms": terms,
        "key_tokens": key_tokens,
        "total_matching_repos": len(models),
        "weights_released": weights_released,
        "official": official,
        "official_weight_files": summaries.get(official_id, {}),
        "derivatives": derivatives[:args.max_derivatives],
        "smallest_community_builds": smallest,
        "community_min_full_build_gb": smallest[0]["file_size_gb"] if smallest else None,
        "community_candidates_checked": len(small_pool),
        "community_file_details": {k: v for k, v in summaries.items() if k != official_id},
        "readme_excerpt": readme,
        "warnings": warnings,
    }
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
