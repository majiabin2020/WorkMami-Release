#!/usr/bin/env python3
"""Detect this computer's hardware for the local-model-check skill.

Standard library only, read-only, no admin rights, no downloads.
Prints one JSON object. Run it on the machine that would actually run the model.

Usage:
  python3 detect_hardware.py
"""

import json
import os
import platform
import re
import shutil
import subprocess
import sys


def run(cmd, timeout=20, shell=False):
    try:
        proc = subprocess.run(cmd, shell=shell, capture_output=True,
                              text=True, errors="replace", timeout=timeout)
        if proc.returncode == 0:
            return (proc.stdout or "").strip()
    except Exception:
        pass
    return ""


def nvidia_smi():
    out = run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version",
               "--format=csv,noheader,nounits"], timeout=12)
    gpus = []
    for line in out.splitlines():
        bits = [x.strip() for x in line.split(",")]
        if len(bits) < 2:
            continue
        try:
            vram = round(int(float(bits[1])) / 1024.0, 1)
        except ValueError:
            vram = None
        gpus.append({"name": bits[0], "vram_gb": vram, "vendor": "nvidia",
                     "source": "nvidia-smi",
                     "driver": bits[2] if len(bits) > 2 else ""})
    return gpus


def disk_free_gb():
    try:
        target = os.path.expanduser("~")
        if platform.system() == "Windows":
            target = os.environ.get("SystemDrive", "C:") + os.sep
        return round(shutil.disk_usage(target).free / 1e9, 1)
    except Exception:
        return None


def parse_physical_memory(text):
    m = re.search(r"([\d.,]+)\s*(GB|TB|MB)", text, re.I)
    if not m:
        return None
    value = float(m.group(1).replace(",", ""))
    unit = m.group(2).upper()
    if unit == "TB":
        return round(value * 1000, 1)
    if unit == "MB":
        return round(value / 1000, 1)
    return round(value, 1)


def detect_macos():
    info = {"os": "macOS " + platform.mac_ver()[0], "arch": platform.machine()}
    info["apple_silicon"] = info["arch"] == "arm64"
    cpu = run(["sysctl", "-n", "machdep.cpu.brand_string"], timeout=8)
    ram = None
    hw = run(["system_profiler", "SPHardwareDataType", "-json"], timeout=30)
    if hw:
        try:
            for group in json.loads(hw).values():
                for item in group:
                    cpu = item.get("chip_type") or item.get("cpu_type") or cpu
                    ram = parse_physical_memory(item.get("physical_memory", "")) or ram
        except Exception:
            pass
    if ram is None:
        raw = run(["sysctl", "-n", "hw.memsize"], timeout=8)
        try:
            ram = round(int(raw) / 1e9, 1)
        except ValueError:
            ram = None
    info["cpu"] = cpu or "unknown"
    info["ram_gb"] = ram

    gpus = []
    notes = []
    disp = run(["system_profiler", "SPDisplaysDataType", "-json"], timeout=30)
    if disp:
        try:
            for group in json.loads(disp).values():
                for item in group:
                    name = item.get("sppci_model") or item.get("_name") or "unknown GPU"
                    vram = item.get("spdisplays_vram")
                    vram_gb = None
                    if vram:
                        m = re.search(r"(\d+)", str(vram))
                        if m:
                            vram_gb = round(int(m.group(1)) / 1024, 1)
                    vendor = "apple" if "apple" in name.lower() else (
                        "nvidia" if "nvidia" in name.lower() else "amd/other")
                    gpus.append({"name": name, "vram_gb": vram_gb,
                                 "vendor": vendor, "source": "system_profiler"})
        except Exception:
            notes.append("显卡信息解析失败，需要人工确认型号。")
    for card in nvidia_smi():
        if not any(card["name"][:12] in g["name"] for g in gpus):
            gpus.append(card)
    if info["apple_silicon"]:
        notes.append("Apple 芯片是统一内存，内存和显存共用一份，不能把两者相加。")
    elif any(g["vendor"] == "nvidia" for g in gpus):
        notes.append("Intel Mac 上的 NVIDIA 卡在 macOS 里没有驱动，只有装 Windows 或 Linux 才能用上 CUDA。")
    info["gpus"] = gpus
    return info, notes


def detect_windows():
    info = {"os": "Windows " + platform.release(), "arch": platform.machine(),
            "apple_silicon": False}
    notes = []
    ps = lambda script: run(["powershell", "-NoProfile", "-Command", script], timeout=30)
    info["cpu"] = ps("(Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name)") or "unknown"
    raw_mem = ps("(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory")
    try:
        info["ram_gb"] = round(int(raw_mem) / 1e9, 1)
    except ValueError:
        info["ram_gb"] = None

    gpus = nvidia_smi()
    raw_cards = ps("Get-CimInstance Win32_VideoController | ForEach-Object { \"$($_.Name)|$($_.AdapterRAM)\" }")
    for line in raw_cards.splitlines():
        if "|" not in line:
            continue
        name, size = line.rsplit("|", 1)
        name = name.strip()
        if any(name[:12] in g["name"] for g in gpus):
            continue
        try:
            size_int = int(size.strip())
            vram = round(size_int / 1e9, 1)
            if vram < 0.5 or vram > 64:
                vram = None
                notes.append("Windows 报告的 " + name + " 显存数字不可信，已忽略，请用显卡型号核对。")
        except ValueError:
            vram = None
            notes.append("显卡 " + name + " 的显存没读到，请用显卡型号核对。")
        vendor = "nvidia" if "nvidia" in name.lower() else (
            "amd" if "amd" in name.lower() or "radeon" in name.lower() else "intel/other")
        gpus.append({"name": name, "vram_gb": vram, "vendor": vendor,
                     "source": "WMI"})
    if not gpus:
        notes.append("没检测到独立显卡，需要人工确认。")
    if not any(g["source"] == "nvidia-smi" for g in gpus):
        notes.append("没有 nvidia-smi 数据，显存容量最好对照显卡型号再确认一次。")
    info["gpus"] = gpus
    return info, notes


def detect_linux():
    info = {"os": "Linux " + platform.release(), "arch": platform.machine(),
            "apple_silicon": False}
    notes = []
    cpu = ""
    try:
        with open("/proc/cpuinfo", "r", errors="replace") as fh:
            for line in fh:
                if line.lower().startswith("model name"):
                    cpu = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    info["cpu"] = cpu or run(["sh", "-c", "lscpu | grep -m1 'Model name'"], timeout=10) or "unknown"
    ram = None
    try:
        with open("/proc/meminfo", "r", errors="replace") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    ram = round(int(line.split()[1]) / 1048576.0, 1)
                    break
    except OSError:
        pass
    info["ram_gb"] = ram
    gpus = nvidia_smi()
    if not gpus:
        lspci = run(["sh", "-c", "lspci -nn 2>/dev/null | grep -Ei 'vga|3d|display'"], timeout=12)
        for line in lspci.splitlines():
            gpus.append({"name": line.strip()[:120], "vram_gb": None,
                         "vendor": "unknown", "source": "lspci"})
        if gpus:
            notes.append("只读到显卡型号，显存容量需要对照型号确认。")
    info["gpus"] = gpus
    return info, notes


def main():
    system = platform.system()
    if system == "Darwin":
        info, notes = detect_macos()
    elif system == "Windows":
        info, notes = detect_windows()
    else:
        info, notes = detect_linux()
    info["disk_free_gb"] = disk_free_gb()
    info["python"] = platform.python_version()
    if info.get("ram_gb") is None:
        notes.append("内存容量没读到，必须补上才能判断。")
    if info.get("disk_free_gb") is not None and info["disk_free_gb"] < 60:
        notes.append("系统盘剩余空间不到 60GB，光下载模型文件就可能不够。")
    info["notes"] = notes
    print(json.dumps(info, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
