# 模型路由 —— 把 3D 代码交给用户选定的那个模型

## 这个文件解决什么

模型闸门要保证"写 3D 代码的环节跑在强模型上"。做到这一件事靠的是**子代理的 `model` 参数按精确 id 路由**，不是靠用户自己去设置面板上的模型。

用户只做一件事：说出一个模型名。剩下的——选 id、起子代理、喂规格包、验收、返修——全部是本 skill 的活。用户不换会话、不复制粘贴、不懂 id。

## 三个必须记住的事实

**一、路由用精确 id，不是界面显示名。**
`MiMo-V2.6-Pro` 是显示名，`mimo-v2.6-pro` 才是 id。两者对不上，传显示名路由不会生效。

**二、不同 model 的子代理必须串行发起。**
同一批并行发多个不同 `model` 的子代理，它们会**全部跑到第一个 model 上**——第一个的参数泄漏到后面几个。同一个 model 的子代理可以并发。这条是实测出来的，不是推测。

**三、当前会话模型可以探测，但它不影响代码环节的产出。**
`echo $CODEBUDDY_CURRENT_MODEL_ID` 给出当前会话实际跑在哪个模型上。它决定"要不要提醒用户当前会话偏弱"，但代码环节是独立路由出去的，当前会话弱不影响 3D 代码的质量。

## 平台模型清单怎么取

平台内置模型清单在本地产品配置缓存里：

```bash
ls -t ~/.workbuddy/cache/acc-product-config-v3-*.json | head -1
```

取 `models` 数组，每条有 `id` / `name` 两个字段：

```bash
python3 - <<'PY'
import json, glob, os
f = sorted(glob.glob(os.path.expanduser('~/.workbuddy/cache/acc-product-config-v3-*.json')))[-1]
cfg = json.load(open(f, encoding='utf-8'))
for m in cfg['models']:
    print(f"{m.get('id'):<28} | {m.get('name')}")
PY
```

平台会增删模型，**每次用之前重新跑一次**，不要照抄任何文档里的清单，包括本文件。

## 课件场景的推荐档

| 精确 id | 界面显示名 | 特点 | 什么时候选 |
|---|---|---|---|
| `mimo-v2.6-pro` | Xiaomi MiMo-V2.6-Pro | 3D 代码正确性与着色器最干净 | 默认首选 |
| `space-bunny` | Space-Bunny | 场景构图与视觉表现有想法，代码也稳 | 想要画面有设计感 |
| `kimi-k3.1-pro` | Kimi-K3.1-Pro | 前端审美强，多轮改稿稳 | 界面与排版要讲究 |
| `deepseek-v4-pro` | DeepSeek-V4-Pro | 出初稿快 | 先看整体再迭代 |
| `deepseek-v4.1-flash` | DeepSeek-V4.1-Flash | 轻量档 | 只在赶时间、能接受打折扣 |

`fast-model` / `balanced-model` / `deep-model` 是**路由别名**（快速 / 均衡 / 极致），具体指哪档由平台决定，做 3D 代码不要选它们。

## 规格包要带什么

子代理看不到主会话，规格包必须自包含：完整提示词、步骤脚本表、图层清单与默认开关、教材口径（Slot B 的原话与禁用词）、骨架路径与五面板结构约束、三条视觉硬规范（写成约束不是形容词）、输出路径与文件名、完成标准（离线可开、无 CDN、`verify_courseware.py --strict` 通过）。

## 路由失败怎么办

- **路由成功但产出不对**：用 `Agent(resume="<上次 id>")` 带缺陷清单继续，不要新开一个子代理重做。
- **子代理工具不可用 / id 不可路由**：降级——把规格包落成一份可复制文件交给用户，说明这条路要他自己切模型后粘贴。
- **平台模型被下架**：重新跑清单脚本取最新 id，别用失效 id。

## 与 `~/.workbuddy/models.json` 的区别

`~/.workbuddy/models.json` 是**用户自定义的代理模型配置**（走自己的 API 端点），不是平台内置清单。不要拿它当 id 来源。
