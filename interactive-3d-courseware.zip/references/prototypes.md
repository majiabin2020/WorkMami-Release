# 四类知识原型 → 交互套路

Strip away the subject label and every K-12 knowledge point falls into four spatial prototypes. Identify the prototype first; the interaction pattern follows.

## ① 空间结构类 (spatial structure)

- **Subjects**: 数学立体几何, 生物细胞/人体结构, 地理地貌/地球仪, 物理电路, 化学晶体/分子结构
- **Student blocker**: cannot see the inside, the back side, or a cross-section from a flat page
- **Interaction**: 360° drag-rotate · cutaway/section plane · layer toggles · zoom into detail · explode/assemble
- **Live data**: dimensions, angles, part names on hover
- **Design note**: default to a cutaway or exploded view; a closed opaque solid teaches nothing. Add a "课本图对照" preset so students can map the free-rotated model back to the textbook side view.

## ② 动态过程类 (dynamic process)

- **Subjects**: 地理地球运动/水循环, 生物分裂/免疫/膜运输, 化学反应过程, 物理运动/电路暂态, 历史演进
- **Student blocker**: the process is continuous and invisible in a still frame; cause and effect are separated in time
- **Interaction**: timeline scrub · play/pause · speed control (1x/10x/1 day per second) · step advance · parameter that changes the outcome
- **Live data**: whatever quantity changes with time — subsolar latitude, concentration, velocity, day length
- **Design note**: dual timeline (date + time of day) when both matter. Always include one "what if" parameter that breaks the process (set tilt to 0, remove helper T cells, reverse current) — this is the 「非它不可」 moment for this prototype.

## ③ 变量规律类 (variable law)

- **Subjects**: 数学函数, 物理定律, 化学周期律/平衡, 政治经济曲线
- **Student blocker**: formula is abstract; changing a coefficient's effect is hard to hold in mind
- **Interaction**: sliders on parameters · live curve/geometry redraw · readouts that update together · compare two states side by side
- **Live data**: parameter values, dependent variables, plotted points
- **Design note**: keep at most 3–4 parameters visible. Lock the axis range so the change is perceptible; an auto-scaling axis hides the effect.

## ④ 场景沉浸类 (immersive scene)

- **Subjects**: 语文古诗情境, 英语对话场景, 历史现场, 政治模拟议事
- **Student blocker**: no sense of place, no emotional or decision stake
- **Interaction**: first-person roam · viewpoint switching · role selection · branching choices with consequences
- **Live data**: minimal — a task checklist or a dialogue log rather than numeric readouts
- **Design note**: this prototype has the weakest 3D necessity. Be honest: if a scene adds no teaching value over a video, tell the user not to build it. When it does, anchor the scene to a single decision the student must make.

## Mixed prototypes

A chapter can combine two. Earth motion = ② (process) + ① (structure). Cell lab = ① (structure) + ② (transport process). Pick the dominant one for navigation; add the secondary as a view mode or a layer group.
