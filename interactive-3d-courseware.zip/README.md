# interactive-3d-courseware · 十二科 3D 交互课件总 skill

把一个教材章节或知识点，做成**单文件 HTML、双击即开、断网可用**的 3D 交互课件。

## 装哪

解压后把整个 `interactive-3d-courseware/` 目录放进 skills 目录：

- macOS / Linux：`~/.workbuddy/skills/interactive-3d-courseware/`
- Windows：`%USERPROFILE%\.workbuddy\skills\interactive-3d-courseware\`

平台会**运行时动态发现** skill，包括 `skills/` 下的子 skill，所以装完直接用，不用重启。

## 怎么用

在对话里直接说需求，比如「做一个地球自转的 3D 课件」「做一节中和滴定的虚拟实验」。

总 skill 会按学科路由到对应的子 skill：

| 学科 | 子 skill | 学科 | 子 skill |
|---|---|---|---|
| 地理 | `courseware-geography` | 历史 | `courseware-history` |
| 物理 | `courseware-physics` | 政治 | `courseware-politics` |
| 化学 | `courseware-chemistry` | 体育 | `courseware-pe` |
| 生物 | `courseware-biology` | 美术 | `courseware-art` |
| 数学 | `courseware-math` | 音乐 | `courseware-music` |
| 语文 | `courseware-chinese` | 英语 | `courseware-english` |

也可以按名直接调某个子 skill：`Skill(skill="courseware-physics")`。

## 目录结构

```
SKILL.md                      总 skill：共享工艺规范 + 12 科路由表
skills/courseware-<key>/      12 个学科子 skill（各有学科专属配置与红线）
references/                   共享规范（视觉三硬规 / 实验型 / 模型路由 / 提示词 / 验收 / 原型）
scripts/                      子 skill 生成器 + 两道机检
assets/                       五件套 HTML 骨架 + 音频探针
```

## 三件需要你自己准备的东西

这个 skill 不替你编教材口径。开工前有两槽必须人填：

1. **非它不可的交互** —— 这节课学生必须自己动手才能看出的东西是什么。
2. **教材口径原话** —— 数字、定义、定理，要和课本逐字对得上。

还有一件：选模型。skill 会问你想用哪个模型来写 3D 代码，然后**自己把那个模型拉进来写**（不用你切会话、不用复制粘贴、不丢上下文）。可选模型 id 见 `references/model-routing.md`。

## 验收：两道机检 + 一次目视

```bash
python3 scripts/verify_courseware.py 成品.html --strict     # 静态：结构、五件套、贴图/动效/单一真相源的存在性
node scripts/smoke_courseware.cjs 成品.html --out ./shots    # 运行时：控制台零错误 + 画面真画出来了 + 控件在位
```

两道都过，**仍不等于画面达标**。`--strict` 只验机制在不在，验不出多边形折面和构图塌陷。最后那一眼目视不能省。

跑 `smoke_courseware.cjs` 需要 playwright-core：`npm i -g playwright && npx playwright install chromium`，或设 `PW_CORE=/绝对路径/playwright-core`。

## 加第 13 科

在 `scripts/build_subjects.py` 的 `SUBJECTS` 表里加一行，在 `skills/` 下建 `courseware-<key>/SKILL.md`，跑 `python3 scripts/build_subjects.py`。共享铁规摘要只有脚本里那一份，改一次全部重生成，**不要手抄 13 份**。
