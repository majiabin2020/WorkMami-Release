// smoke_courseware.cjs —— 浏览器实跑冒烟
//
// 与 verify_courseware.py 的分工：
//   verify_courseware.py  = 静态机检（结构、五件套、贴图/动效/单一真相源的存在性）
//   本脚本                = 运行时实检（控制台错误、画面是否真的画出来了、交互控件在不在）
//
// 两者都过 ≠ 画面达标（机检只验存在性，不验面数与构图），目视截图仍不可省。
//
// 用法：
//   node scripts/smoke_courseware.cjs <文件或目录> [...] [--out 目录] [--wait 毫秒] [--keep]
//   目录会被递归扫描，自动挑出所有 .html
//
// 退出码：0 = 全部通过；1 = 有失败项；2 = 环境不可用（找不到 playwright-core 或浏览器）
//
// 依赖解析顺序（任一命中即可）：
//   playwright-core  → PW_CORE 环境变量 → 本地 node_modules → npm root -g
//                    → ~/.workbuddy/binaries/node/versions/*/lib/node_modules 下的 @playwright/cli
//   浏览器          → CHROME_PATH 环境变量 → macOS/Linux 常见安装路径 → playwright 自带 chromium

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execSync } = require('child_process');
const { pathToFileURL } = require('url');

// ---------- 参数 ----------
const argv = process.argv.slice(2);
let outDir = path.join(process.cwd(), '.smoke-out');
let waitMs = 4000;
let targets = [];
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--out') outDir = path.resolve(argv[++i]);
  else if (a === '--wait') waitMs = parseInt(argv[++i], 10) || 4000;
  else if (a === '--keep') { /* 预留：保留截图（默认也保留，置此开关仅为兼容旧调用） */ }
  else targets.push(a);
}
if (!targets.length) {
  console.error('用法：node smoke_courseware.cjs <文件或目录> [...] [--out 目录] [--wait 毫秒]');
  process.exit(2);
}

// ---------- 依赖探测 ----------
function tryRequire(p) {
  try { return require(p); } catch (e) { return null; }
}

function findPlaywright() {
  const cands = [];
  if (process.env.PW_CORE) cands.push(process.env.PW_CORE);
  cands.push('playwright-core', 'playwright');
  try {
    const g = execSync('npm root -g', { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
    cands.push(path.join(g, 'playwright-core'), path.join(g, 'playwright'),
      path.join(g, '@playwright', 'cli', 'node_modules', 'playwright-core'));
  } catch (e) { /* npm 不在 PATH 也无所谓 */ }
  // WorkBuddy 自带 node 运行时下的 @playwright/cli
  const verRoot = path.join(os.homedir(), '.workbuddy', 'binaries', 'node', 'versions');
  try {
    for (const v of fs.readdirSync(verRoot)) {
      cands.push(path.join(verRoot, v, 'lib', 'node_modules', '@playwright', 'cli', 'node_modules', 'playwright-core'));
    }
  } catch (e) { /* 没有这个目录就跳过 */ }
  for (const c of cands) {
    const m = tryRequire(c);
    if (m && m.chromium) return { mod: m, from: c };
  }
  return null;
}

function findBrowser() {
  const cands = [];
  if (process.env.CHROME_PATH) cands.push(process.env.CHROME_PATH);
  if (process.platform === 'darwin') {
    cands.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Chromium.app/Contents/MacOS/Chromium',
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
      '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser');
  } else {
    cands.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable',
      '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge');
  }
  for (const c of cands) {
    try { if (c && fs.existsSync(c)) return c; } catch (e) { /* ignore */ }
  }
  return null; // 交给 playwright 自带 chromium
}

const pw = findPlaywright();
if (!pw) {
  console.error('[环境不可用] 找不到 playwright-core。任选其一：');
  console.error('  npm i -g playwright && npx playwright install chromium');
  console.error('  或设置 PW_CORE=/绝对路径/playwright-core');
  process.exit(2);
}
const browserExe = findBrowser();
console.log(`playwright-core: ${pw.from}`);
console.log(`browser: ${browserExe || 'playwright 自带 chromium'}`);
console.log('');

// ---------- 收集待测文件 ----------
function collect(p) {
  const abs = path.resolve(p);
  const st = fs.statSync(abs);
  if (st.isFile()) return abs.toLowerCase().endsWith('.html') ? [abs] : [];
  const out = [];
  (function walk(dir) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const fp = path.join(dir, e.name);
      if (e.isDirectory()) { if (e.name !== 'node_modules' && e.name[0] !== '.') walk(fp); }
      else if (e.name.toLowerCase().endsWith('.html')) out.push(fp);
    }
  })(abs);
  return out.sort();
}
let files = [];
for (const t of targets) {
  if (!fs.existsSync(t)) { console.error(`[跳过] 路径不存在：${t}`); continue; }
  files = files.concat(collect(t));
}
files = Array.from(new Set(files));
if (!files.length) { console.error('没有找到 .html 文件'); process.exit(2); }

fs.mkdirSync(outDir, { recursive: true });

// ---------- 跑 ----------
(async () => {
  const launchOpts = { headless: true };
  if (browserExe) launchOpts.executablePath = browserExe;
  const browser = await pw.mod.chromium.launch(launchOpts);
  const rows = [];

  for (const abs of files) {
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    const errs = [];
    page.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + m.text().slice(0, 180)); });
    page.on('pageerror', (e) => errs.push('pageerror: ' + String(e.message).slice(0, 180)));
    const r = { file: abs, name: path.basename(abs), errs, canvas: 0, full: 0, ctl: 0, size: fs.statSync(abs).size };
    const tag = path.basename(abs).replace(/\.html$/i, '').slice(0, 28);
    try {
      await page.goto(pathToFileURL(abs).href, { waitUntil: 'load', timeout: 30000 });
      await page.waitForTimeout(waitMs);
      if (await page.locator('canvas').count() > 0) {
        const c = page.locator('canvas').first();
        const box = await c.boundingBox();
        if (box && box.width > 0) {
          const buf = await c.screenshot({ path: path.join(outDir, `canvas_${tag}.png`) });
          r.canvas = buf.length;
        }
      }
      const full = await page.screenshot({ path: path.join(outDir, `full_${tag}.png`) });
      r.full = full.length;
      r.ctl = await page.evaluate(() => document.querySelectorAll('button,input[type=range],input[type=button]').length);
    } catch (e) {
      errs.push('fatal: ' + String(e.message).slice(0, 160));
    }
    await page.close();
    rows.push(r);
  }
  await browser.close();

  // ---------- 判定 ----------
  // canvas 元素截图 PNG 字节数 > 12000 才算"画面真的画出来了"（纯色 canvas 只有几 KB）
  // 整页 PNG > 60000 是没有 canvas 时的兜底（纯 2D 课件）
  console.log('文件'.padEnd(30) + '体积'.padStart(8) + 'canvasPNG'.padStart(11) + '整页PNG'.padStart(11) + '控件'.padStart(6) + '  控制台');
  console.log('─'.repeat(88));
  let bad = 0;
  for (const r of rows) {
    const hasPix = r.canvas > 12000 || r.full > 60000;
    const ok = r.errs.length === 0 && hasPix && r.ctl > 0;
    if (!ok) bad++;
    console.log(
      r.name.slice(0, 28).padEnd(30) +
      ((r.size / 1024).toFixed(0) + 'K').padStart(8) +
      (r.canvas + 'B').padStart(11) +
      (r.full + 'B').padStart(11) +
      String(r.ctl).padStart(6) +
      '  ' + (r.errs.length === 0 ? (ok ? '0 ✓' : '0 ✗') : r.errs.length + ' ✗')
    );
    if (r.errs.length) {
      r.errs.slice(0, 3).forEach((e) => console.log('      └ ' + e));
    } else if (!ok) {
      // 没有控制台错误却判失败，必须说清是哪一条不满足
      const why = [];
      if (r.canvas === 0) why.push('没有 canvas');
      else if (r.canvas <= 12000) why.push(`canvas 截图仅 ${r.canvas}B（纯色画布的典型特征）`);
      if (r.full <= 60000) why.push(`整页截图仅 ${r.full}B`);
      if (r.ctl === 0) why.push('没有交互控件');
      console.log('      └ 不满足：' + why.join('；') + '。若该文件本就不是成品课件（模板/探针页），可忽略。');
    }
  }
  console.log('─'.repeat(88));
  console.log(bad === 0
    ? `冒烟结论：${rows.length}/${rows.length} 通过（零控制台错误 + 画面非空 + 交互控件在位）`
    : `冒烟结论：${bad} 份有问题（共 ${rows.length} 份）`);
  console.log('截图目录：' + outDir);
  fs.writeFileSync(path.join(outDir, 'report.json'), JSON.stringify(rows, null, 2));
  process.exit(bad === 0 ? 0 : 1);
})().catch((e) => { console.error('运行失败：', e); process.exit(2); });
