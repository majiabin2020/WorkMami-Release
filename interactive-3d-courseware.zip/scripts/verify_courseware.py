#!/usr/bin/env python3
"""Structure + visual-quality check for a 3D courseware HTML file.

Deterministic, dependency-free pre-flight check. It is NOT a substitute for a
real browser interaction pass: it only proves that the required *mechanisms*
exist, not that they behave correctly.

Two layers:
  1. Structure  — five panels, interaction hooks, offline killers, debug hook.
  2. Visual     — the three hard rules in references/visual-quality.md:
                  real embedded textures / time-based reversible motion /
                  single source of truth for simulated quantities.
                  Only run with --strict (or --visual). A file carrying the
                  <!-- SKELETON --> marker skips layer 2 by design.

Usage:
    python verify_courseware.py <path-to-html>
    python verify_courseware.py <path-to-html> --strict   # exit 1 on warnings too
    python verify_courseware.py <path-to-html> --visual   # force layer 2
"""

import argparse
import re
import sys
from pathlib import Path

PANELS = {
    "章节导航": ["chapter", "nav", "step-nav", "章节"],
    "分步引导": ["guide", "step", "prev", "next", "引导", "下一步"],
    "3D 舞台": ["canvas", "stage", "viewport", "3d"],
    "数据面板": ["data", "panel", "readout", "数据"],
    "时间轴": ["timeline", "slider", "time", "时间轴"],
}

INTERACTION_HOOKS = [
    "layer", "图层",
    "play", "播放",
    "drag", "旋转",
]

OFFLINE_KILLERS = [
    (r"https?://(?:cdn|unpkg|cdnjs|jsdelivr|esm\.sh)", "外链 CDN 资源，离线打不开"),
    (r'<script[^>]+type=["\']module["\']', "ESM script 在 file:// 下会被 CORS 拦截"),
    # Only flag fetch of a *local-looking* path. Bundled libraries (e.g. three)
    # contain fetch(...) for their own loaders; that is harmless if unused.
    (r'fetch\s*\(\s*["\'][^"\']*\.(?:json|glb|gltf|png|jpg|hdr|bin)["\']', "fetch 本地资源文件在 file:// 下会失败"),
    (r'fetch\s*\(\s*["\'][.]{1,2}/', "fetch 相对路径在 file:// 下会失败"),
]

DEBUG_HOOK = re.compile(r"window\.(?:APP|COURSEWARE|DEBUG)\s*=")

# ---------------------------------------------------------------- visual rules
SKELETON_MARK = "<!-- SKELETON"
# Escape hatch for genuinely texture-less subjects (math surfaces, force diagrams,
# circuit schematics). Must carry a reason, so exemptions stay deliberate.
TEXTURE_EXEMPT_MARK = "<!-- NO-TEXTURE-OK"

# A real embedded image: base64 payload long enough to be an actual texture
# (20k chars ≈ 15 KB binary). Tiny inline icons do not count.
DATA_URI_IMG = re.compile(r"data:image/(?:png|jpe?g|webp|avif);base64,[A-Za-z0-9+/=\s]{20000,}", re.I)
EXTERNAL_TEX = re.compile(r"""https?://[^"'\s)]+\.(?:png|jpe?g|webp|avif|hdr|ktx2)\b""", re.I)

RAF = re.compile(r"requestAnimationFrame\s*\(")
DELTA = re.compile(r"getDelta\s*\(|performance\.now\s*\(|\bdeltaTime\b|\bdTime\b|\belapsedTime\b")
EASING = re.compile(r"easeInOut|easeOut|easeIn|smoothstep|Math\.exp\(\s*-|lerp\s*\(|\bdamp")
CLAMP = re.compile(
    r"Math\.min\(\s*1\s*,\s*Math\.max\("      # clamp upper bound
    r"|Math\.max\(\s*-1\s*,\s*Math\.min\("    # clamp lower bound
    r"|MathUtils\.clamp|\bclamp\s*\("
)
SUN_UNIFORM = re.compile(r"uSunDir|uSunDirection|uLightDir|uLightDirection|uSunPosition")
SUN_READOUT = re.compile(r"sunAltitude|solarAltitude|sunHeight|solarElevation")

# Frame-accumulated transform: `obj.rotation.y += dt * k`. Breaks reversibility
# when the motion is tied to the teaching timeline. Background-only motion is
# allowed, so this is a warning with an escape clause.
ACCUM_MOTION = re.compile(r"\.rotation\.[xyz]\s*\+=\s*(?:dt|delta|dTime|deltaTime)")


def check_structure(text: str) -> tuple[list[str], list[str]]:
    lowered = text.lower()
    errors: list[str] = []
    warnings: list[str] = []

    for name, keys in PANELS.items():
        if not any(k.lower() in lowered for k in keys):
            warnings.append(f"疑似缺少面板：{name}（未找到关键词 {keys[:3]}）")

    hits = sum(1 for pair in INTERACTION_HOOKS if any(p.lower() in lowered for p in [pair]))
    if hits < 2:
        warnings.append("交互钩子偏少：至少应有图层开关、播放控制、拖拽旋转中的两个")

    for pattern, reason in OFFLINE_KILLERS:
        if re.search(pattern, text, re.I):
            errors.append(reason)

    if not DEBUG_HOOK.search(text):
        warnings.append("未发现 window.APP / window.COURSEWARE 调试钩子，无头浏览器难以自动验收")

    if "canvas" not in lowered:
        warnings.append("未发现 canvas，3D 场景可能未初始化")

    return errors, warnings


def check_visual(text: str, texture_exempt: bool = False) -> tuple[list[str], list[str]]:
    """Presence check for the three hard visual rules.

    Deliberately lenient on style, strict only on mechanisms whose absence
    guarantees a bad outcome. Never fails on library-internal code unless the
    pattern is unambiguous.
    """
    errors: list[str] = []
    warnings: list[str] = []

    # --- 规范一：贴图 ---
    if not DATA_URI_IMG.search(text):
        if texture_exempt:
            print("[NOTE] 规范一·贴图：已按 NO-TEXTURE-OK 豁免（纯几何对象）。交付说明里必须写明本课无真实影像贴图的理由，"
                  "并确认材质有合理粗糙度与环境光高光，不是平贴一张图")
        else:
            errors.append(
                "规范一·贴图：未发现内嵌的真实影像贴图。地表/主体必须用真实影像贴图（data:image/...;base64，"
                "单张足够大），手绘色块或多边形充当地表不合格。若本课件确为纯几何对象（数学曲面、受力示意），"
                "请在 HTML 顶部加 <!-- NO-TEXTURE-OK: 理由 --> 显式豁免，并在交付说明里写明。"
            )
    ext = EXTERNAL_TEX.search(text)
    if ext:
        errors.append(f"规范一·贴图：发现外链贴图 {ext.group(0)[:70]}，断网会白屏，必须内嵌为 data URI")

    # --- 规范二：动效 ---
    if not RAF.search(text):
        errors.append("规范二·动效：未发现 requestAnimationFrame，没有动画循环")
    if not DELTA.search(text):
        errors.append(
            "规范二·动效：未发现基于时间的增量（getDelta / performance.now / deltaTime），"
            "疑似每帧固定步进，帧率一变速度就变"
        )
    if not EASING.search(text):
        warnings.append(
            "规范二·动效：未发现缓动或阻尼函数，视角切换与跟随位移可能直接赋值（瞬移）"
        )
    if ACCUM_MOTION.search(text):
        warnings.append(
            "规范二·动效：发现每帧累加的变换（rotation += dt ...）。与教学时间轴绑定的运动必须可逆，"
            "应由主时间变量派生；若为纯背景装饰（星空、光晕）或第三方库内部实现，可忽略"
        )

    # --- 规范三：仿真 ---
    if SUN_READOUT.search(text) and not SUN_UNIFORM.search(text):
        errors.append(
            "规范三·仿真：有太阳高度/方位类读数，但没找到光照方向 uniform（uSunDir / uLightDir），"
            "疑似渲染与读数各算一套公式，两者必然在某个时刻打架"
        )
    if not CLAMP.search(text):
        warnings.append("规范三·仿真：未发现数值钳制（clamp / min-max），asin/acos 可能算出 NaN")

    return errors, warnings


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("html", type=Path)
    ap.add_argument("--strict", action="store_true", help="warnings also fail the check, and run visual rules")
    ap.add_argument("--visual", action="store_true", help="force the visual-quality layer")
    args = ap.parse_args()

    if not args.html.exists():
        print(f"[ERROR] 文件不存在: {args.html}")
        return 2

    text = args.html.read_text(encoding="utf-8", errors="replace")
    if not text.strip():
        print("[FAIL] 文件为空")
        return 1

    errors, warnings = check_structure(text)

    want_visual = args.strict or args.visual
    is_skeleton = SKELETON_MARK in text

    if want_visual and is_skeleton:
        print("[SKIP] 检测到 <!-- SKELETON --> 标记：这是起步骨架，跳过视觉规范检查")
        print("       填入真实贴图与动效后，删掉该标记再跑 --strict，才算成品")
    elif want_visual:
        v_err, v_warn = check_visual(text, texture_exempt=TEXTURE_EXEMPT_MARK in text)
        errors += v_err
        warnings += v_warn

    for e in errors:
        print(f"[FAIL] {e}")
    for w in warnings:
        print(f"[WARN] {w}")
    if not errors and not warnings:
        if want_visual and not is_skeleton:
            print("[OK] 结构 + 视觉规范检查通过：五件套面板、交互钩子、离线形态与三条视觉规范均在位")
        else:
            print("[OK] 结构检查通过：五件套面板、交互钩子与离线形态均在位")

    if errors or (args.strict and warnings):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
