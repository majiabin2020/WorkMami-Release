#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 12 个学科子 skill。

设计要点（防止 12 份手抄漂移）：
  * 「共享铁规速记」只有这一份 SOURCE_OF_TRUTH，在本脚本里，改一次全部重生成。
  * 学科专属正文住在子 skill 自己身上（skills/courseware-<key>/SKILL.md 的 BODY_MARKER 之后），
    手改不会被下一次重生成覆盖。
  * --init  : 首次生成，正文从学科源目录取（优先 references/subjects/_migrated/，回退 references/subjects/）
  * 默认     : 只刷新头部（frontmatter + 共享摘要 + 工作流骨架），正文保留
  * --pull-body : 强制用学科源目录的版本覆盖正文（改了源文件时用）

用法：
  python3 scripts/build_subjects.py --init
  python3 scripts/build_subjects.py            # 只刷新头部
  python3 scripts/build_subjects.py --pull-body
"""

import argparse
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKILLS_DIR = os.path.join(ROOT, "skills")

# 学科正文源：优先读迁移后的归档目录，回退到旧的 references/subjects。
# 迁移后，子 skill 自己的正文才是活的源；归档只用于 --pull-body 回滚。
SRC_CANDIDATES = [
    os.path.join(ROOT, "references", "subjects", "_migrated"),
    os.path.join(ROOT, "references", "subjects"),
]

BODY_MARKER = "# 本学科专属配置"
PARENT = "interactive-3d-courseware"

# ---------------------------------------------------------------- 学科元数据
# description 是平台自动触发的唯一依据，写清楚「触发词 + 内容范围 + 本科特色约束」。
SUBJECTS = [
    {
        "key": "geography",
        "cn": "地理",
        "display_zh": "3D 课件 · 地理",
        "display_en": "3D Courseware · Geography",
        "desc": (
            "地理学科的 3D 交互课件/虚拟实验：地球自转与昼夜更替、公转与地轴倾斜、"
            "黄赤交角与直射点回归、昼夜长短与四季、太阳周日视运动、水循环与径流、"
            "地形与大气环流。做「可旋转的地日系统」「拖时间轴看变化」这一类课件时使用。"
            "本学科标准是：空间关系类必须能切回「课本图对照」侧视图；极区俯视必须用高分辨率贴图，"
            "否则判为不合格。"
        ),
    },
    {
        "key": "physics",
        "cn": "物理",
        "display_zh": "3D 课件 · 物理",
        "display_en": "3D Courseware · Physics",
        "desc": (
            "物理学科的 3D 交互课件/虚拟实验：力学（斜面小车、杠杆、滑轮）、"
            "电学（电路、磁场、带电粒子）、光学（凸透镜成像、光路、色散）、"
            "热学（分子运动、温度与压强）。做「让学生亲手调仪器、找状态、读刻度」"
            "这一类实验型课件时使用。本学科默认实验型：结论必须由学生操作推导，"
            "按一次播放就能看完全部结论的，判为不合格。"
        ),
    },
    {
        "key": "chemistry",
        "cn": "化学",
        "display_zh": "3D 课件 · 化学",
        "display_en": "3D Courseware · Chemistry",
        "desc": (
            "化学学科的 3D 交互课件/虚拟实验：酸碱中和滴定与 pH 突跃、滴定操作与指示剂变色、"
            "化学反应速率、溶液配制与浓度、物质结构与晶体、化学实验装置。"
            "做「滴定、反应速率、浓度换算、结构与键」这一类课件时使用。"
            "本学科默认实验型：器材规格与教材版本必须先核对，数值必须独立复算，不能照抄任务书期望值。"
        ),
    },
    {
        "key": "biology",
        "cn": "生物",
        "display_zh": "3D 课件 · 生物",
        "display_en": "3D Courseware · Biology",
        "desc": (
            "生物学科的 3D 交互课件/虚拟实验：细胞与细胞器、酶活性与温度/pH 的影响、"
            "遗传与基因表达、光合作用与呼吸作用、细胞分裂与减数分裂、人体生理与循环。"
            "做「细胞、酶、遗传、呼吸光合」这一类课件时使用。"
            "本学科默认实验型：观察动作必须由学生完成；默认图层必须把核心概念放在画面上，"
            "藏在容器背后或默认关闭的，判为不合格。"
        ),
    },
    {
        "key": "math",
        "cn": "数学",
        "display_zh": "3D 课件 · 数学",
        "display_en": "3D Courseware · Mathematics",
        "desc": (
            "数学学科的 3D 交互课件：函数图像与动态变化、立体几何（圆锥曲线、球、锥、柱）、"
            "数形结合、轨迹与最值、解析几何与向量、立体几何展开与截切。"
            "做「数形结合、拖参数看曲线变」这一类课件时使用。"
            "本学科要求：画面里的每一个系数都必须是严格推导出来的，不能硬编码漂亮数字；"
            "关键量用数值探针断言到 1e-14 量级。"
        ),
    },
    {
        "key": "chinese",
        "cn": "语文",
        "display_zh": "3D 课件 · 语文",
        "display_en": "3D Courseware · Chinese",
        "desc": (
            "语文学科的 3D 交互动画/课件：字词形义演变、修辞手法可视化、朗读与语感节奏、"
            "文本结构与意象空间、诗词意境、写作过程演示。做「把语言表达变成可操作画面」"
            "这一类课件时使用。本学科命中率最低：先问「学生闭眼能不能想出来」，"
            "想得出来就不要做。数字与引语必须逐字对上课本，错一处整个课件在课堂上就废了。"
        ),
    },
    {
        "key": "english",
        "cn": "英语",
        "display_zh": "3D 课件 · 英语",
        "display_en": "3D Courseware · English",
        "desc": (
            "英语学科的 3D 交互课件：时态与语态、从句结构、词汇语义空间、对话场景与交际策略、"
            "语法结构树。做「时态轴、语义关系网、句法结构」这一类课件时使用。"
            "本学科允许 2D 主画面：英语的 3D 增量通常有限，硬做 3D 只是把时间轴立起来转着看。"
        ),
    },
    {
        "key": "history",
        "cn": "历史",
        "display_zh": "3D 课件 · 历史",
        "display_en": "3D Courseware · History",
        "desc": (
            "历史学科的 3D 交互课件/时间轴课件：中外同期对照双轨、事件因果时间链、"
            "史料辨析与多视角、朝代更替与制度演变、地理与历史的交汇。"
            "做「拖时间轴看两个时空同时发生什么」这一类课件时使用。"
            "本学科以时间轴与图层为主交互；史料须标注出处与争议点，不做单一结论断言。"
        ),
    },
    {
        "key": "politics",
        "cn": "政治（思想政治）",
        "display_zh": "3D 课件 · 政治",
        "display_en": "3D Courseware · Politics",
        "desc": (
            "政治（思想政治）学科的 3D 实验型课件：供需曲线与均衡价格、价格管制（限价）、"
            "财政政策与货币政策工具原理、市场机制与价格形成、供求变动对均衡的影响。"
            "做「拖价格看短缺过剩、拖税率看曲线移动」这一类课件时使用。"
            "本学科红线最重：只讲教材里的通用原理，不评价具体制度优劣、不评价现实商品价格、"
            "不涉及现实政治人物与事件；界面保持教材口吻。"
        ),
    },
    {
        "key": "pe",
        "cn": "体育",
        "display_zh": "3D 课件 · 体育",
        "display_en": "3D Courseware · PE",
        "desc": (
            "体育学科的 3D 动作模型/课件：田径动作（立定跳远、投掷、跳绳）、球类技术与走位、"
            "健身动作分解与肌肉参与、球类战术队形、体能训练负荷。做「拖参数改动作姿态」"
            "这一类课件时使用。本学科硬前提：动作必须能用 3–5 个连续参数描述，"
            "参数一改姿态就变；拆不出参数的动作（整套套路、健美操组合）只做展示型。"
            "中考项目与得分标准按各地教材版本核对，不写「中考必考」。"
        ),
    },
    {
        "key": "art",
        "cn": "美术",
        "display_zh": "3D 课件 · 美术",
        "display_en": "3D Courseware · Art",
        "desc": (
            "美术学科的 3D 立体造型/课件：传统构件（斗拱、青铜器范铸、陶瓷胎釉）、"
            "建筑空间与构造、透视与光影实验、色彩与构成、雕塑与器物拆解。"
            "做「把照片看不到的面拆开看」这一类课件时使用。本学科标准："
            "立体造型与建筑做展示型，判据是「能看到照片看不到的面」（背面、剖面、内部、构件咬合），"
            "不是「转着好看」；透视与光影可做实验型。"
        ),
    },
    {
        "key": "music",
        "cn": "音乐",
        "display_zh": "3D 课件 · 音乐",
        "display_en": "3D Courseware · Music",
        "desc": (
            "音乐学科的 3D 音频交互课件：乐理与调式、节奏与节拍、乐器结构与发声原理、"
            "编曲织体与声部、和声进行。做「听得见也看得见」的音高柱、波形、节拍闪光课件时使用。"
            "本学科音频优先、形态允许 2D 主画面；每个声音必须有视觉孪生，"
            "关掉声音这节课也得能教；AudioContext 必须在用户手势里创建或 resume。"
        ),
    },
]

# ------------------------------------------------------- 共享铁规（唯一来源）
SHARED_BRIEF = """## 0. 先加载母 skill 的共享规范（不可跳）

本文件只是「这一科怎么教」。**共通的工艺规范在母 skill 里**，动手前必须读：

| 读什么 | 母 skill 根 = `~/.workbuddy/skills/{parent}/` |
|---|---|
| 视觉三条硬规范（贴图 / 动效 / 仿真）与判据 | `references/visual-quality.md` |
| 实验型课件五条硬要求 | `references/lab-design.md` |
| 生成用提示词模板（两个槽） | `references/prompt-template.md` |
| 模型闸门与模型路由规则 | `references/model-routing.md` |
| 验收清单与交付说明 | `references/acceptance.md` |
| 四类知识原型 | `references/prototypes.md` |

> 若本 skill 是被母 skill 派发加载的，上下文里已有这些内容，可直接用；
> 若本 skill 被平台**直接自动触发**，必须自己按上表读一遍，不要凭印象做。

## 1. 通用铁规速记（母 skill 全文为准，这里是必抄的十条）

1. **五面板结构固定**：顶部章节导航 / 左侧步骤引导 / 中间 3D 舞台 / 右侧实时数据面板 / 底部时间轴与滑杆。只有知识内核换学科，面板不换。
2. **两个槽必须人填**：槽 A「非它不可的交互」、槽 B「教材口径原话」。缺了就问，绝不自己编口径。
3. **模型闸门**：生成 3D 代码之前先问用户选哪个模型（给精确 id），再用 `Agent(model="<精确 id>")` 把代码环节路由出去。用户不换会话、不复制粘贴、不丢上下文。
4. **贴图**：主体表面必须有真实影像贴图，内嵌 data URI 断网可开，禁止手绘色块或多边形充当地表。
5. **动效**：一切运动落在时间轴上且可逆；0.6–1.0s 缓动，dt 增量做帧率无关，禁用 `position.set()` 瞬移，渲染循环只写有变化的 DOM。
6. **仿真**：一个物理量只有一个真相源，同时供给着色器和读数，禁止两套公式；相位与口径用数值探针断言，不靠看截图。
7. **范围**：先做一个关键交互，用户认可了再往下做；图层总数 < 12，默认只开 3–4 个。
8. **口径优先于观感**：定义错了，画面再美也是废品。每个数字和标签都要对回教材。
9. **不替老师讲课**：交付说明里写清教具的边界（帮学生懂，不替代讲课与做题）。
10. **验收四件套**：`verify_courseware.py --strict`（静态机检）+ `smoke_courseware.cjs`（浏览器实跑：控制台零错误 + 画面真画出来了 + 控件在位）+ 无头浏览器数值探针 + 目视截图。**机检 PASS ≠ 画面达标**，目视那一步不能省。

## 2. 通用工作流骨架（细节看母 skill）

Step 1 定原型与「非它不可的交互」→ Step 2 写 5–7 步教学脚本（每步 = 一个教学问题 + 一个学生动作 + 一个预期观察）→ Step 3 列图层与默认开关 → Step 4 填两个槽、写成自然段提示词 → Step 4.5 模型闸门 → Step 5 生成并截图迭代 5–8 轮 → Step 6 跑机检 + 探针 + 人工交互 + 口径复核 → 出交付说明。
"""

def build_header(meta):
    desc = meta["desc"]
    return """---
name: courseware-{key}
display_name_zh: {display_zh}
display_name_en: {display_en}
description: {desc}
version: "1.0.0"
parent: {parent}
---

# 3D 交互课件 · {cn}

{brief}
---

""".format(
        key=meta["key"],
        display_zh=meta["display_zh"],
        display_en=meta["display_en"],
        desc=desc,
        parent=PARENT,
        cn=meta["cn"],
        brief=SHARED_BRIEF.format(parent=PARENT),
    )


def split_body(text):
    """把子 skill 文件拆成 (header, body)。body 为 None 表示还没有正文。"""
    if BODY_MARKER not in text:
        return text, None
    head, _, body = text.partition(BODY_MARKER)
    return head, body


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--init", action="store_true", help="首次生成，正文取自 references/subjects/<key>.md")
    ap.add_argument("--pull-body", action="store_true", help="强制用 references/subjects/<key>.md 覆盖正文")
    args = ap.parse_args()

    if not os.path.isdir(SKILLS_DIR):
        os.makedirs(SKILLS_DIR)

    written, skipped, pulled = [], [], []

    for meta in SUBJECTS:
        key = meta["key"]
        d = os.path.join(SKILLS_DIR, "courseware-" + key)
        if not os.path.isdir(d):
            os.makedirs(d)
        path = os.path.join(d, "SKILL.md")

        old = ""
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                old = f.read()

        _, old_body = split_body(old)

        # 决定正文来源
        src_body = None
        src_path = None
        if args.pull_body or (args.init and old_body is None):
            for cand in SRC_CANDIDATES:
                p = os.path.join(cand, key + ".md")
                if os.path.exists(p):
                    src_path = p
                    break
            if src_path:
                with open(src_path, encoding="utf-8") as f:
                    src_body = f.read().strip()
                pulled.append(key)

        if old_body is not None and not args.pull_body:
            body = old_body
        elif src_body is not None:
            body = src_body
        else:
            body = "（待补充：本学科专属配置尚未迁移。请从 `references/subjects/%s.md` 复制，或直接编写。）" % key

        content = build_header(meta) + BODY_MARKER + "\n\n" + body.strip() + "\n"

        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        written.append("courseware-" + key)

    print("生成 %d 个子 skill：" % len(written))
    for w in written:
        print("  -", w)
    if pulled:
        print("正文来源 references/subjects/：", ", ".join(pulled))
    if skipped:
        print("跳过：", ", ".join(skipped))
    return 0


if __name__ == "__main__":
    sys.exit(main())
