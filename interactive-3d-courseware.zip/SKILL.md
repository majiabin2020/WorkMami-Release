---
name: interactive-3d-courseware
description: Design, build and validate a single-file 3D interactive courseware HTML for K-12 teaching. This is the hub skill: it holds the shared craft rules (three visual hard rules, model gate, seven-step workflow, acceptance checklist) and routes each subject to its own sub-skill — courseware-geography / physics / chemistry / biology / math / chinese / english / history / politics / pe / art / music. Use it for any "3D 课件/交互课件/虚拟实验/可旋转教学模型" request, including subject-specific ones. Output: one offline, double-click-to-open HTML with a five-panel layout, layer toggles, a timeline and a live data panel; music courseware carries Web Audio synthesis. Owns teaching design and QA; offline bundling is delegated to the threejs-single-file-app skill.
license: MIT
version: 0.9.0
agent_created: true
---

# interactive-3d-courseware · 3D 互动课件工坊

Make a 3D courseware that functions as a **teaching aid**, not a demo animation. The output is one HTML file that opens by double-click, runs offline, supports drag/rotate, and follows a fixed five-panel layout.

## 学科路由 —— 先定学科，再干活

本文件是**总 skill**。十二个学科各有自己的子 skill：学科专属的原型、图层、教材红线、学科坑位都在子 skill 里；**共通的工艺规范（三条视觉硬规范、模型闸门、七步工作流、验收清单）在本文件里**，被子 skill 引用。

| 学科 | 子 skill | 定位 | 这一科最容易翻车的地方 |
|---|---|---|---|
| 地理 | `courseware-geography` | 展示型为主 | 极区俯视糊成一团；课本图对照按钮 |
| 物理 | `courseware-physics` | 实验型为主 | 器材版本与教材对不上；结论被自动动画代劳 |
| 化学 | `courseware-chemistry` | 实验型为主 | 数值照抄任务书期望值；器材规格 |
| 生物 | `courseware-biology` | 实验型为主 | 核心概念默认关着或藏在容器背后 |
| 数学 | `courseware-math` | 数形结合 | 系数硬编码而不是推导出来的 |
| 语文 | `courseware-chinese` | 命中率最低 | 引语数字没逐字对课本；硬做 3D |
| 英语 | `courseware-english` | 形态允许 2D 主画面 | 3D 增量有限，硬做只是把时间轴立起来 |
| 历史 | `courseware-history` | 时间轴与双轨 | 史料无出处；把争议说成定论 |
| 政治 | `courseware-politics` | 实验型 | 内容边界越线；界面口吻脱离教材 |
| 体育 | `courseware-pe` | 动作参数化 | 动作拆不出连续参数；中考口径未按版本核对 |
| 美术 | `courseware-art` | 展示型为主 | 只做「转着好看」而拆不开背面剖面 |
| 音乐 | `courseware-music` | 音频优先 | AudioContext 没在用户手势里创建；声音没有视觉孪生 |

**加载方式（两种，按顺序试）**：

1. 用 Skill 工具按名调用，例如 `Skill(skill="courseware-physics")`。**已实测调通**——平台对嵌套子 skill 是运行时动态发现，不依赖会话启动时的 skill 列表快照。
2. 平台不认这个名字，就直接读文件：`~/.workbuddy/skills/interactive-3d-courseware/skills/courseware-physics/SKILL.md`。

两条都不通，就把本文件读完，按上表的定位自己套用该学科的规则——这是兜底，**不要因为加载不了子 skill 就停下来不做**。

**用户没说学科时**：先问是哪个学科、哪一册哪一章，不要自己挑一个最像的顶替。

**平台直接自动触发了某个学科子 skill（没经过本总 skill）**：子 skill 第 0 节会要求自己回读母 skill 的共享规范，按它做，不要凭印象。

## 模型闸门 —— 动手写代码之前必须先过这一关

**这是最高优先级规则，先于下面所有步骤和铁律。**

闸门要保证的是一件事：**写 3D 代码的那个环节，跑在一个用户认可的强模型上。** 不是保证用户去换会话模型——**用户不需要离开当前会话、不需要复制粘贴、不需要懂模型 id**。选择权在用户，执行由本 skill 负责。

### 闸门前置：读出当前会话模型

```bash
echo $CODEBUDDY_CURRENT_MODEL_ID
```

这个环境变量给出当前会话实际跑在哪个模型上（可能是显示名，也可能是路由别名）。读到 `flash` / `lite` / `balanced` / `均衡` 这类轻量档时，先如实告诉用户"当前会话跑在 X，做复杂 3D 和着色器是它的短板"。**但这不等于要用户去切模型**——代码环节本来就要路由出去（见下）。

### 闸门流程

在生成任何 3D 场景代码之前（尤其是自定义 GLSL 着色器、昼夜光照、材质细节、相机与后期效果），你必须**停下来，用一段显眼的话当面问用户**，不能把提醒藏在文档、注释或某一步的说明里。这段话要包含三件事：

1. **说清风险**：轻量级模型做复杂 3D 和着色器是明确短板，很容易出现"能转但不对味"、光照过曝、物理口径算反这类问题，做出来的效果会明显打折。
2. **给出可执行选项**，每个选项同时写清**精确 id** 和界面显示名，让用户知道选中之后会发生什么：

   | 精确 id（路由用） | 界面显示名 | 什么时候选它 |
   |---|---|---|
   | `mimo-v2.6-pro` | Xiaomi MiMo-V2.6-Pro | 3D 代码正确性与着色器最干净，默认首选 |
   | `space-bunny` | Space-Bunny | 场景构图与视觉表现有想法，代码也稳 |
   | `kimi-k3.1-pro` | Kimi-K3.1-Pro | 前端审美强，多轮改稿有耐心 |
   | `deepseek-v4-pro` | DeepSeek-V4-Pro | 出初稿快，适合先看整体再迭代 |
   | `deepseek-v4.1-flash` | DeepSeek-V4.1-Flash | 只在赶时间、能接受打折扣时用 |

   完整平台模型清单（含全部 id）见 `references/model-routing.md`。**不要把界面显示名当 id 传给路由**，两者对不上，路由不会生效。
3. **说清分工和承诺**：教案设计、两个槽的填写、教材口径核对、截图验收、挑错与返修由主控全程负责；**3D 代码由用户选中的那个模型来写**。并且明确告诉用户一句话：**"你选完就不用动了，不用切会话、不用复制粘贴，我直接把你选的模型拉进来写代码。"**

最后明确问一句：**"用哪个模型来写 3D 代码？"**（有问答工具就用工具给选项，别让用户打字猜 id）

**没有做出这个提醒、没有拿到用户明确回复，就不许开始生成 3D 代码。** 这不是建议，是闸门。沉默、没提、或把提醒藏在文档里都算违规。记住用户为此发过火——他知道风险却没被提醒，等于被坑。

### 拿到回复之后的分支

- **用户选了表里的模型（推荐路径）**：**主控自己不写 3D 代码。** 用 `Agent(model="<精确 id>")` 起一个子代理，把自包含的规格包喂给它，让它产出 3D 代码文件；主控翻成验收者，跑完 Step 6 的机检、探针与目视验收，不合格就打回同一个子代理返修。细节见 Step 4.5。
- **用户说"就用当前模型"**：明确记下风险，然后继续 Step 5（在当前会话写），并在交付说明里如实写清哪些地方打了折。
- **用户沉默或没选**：追问一次；再没回就按默认 `mimo-v2.6-pro` 路由，**不要因为选型卡住整条流程**，并在交付说明里注明"3D 代码由默认模型生成"。
- **子代理路由不可用**（工具不支持 `model` 参数，或该 id 不可路由）：降级到旧路径——把规格包落成一份可复制文件交给用户，并说明"这条路要你自己切模型后粘贴"。

**闸门只拦一件事：不让一个用户没认可过的弱模型偷偷写 3D 代码。** 这一件事拦住了，剩下的流程不许再让用户额外干活。

## Non-negotiable rules

1. **Two slots must be answered by a human; never invent them.**
   - Slot A — "非它不可的交互": the one moment in this lesson that a blackboard and a video cannot do, and the student must operate by hand. Examples: set the axial tilt to 0°, punch a hole in a cell membrane, reverse the current, drag a function parameter.
   - Slot B — "教材口径": the exact textbook wording — 23°26′ vs 23.5°, whether twilight counts into day length, which terms are in scope. If the user has not supplied Slot B, ask; never guess academic口径.
   - Ask both before generating any code when they are missing. One short question with the two slots is enough.
2. **The model gate above is mandatory.** Never let a weak model quietly write the 3D code. Ask first, then route the code step to the model the user picked — the gate is about *which model writes the code*, not about whether the user switched their own session model. See the dedicated section at the top.
3. **The three visual hard rules are mandatory for every 3D courseware.** Real embedded textures, time-based reversible motion, one source of truth for simulated quantities. No exceptions for "simple" scenes. See the section right below and `references/visual-quality.md`.
4. **Fidelity of knowledge beats visual polish.** Wrong definitions in a beautiful scene are a failed deliverable. Verify every number and label against the textbook口径 before shipping.
5. **Scope by one interaction, not a whole platform.** Build the one key interaction first; get user sign-off; then add the rest.
6. **Never claim the courseware replaces a teacher or practice.** State the limits in the handoff note (see references/acceptance.md).
7. **Teaching intent goes into the prompt.** Describe where the student should get stuck, not how the picture should look. Visual descriptions alone produce a pretty animation that teaches nothing.
8. **Lab chapters must satisfy the five hard requirements in `references/lab-design.md`.** The one most often broken: the observation action (finding the sharp image, balancing the balance, locating the critical angle) stays a manual student operation. A courseware where one "play" button reveals every conclusion is a fail.
9. **Audio is opt-in, and every sound needs a visual twin.** A music courseware must create or `resume()` its `AudioContext` inside a user gesture — instantiate it on page load and the browser silently parks it in `suspended`, with no error and no sound. Every audio event must also be rendered visually (pitch column, waveform, beat flash), and the rule is: **turn the sound off and the lesson still has to teach.** A classroom without speakers is the normal case, not the edge case. See `courseware-music` §2.

## 两类课件：展示型 / 实验型（先分类，再动手）

物理、化学、生物的大部分章节属于**实验型**——结论是实验数据推出来的，学生得亲手调仪器、找状态、读刻度、记数据。这类课件的定位不是展示模型，是**实验工具**。按展示型的标准做实验章节，做出来一定是"会转的动画片"。

Step 1 除了定原型，先回答一句：**这一节是不是让学生动手做一遍才得出结论的？**

- **实验型** → `references/lab-design.md` 的五条硬要求全部生效：自变量连续可调且可复位、因变量实时测量且单一算法源、**观测动作不许替学生完成**、数据可记录可对比、临界与失败态可复现。
- **展示型** → 按下面的视觉硬规范与原型分类做即可。

五条里最容易做坏的是第三条：把"移动光屏找清晰的像""调天平平衡""找临界角"换成自动对焦、自动归零，实验就降级成动画了。**判据是：按住一个演示按钮从头放到尾就能看到全部结论的，不合格。**

六科的默认档位不一样，先按下表定档，再谈视觉：

| 学科 | 默认档位 | 定档依据 |
|---|---|---|
| 物理 / 化学 / 生物 | 实验型为主 | 结论靠实验数据推出来，学生得亲手调仪器、找状态、读数、记录 |
| 体育 | 实验型为主，**但有硬前提** | 动作必须能用 3–5 个连续参数描述，参数一改姿态就变。拆不出参数的动作（整套太极拳、健美操组合）只做展示型。做成了固定骨骼动画就是视频，不是课件 |
| 美术 | **展示型为主**，两处例外 | 立体造型与建筑做展示，标准是"能看到照片看不到的面"（背面、剖面、内部、构件咬合），不是"转着好看"；透视与光影可做实验型，因为灭点和光源是连续可调的 |
| 音乐 | 音频优先，**形态允许 2D 主画面** | 结论靠听出来，因变量是听觉判断，必须配同源的量化视觉支撑。不必为了凑 3D 把五线谱做成漂浮的发光条 |
| 地理 | 多为展示型 | 空间关系类（自转、公转、地形）用展示型，图层与时间轴就是交互 |
| 语文 | 命中率最低 | 先问"学生闭上眼睛能不能想出来"，想得出来就别做 |

体育、音乐、美术三科还要各读一份配置（`pe.md` / `music.md` / `art.md`）才能动手——它们各自的失败方式完全不同：体育败在参数改不动，音乐败在没声音还不报错，美术败在把平面画硬做成 3D 场景。

## 三条视觉硬规范（MUST，不是建议）

**任何 3D 交互课件都要过这三条，没有"这次简单点所以不做"的例外。** 正本见 `references/visual-quality.md`，含判据、反例与实测陷阱。

1. **贴图 —— 主体表面必须有真实影像。** 地球、行星、细胞、器官、晶体这类有真实形貌的对象，一律用真实影像贴图，**禁止手绘色块或多边形轮廓充当地表**（这是仿真度的第一道天花板）。贴图必须内嵌为 data URI，断网可开；昼夜/内外这类对偶表现用两张贴图分担，不靠滤镜算。
2. **动效 —— 一切运动落在时间轴上且可逆。** 视角/状态切换必须缓动（0.6–1.0s，不是 `position.set()` 瞬移）；动画必须用 dt 增量做帧率无关；跟随位移用阻尼但必须能吸附到精确值（否则画面与读数分裂）；主运动必须可感知（一个周期 30–60 秒，不是 24 分钟）；与教学绑定的次要运动必须由主时间变量派生，**禁止每帧累加**；渲染循环只写有变化的 DOM；首屏要有入场编排。
3. **仿真 —— 一个物理量只有一个真相源。** 太阳方向、重力、温度这类驱动量必须定义为单一常量/uniform，同时供给着色器和读数函数，**禁止两套公式**；相位符号必须用数值探针断言，不能只看截图；`asin/acos` 入参必须 clamp。

动手前就要按这三条写，不要等验收时才发现没贴图再返工。`scripts/verify_courseware.py --strict` 能机检出前两条和第三条的一半（存在性），剩下必须写运行时探针。

这三条与"反 AI 味"不冲突：反对的是堆装饰噪声，不是反对分辨率、缓动和物理层次。**克制的同时必须精细。**

## Workflow (seven checkpoints, six build steps)

Follow the sequence; do not skip the checkpoints.

### Step 1 — Locate the interaction (Slot A)
First decide whether the chapter is **explainer or lab** (see the section above); lab chapters load `references/lab-design.md` and must satisfy its five hard requirements.

Ask/derive the "one indispensable interaction". Classify the knowledge point into one of four prototypes using `references/prototypes.md`. State the classification back to the user in one sentence.

### Step 2 — Write the teaching script
Split the chapter into 5–7 steps. Each step = one teaching question + one student action + one expected observation. Use the script form in `references/prompt-template.md`. Get the step list confirmed before coding.

### Step 3 — List the layers
Enumerate every 3D element as a togglable layer. Default ON: only 3–4 key layers; the rest start OFF. The layer list is the teaching rhythm switch, not a decoration toggle. Keep the total under 12.

### Step 4 — Build the prompt
Fill the two slots in `references/prompt-template.md`. Write the prompt as natural paragraphs (no numbered short-list style). Include: five-panel layout, layer behavior, timeline, live data panel, textbook口径 constraint, and "build only step one first".

### Step 4.5 — Model gate (MANDATORY checkpoint)
Deliver the warning from the top section **verbatim in plain, prominent language** (use the question tool if available, so the user clicks an option instead of typing an id), then wait for the user's reply. Do not merge this into Step 5 or bury it in a paragraph about engineering.

**Path A — user picked a model (default path).**

You do NOT write the 3D code yourself. Spin up a sub-agent with the exact id:

```text
Agent(
  description: "3D courseware code",
  model: "<exact id, e.g. mimo-v2.6-pro>",
  prompt: "<self-contained spec pack>"
)
```

The spec pack **must be self-contained** — the sub-agent cannot see this conversation. It has to carry:

- the finished prompt from Step 4, in full
- the step script table (teaching question → student action → expected observation)
- the layer list with its default on/off states
- the textbook口径 list (Slot B): the exact wording to use, and the wording to avoid
- the skeleton path (`assets/courseware-skeleton.html`) and the five-panel shell contract
- the three visual hard rules, written as constraints rather than adjectives
- the output path and the file name
- what "done" means: file written, opens offline, no CDN, `verify_courseware.py --strict` clean

Then the main controller owns Step 6: run `scripts/verify_courseware.py --strict`, run the runtime probes in a headless browser, do the screenshot pass. **Anything that fails goes back to the same sub-agent via `resume` with a concrete defect list** — visual/polish and shader defects go back to the sub-agent; 口径 and teaching-logic defects the main controller fixes directly.

**Path B — user insists on the current model.** Acknowledge the quality risk explicitly, then continue to Step 5 in this session. Record the risk in the final handoff note so the user is not misled into thinking this is full-strength output.

**Routing constraints (measured, not guessed):**

- **Different models must be launched serially.** Launching several sub-agents with different `model` values in one parallel batch routes them all to the same model — the first one's parameter leaks into the rest. Same-model sub-agents can run in parallel.
- Never pass a UI display name as the id (`"MiMo-V2.6-Pro"`, `"Kimi K3"`); use the exact id from `references/model-routing.md`.
- Ask the sub-agent to print its model identifier on the first line of its reply (`ROUTE_OK <id>`) so the routing is at least self-reported. This is a soft check, not a proof — the real backstop is the Step 6 visual pass.

### Step 5 — Generate and inspect
Do not enter this step until Step 4.5 has been passed with an explicit user reply.

**On Path A the code arrives from the sub-agent**, so your job here is review and repair, not first authorship. **On Path B you generate it yourself**, and every bullet below applies to you directly.
- For the engineering part, when the user wants a double-click/offline single HTML file, delegate the bundling shape to the **`threejs-single-file-app`** skill (esbuild IIFE inlining, no CDN, no `type=module` on file://). Do not invent a different bundling method.
- Generate step one, take a headless-browser screenshot, and iterate on visual feedback 5–8 rounds. Fix overexposure, lighting, label overlap and camera framing here.
- **Write to the three visual hard rules from the first line of code.** Real texture inlined from the start (retrofitting textures later means rewriting the material layer), tweened camera from the start, single sun-direction constant from the start. Do not "add polish later" — polish never gets added.
- If the code came from a light-weight model under protest, or from the default pick without the user's confirmation, say so again in the handoff note and list the specific effects that were simplified.

### Step 6 — Self-test and口径 check
1. Run `scripts/verify_courseware.py <html> --strict` — structure **plus** the three visual rules. A file still carrying the `<!-- SKELETON` marker skips the visual layer, so delete that marker only after textures and motion are real.
2. Run `scripts/smoke_courseware.cjs <html> [--out 截图目录]` — runtime pass: console errors, canvas really rendered (element screenshot PNG > 12000 bytes, not file size), interaction controls present. Exit 0 = all pass. This is a different gate from `--strict`, not a replacement: `--strict` cannot see faceting or framing.
3. Run runtime probes in a headless browser against `window.APP`: assert the physics numerically (e.g. UTC 6 → Beijing daylight, New York night), assert `spinLag === 0` so the readout and the render agree, assert camera tween reaches its exact endpoint. Never sign off a phase/direction question from a screenshot alone.
4. Do a manual interaction pass (drag, timeline, every layer toggle, quiz buttons).
5. Re-check every definition and number against Slot B. Deliver with the handoff note from `references/acceptance.md`.

## Subject configuration（12 科全覆盖）

学科专属配置在 12 个子 skill 里，按上表路由加载。加载后，子 skill 的正文是这一科的原型、图层、教材红线与坑位；**共享规范仍以本文件为准**（子 skill 第 0 节列了必读清单）。

未列出的学科：用四类原型做，明确告诉用户该学科配置待补，并请用户自己提供教材口径。

**新增第 13 科**：在 `scripts/build_subjects.py` 的 `SUBJECTS` 表里加一行（`description` 是平台自动触发的唯一依据，必须写清触发词、内容范围、本科红线），在 `skills/` 下建 `courseware-<key>/SKILL.md`，跑 `python3 scripts/build_subjects.py`。共享铁规摘要只有脚本里那一份，改一次全部重生成，**不要手抄 12 份**。

**2D 主画面的允许范围**：音乐（音频优先）、英语（语义空间若做成 3D 只是把时间轴立起来转着看）、历史（史料辨析类本就不该做 3D）。其余科目默认真 3D，语文命中率最低要先问"学生闭眼能不能想出来"。用户若明确要求"一律真 3D"，照办但在 README 写明该科 3D 的增量在哪。

语文的规矩和地理不同：数字与引语必须逐字对上课本，做错一处整个课件在课堂上就废了；而且语文学科的 3D 命中率天生更低，先问"学生闭上眼睛能不能想出来"，想得出来就别做。详见 `courseware-chinese` 的"3D 必要性说明"。

物理、化学、生物还要多一层：它们的大多数章节是**实验型**，必须先过 `references/lab-design.md`，再谈视觉。物理的具体口径、器材版本与红线见 `courseware-physics`。

体育、美术、音乐三科的教材版本务必先问清学校用书：体育的中考项目各地不同（绝不能写"中考必考"）；美术的人美版 / 人教版 / 湘美版**作品选目差异很大**；音乐的人音版 / 人教版 / 湘版曲目也不同。**版本没确认就动手，选错作品或项目是硬伤。**

## Resource map

- `references/prototypes.md` — four knowledge prototypes and their interaction patterns. Load at Step 1.
- `references/lab-design.md` — **实验型课件规范**：两类课件差异、五条硬要求、观测值三层、因变量的三种形态（读数 / 听觉 / 视觉形变）、反模式、实验型验收清单。实验章节必须在 Step 1 加载。
- `references/visual-quality.md` — **the three hard visual rules** (texture / motion / simulation), with pass-fail criteria, anti-patterns and the equatorial-projection polar trap. Load before Step 5.
- `references/prompt-template.md` — natural-paragraph prompt with the two slots. Load at Steps 2 and 4.
- `references/model-routing.md` — **模型路由**：精确 id 与界面显示名的对照、平台模型清单的取法、串行发起约束、路由失败怎么降级。Step 4.5 起手前读。
- `references/acceptance.md` — QA checklist and handoff-note wording. Load at Step 6.
- `references/subjects/_template.md` — 新增学科的子 skill 模板（结构说明）。
- `skills/courseware-<key>/SKILL.md` — **12 个学科子 skill**，每个 = frontmatter + 共享铁规速记 + 本学科专属配置（原型、图层、口径红线、学科坑位）。路由表见上文。
- `scripts/build_subjects.py` — 子 skill 生成器。共享铁规摘要只有脚本里那一份，`--init` 建库、默认只刷头部不覆盖手改正文、`--pull-body` 从源重取正文。**改共享摘要改这里，不要手改 12 份。**
- `scripts/verify_courseware.py` — deterministic structure check on the output HTML.
- `scripts/smoke_courseware.cjs` — runtime browser smoke: console errors, canvas actually rendered, interaction controls present. `node scripts/smoke_courseware.cjs <html 或目录> [--out 截图目录]`. Works on a single file or a whole directory tree.
- `assets/courseware-skeleton.html` — five-panel HTML skeleton with layer/timeline/data hooks. Copy and fill; do not load into context unless needed.
- `assets/audio-probe.html` — 单选文件音频探针（自动播放限制 / 拍音周期 / 咔哒对比）。做音乐课件前在目标机器上打开一次，确认这台机器真能出声。

## Integration notes

- The five-panel shell is fixed: top chapter nav, left step guide, center 3D stage, right live data panel, bottom dual timeline. Only the knowledge core changes across subjects.
- Reuse the visual language proven by the Earth-motion reference: dark background, one accent color, thin borders, left-aligned text, instrument-style readouts. Avoid a pile of rounded cards or neon glows.
- A "textbook view" preset button is valuable for spatial topics — one click returns the free-rotated 3D scene to the standard textbook side view, bridging 3D back to the exam paper.
