---
name: token-stuck-guard
description: WorkBuddy「卡住止损」hook 安装器（借鉴微软 TokenEconomizer loop guard）。本 skill 用于把一个零模型开销的本地 hook 安装进 WorkBuddy：agent 连续 3 次失败或重复相同空转时自动打回止损，实测卡住任务省 40%~60% 计费 token、日常总体约省 5%~15%。触发词：卡住止损、省 token、省积分、降低消耗、loop guard、token-stuck-guard、安装止损 hook。
agent_created: true
---

# token-stuck-guard — WorkBuddy 卡住止损 hook

给 WorkBuddy 桌面端安装一个纯本地 hook（0 模型 token，每次工具调用约 33ms）：当 agent 在一个回合内连续失败 3 次、或原样重复相同空转调用、或输出里反复出现强失败签名时，在回合结束点把它打回——强制它停下总结、换思路或向用户交代，而不是继续烧 token 硬撞。

## 何时使用本 skill

- 用户要求安装「卡住止损 / 省 token / 降低积分消耗」相关的 hook 或机制
- 用户要求排查、更新或卸载已安装的 token-stuck-guard hook

## 安装流程

1. 运行安装器（幂等，可重复执行）：

   ```bash
   python3 <skill目录>/scripts/install.py
   ```

   安装器自动完成：复制 hook 脚本到 `~/.codebuddy/hooks/stuck_guard.py`、备份并合并 `~/.workbuddy/settings.json` 的 hooks 字段（保留用户已有 hook，如 agit）、语法编译自检、模拟 3 连败全链路自检并清理测试状态。

2. 安装完成后向用户说明验证方法：新开会话，让 agent 连续跑 3 次必失败的命令；第 3 次失败后 agent 应被打回，改为说明卡点并给出可选方向，而不是继续重试。若未生效，重启一次 WorkBuddy 桌面端。

3. 如实告知预期效果（不得夸大）：
   - 卡住/空转任务上：计费 token 约 -40% ~ -60%
   - 折算日常总体：约 -5% ~ -15%（任务顺利时 hook 零开销、零收益）
   - 依据：本机 A/B 实测（同任务对照，4 轮子代理）+ 微软 TokenEconomizer 论文消融（loop guard 单项 -5% ~ -7%）

## 排障

先看调试日志 `~/.codebuddy/hooks/stuck_state/debug.log`（`[count]`/`[loop]`/`[stop]` 三类标签），再下结论：

- 日志里没有本次调用记录 → hook 没被调用，检查 `~/.workbuddy/settings.json` 的 hooks 字段（桌面端读这里，不是 `~/.codebuddy/settings.json`）
- 有 `[stop]` 但没打回 → 看 `total` 与 `bounces` 字段（打回上限每会话 2 次）
- 全部正常但模型无反应 → 检查 kill switch `~/.codebuddy/hooks/stuck_guard.off` 是否存在

机制细节、参数与实测数据见 `references/design.md`。

## 卸载

```bash
python3 <skill目录>/scripts/uninstall.py
```

自动备份配置后移除全部注册条目、hook 脚本与状态文件，用户已有的其他 hook 原样保留。
