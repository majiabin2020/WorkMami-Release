#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
token-stuck-guard 卸载器（幂等）

  1. 从 ~/.workbuddy/settings.json 的 hooks 里移除本 skill 的全部注册条目
     （其他 hook 如 agit 原样保留），修改前自动备份
  2. 删除 ~/.codebuddy/hooks/stuck_guard.py
  3. 删除状态目录 ~/.codebuddy/hooks/stuck_state/ 下的本 skill 状态文件（保留 debug.log 可选删除）

用法：python3 uninstall.py
"""
import json
import os
import shutil
import sys
import time

HOOK_DST = os.path.expanduser("~/.codebuddy/hooks/stuck_guard.py")
STATE_DIR = os.path.expanduser("~/.codebuddy/hooks/stuck_state")
SETTINGS = os.path.expanduser("~/.workbuddy/settings.json")
KILL_SWITCH = os.path.expanduser("~/.codebuddy/hooks/stuck_guard.off")


def main() -> int:
    print("token-stuck-guard 卸载开始")
    if os.path.exists(SETTINGS):
        backup = SETTINGS + ".bak-" + time.strftime("%Y%m%d-%H%M%S")
        shutil.copy2(SETTINGS, backup)
        print("  已备份配置 -> " + os.path.basename(backup))
        with open(SETTINGS, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        hooks = cfg.get("hooks", {})
        removed = []
        for ev, groups in list(hooks.items()):
            kept = [
                grp for grp in groups
                if "stuck_guard" not in " ".join(
                    h.get("command", "") for h in grp.get("hooks", [])
                )
            ]
            if len(kept) != len(groups):
                removed.append(ev)
            if kept:
                hooks[ev] = kept
            else:
                del hooks[ev]
        with open(SETTINGS, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        print("  已移除事件注册: " + (", ".join(removed) if removed else "（无）"))
    else:
        print("  未找到 settings.json，跳过")
    for path in (HOOK_DST, KILL_SWITCH):
        if os.path.exists(path):
            os.remove(path)
            print("  已删除 " + path)
    if os.path.isdir(STATE_DIR):
        shutil.rmtree(STATE_DIR, ignore_errors=True)
        print("  已删除状态目录 " + STATE_DIR)
    print("卸载完成。若仍生效，重启一次 WorkBuddy 桌面端。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
