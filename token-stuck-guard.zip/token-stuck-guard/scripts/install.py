#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
token-stuck-guard 安装器（幂等）

做四件事：
  1. 把 stuck_guard.py 复制到 ~/.codebuddy/hooks/stuck_guard.py
  2. 向 ~/.workbuddy/settings.json 的 hooks 字段合并 4 个事件注册
     （PostToolUse / PostToolUseFailure / Stop / UserPromptSubmit），
     已有的其他 hook（如 agit）原样保留，本 skill 的条目已存在则跳过
  3. 修改前自动备份 settings.json（带时间戳）
  4. 自检：语法编译 + 模拟 3 次失败全链路 + 清理测试状态

用法：python3 install.py
卸载：python3 uninstall.py
"""
import json
import os
import shutil
import subprocess
import sys
import time

SKILL_DIR = os.path.dirname(os.path.abspath(__file__))
HOOK_SRC = os.path.join(SKILL_DIR, "stuck_guard.py")
HOOK_DST = os.path.expanduser("~/.codebuddy/hooks/stuck_guard.py")
STATE_DIR = os.path.expanduser("~/.codebuddy/hooks/stuck_state")
SETTINGS = os.path.expanduser("~/.workbuddy/settings.json")
KILL_SWITCH = os.path.expanduser("~/.codebuddy/hooks/stuck_guard.off")

EVENTS = ("PostToolUse", "PostToolUseFailure", "Stop", "UserPromptSubmit")


def hook_entry() -> dict:
    return {
        "type": "command",
        "command": "python3 " + HOOK_DST,
        "timeout": 10,
    }


def step1_copy_hook() -> None:
    os.makedirs(os.path.dirname(HOOK_DST), exist_ok=True)
    shutil.copy2(HOOK_SRC, HOOK_DST)
    os.chmod(HOOK_DST, 0o755)
    print("  [1/4] hook 脚本已复制 -> " + HOOK_DST)


def step2_merge_settings() -> None:
    if os.path.exists(SETTINGS):
        backup = SETTINGS + ".bak-" + time.strftime("%Y%m%d-%H%M%S")
        shutil.copy2(SETTINGS, backup)
        print("  [2/4] 已备份原配置 -> " + os.path.basename(backup))
        with open(SETTINGS, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    else:
        print("  [2/4] 未找到 settings.json，将新建（注意：WorkBuddy 桌面端读 ~/.workbuddy/settings.json）")
        cfg = {}
    hooks = cfg.setdefault("hooks", {})
    entry = hook_entry()
    added = []
    for ev in EVENTS:
        groups = hooks.setdefault(ev, [])
        exists = any(
            "stuck_guard" in h.get("command", "")
            for grp in groups
            for h in grp.get("hooks", [])
        )
        if not exists:
            groups.append({"hooks": [entry]})
            added.append(ev)
    with open(SETTINGS, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    if added:
        print("        新注册事件: " + ", ".join(added))
    else:
        print("        4 个事件均已注册过，跳过（幂等）")


def step3_check_kill_switch() -> None:
    if os.path.exists(KILL_SWITCH):
        os.remove(KILL_SWITCH)
        print("  [3/4] 检测到历史关停标记 stuck_guard.off，已移除（重新启用）")
    else:
        print("  [3/4] 无关停标记，正常")
    os.makedirs(STATE_DIR, exist_ok=True)


def step4_selftest() -> bool:
    r = subprocess.run([sys.executable, "-m", "py_compile", HOOK_DST],
                       capture_output=True)
    if r.returncode != 0:
        print("  [4/4] 语法编译失败！\n" + r.stderr.decode(errors="ignore"))
        return False
    sid = "install-selftest-%d" % int(time.time())
    ok = True
    try:
        for i in range(3):
            fail_payload = json.dumps({
                "session_id": sid, "hook_event_name": "PostToolUseFailure",
                "tool_name": "Bash", "call_id": "t%d-%d" % (time.time(), i),
            })
            p = subprocess.run([sys.executable, HOOK_DST], input=fail_payload.encode(),
                               capture_output=True, timeout=10)
            if p.returncode != 0:
                ok = False
        stop = subprocess.run(
            [sys.executable, HOOK_DST],
            input=json.dumps({"session_id": sid, "hook_event_name": "Stop"}).encode(),
            capture_output=True, timeout=10)
        bounced = b"continue" in stop.stdout
        if not (ok and bounced):
            ok = False
    except Exception as e:
        print("        自检异常: %s" % e)
        ok = False
    finally:
        try:
            os.remove(os.path.join(STATE_DIR, sid + ".json"))
        except OSError:
            pass
    if ok:
        print("  [4/4] 自检通过：3 连败 -> Stop 打回，全链路正常")
    else:
        print("  [4/4] 自检未通过，hook 已安装但请人工核查 debug.log")
    return ok


def main() -> int:
    print("token-stuck-guard 安装开始")
    if not os.path.exists(HOOK_SRC):
        print("错误：找不到 " + HOOK_SRC)
        return 1
    step1_copy_hook()
    step2_merge_settings()
    step3_check_kill_switch()
    ok = step4_selftest()
    print()
    if ok:
        print("安装完成。验证方法：新开会话，让 agent 连续跑 3 次必失败的命令，")
        print("第 3 次失败后它应被打回、改为说明卡点而不是闷头重试。")
        print("调试日志：" + STATE_DIR + "/debug.log")
        print("临时关停：touch " + KILL_SWITCH + "（删除该文件即恢复）")
        print("若未生效，重启一次 WorkBuddy 桌面端。")
    else:
        print("安装完成但自检有异常，请查看 " + STATE_DIR + "/debug.log")
    return 0


if __name__ == "__main__":
    sys.exit(main())
