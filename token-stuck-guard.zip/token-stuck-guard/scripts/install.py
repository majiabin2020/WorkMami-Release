#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
token-stuck-guard 安装器（幂等，v1.1 兼容 Windows）

做四件事：
  1. 把 stuck_guard.py 复制到 ~/.codebuddy/hooks/stuck_guard.py
  2. 向 ~/.workbuddy/settings.json 的 hooks 字段合并 4 个事件注册
     （PostToolUse / PostToolUseFailure / Stop / UserPromptSubmit），
     已有的其他 hook（如 agit）原样保留，本 skill 的条目已存在则跳过
  3. 修改前自动备份 settings.json（带时间戳）
  4. 自检：语法编译 + 用注册的完整命令串跑 3 连败全链路 + 清理测试状态

v1.1 修复（源自 Windows 用户实战反馈）：
  - 自动探测可用的 Python 解释器（python3 / python / py -3），注册实测可用的那个
  - 命令串对路径加引号（兼容带空格的用户目录）
  - 命令串追加 "|| exit 0" 兜底：即使脚本文件缺失、Python 损坏，
    hook 也不会非零退出阻塞会话（fail-open 从脚本内部扩展到命令层）

用法：python3 install.py   （Windows: python install.py）
卸载：python3 uninstall.py
"""
import json
import os
import shutil
import subprocess
import sys
import time

SKILL_DIR = os.path.dirname(os.path.abspath(__file__))
HOOK_SRC = os.path.join(SKILL_DIR, "stuck_guard.py")
HOOK_DST = os.path.expanduser("~/.codebuddy/hooks/stuck_guard.py")
STATE_DIR = os.path.expanduser("~/.codebuddy/hooks/stuck_state")
SETTINGS = os.path.expanduser("~/.workbuddy/settings.json")
KILL_SWITCH = os.path.expanduser("~/.codebuddy/hooks/stuck_guard.off")

EVENTS = ("PostToolUse", "PostToolUseFailure", "Stop", "UserPromptSubmit")


def find_python() -> str:
    """探测本机可用的 Python 解释器，返回命令（如 'python3' / 'py -3'）。"""
    for cand in ("python3", "python", "py -3"):
        try:
            r = subprocess.run(cand.split() + ["-c", "print(1)"],
                               capture_output=True, timeout=15)
            if r.returncode == 0:
                return cand
        except Exception:
            continue
    return "python3"


def build_command(py: str) -> str:
    # 路径加引号（兼容空格）；"|| exit 0" 兜底：任何启动失败都不阻塞会话
    return py + ' "' + HOOK_DST + '" || exit 0'


def hook_entry(command: str) -> dict:
    return {"type": "command", "command": command, "timeout": 10}


def step1_copy_hook() -> None:
    os.makedirs(os.path.dirname(HOOK_DST), exist_ok=True)
    shutil.copy2(HOOK_SRC, HOOK_DST)
    if os.name != "nt":
        os.chmod(HOOK_DST, 0o755)
    if not os.path.exists(HOOK_DST):
        raise RuntimeError("复制后仍找不到 " + HOOK_DST)
    print("  [1/4] hook 脚本已复制 -> " + HOOK_DST)


def step2_merge_settings(command: str) -> None:
    if os.path.exists(SETTINGS):
        backup = SETTINGS + ".bak-" + time.strftime("%Y%m%d-%H%M%S")
        shutil.copy2(SETTINGS, backup)
        print("  [2/4] 已备份原配置 -> " + os.path.basename(backup))
        with open(SETTINGS, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    else:
        print("  [2/4] 未找到 settings.json，将新建（WorkBuddy 桌面端读 ~/.workbuddy/settings.json）")
        cfg = {}
    hooks = cfg.setdefault("hooks", {})
    entry = hook_entry(command)
    added = []
    for ev in EVENTS:
        groups = hooks.setdefault(ev, [])
        # 旧版本条目（命令串不含 || exit 0）也视为需要更新
        exists = any(
            "stuck_guard" in h.get("command", "")
            for grp in groups
            for h in grp.get("hooks", [])
        )
        if not exists:
            groups.append({"hooks": [entry]})
            added.append(ev)
        else:
            # 幂等更新：把旧命令串替换为新命令串
            for grp in groups:
                for h in grp.get("hooks", []):
                    if "stuck_guard" in h.get("command", ""):
                        h["command"] = command
    with open(SETTINGS, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    if added:
        print("        新注册事件: " + ", ".join(added))
    else:
        print("        4 个事件均已注册，命令串已更新为当前版本")


def step3_check_kill_switch() -> None:
    if os.path.exists(KILL_SWITCH):
        os.remove(KILL_SWITCH)
        print("  [3/4] 检测到历史关停标记 stuck_guard.off，已移除（重新启用）")
    else:
        print("  [3/4] 无关停标记，正常")
    os.makedirs(STATE_DIR, exist_ok=True)


def step4_selftest(command: str) -> bool:
    r = subprocess.run([sys.executable, "-m", "py_compile", HOOK_DST],
                       capture_output=True)
    if r.returncode != 0:
        print("  [4/4] 语法编译失败！\n" + r.stderr.decode(errors="ignore"))
        return False
    sid = "install-selftest-%d" % int(time.time())
    ok = True
    try:
        for i in range(3):
            fail_payload = json.dumps({
                "session_id": sid, "hook_event_name": "PostToolUseFailure",
                "tool_name": "Bash", "call_id": "t%d-%d" % (time.time(), i),
            })
            # 用注册的完整命令串走 shell，与平台实际执行方式对齐
            p = subprocess.run(command, shell=True, input=fail_payload.encode(),
                               capture_output=True, timeout=15)
            if p.returncode != 0:
                ok = False
        stop = subprocess.run(command, shell=True,
                              input=json.dumps({"session_id": sid,
                                                "hook_event_name": "Stop"}).encode(),
                              capture_output=True, timeout=15)
        bounced = b"continue" in stop.stdout
        if not (ok and bounced):
            ok = False
    except Exception as e:
        print("        自检异常: %s" % e)
        ok = False
    finally:
        try:
            os.remove(os.path.join(STATE_DIR, sid + ".json"))
        except OSError:
            pass
    if ok:
        print("  [4/4] 自检通过：注册命令串实测 3 连败 -> Stop 打回，全链路正常")
    else:
        print("  [4/4] 自检未通过，hook 已安装但请人工核查 debug.log")
    return ok


def main() -> int:
    print("token-stuck-guard 安装开始")
    if not os.path.exists(HOOK_SRC):
        print("错误：找不到 " + HOOK_SRC)
        return 1
    py = find_python()
    command = build_command(py)
    print("  探测到解释器: " + py + "，注册命令: " + command)
    ok = False
    try:
        step1_copy_hook()
        step2_merge_settings(command)
        step3_check_kill_switch()
        ok = step4_selftest(command)
    except Exception as e:
        print("安装过程出错: %s" % e)
        print("已保留备份，可重试或用 uninstall.py 还原")
        return 1
    print()
    if ok:
        print("安装完成。验证方法：新开会话，让 agent 连续跑 3 次必失败的命令，")
        print("第 3 次失败后它应被打回、改为说明卡点而不是闷头重试。")
        print("调试日志：" + STATE_DIR + "/debug.log")
        print("临时关停：新建空文件 " + KILL_SWITCH + "（删除该文件即恢复）")
        print("若未生效，重启一次 WorkBuddy 桌面端。")
    else:
        print("安装完成但自检有异常，请查看 " + STATE_DIR + "/debug.log")
    return 0


if __name__ == "__main__":
    sys.exit(main())
