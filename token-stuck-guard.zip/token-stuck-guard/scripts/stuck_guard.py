#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
stuck_guard.py v3 — WorkBuddy「卡住止损」hook（借鉴微软 TokenEconomizer loop guard）

架构（v2，解决 transcript 落盘延迟）：
  - PostToolUse / PostToolUseFailure：显式失败实时计数（exitCode>0 / is_error / 失败事件），
    用 call_id 去重；成功与读不到输出一律中性，不清零。
  - PostToolUse 额外做「空转循环检测」（v3，对标原版 repeated identical action）：
    连续 >=3 次完全相同的调用（同工具+同参数）即使"成功"也按无进展计数。
  - Stop（回合结束，transcript 必然已落盘）：扫 transcript 尾部统计本回合新增的
    「被洗白的失败」（exitCode=0 但输出含强失败签名），与显式失败合计 >=3 则打回一次
    （continue:false + reason），随后本回合窗口清零。
  - UserPromptSubmit：若上回合判定卡住，补投递提醒。
  - fail-open：任何异常一律静默退出 0，绝不阻塞会话。
  - 开关：touch ~/.codebuddy/hooks/stuck_guard.off 即整体停用。
"""
import hashlib
import json
import os
import sys
import time

STATE_DIR = os.path.expanduser("~/.codebuddy/hooks/stuck_state")
KILL_SWITCH = os.path.expanduser("~/.codebuddy/hooks/stuck_guard.off")
STREAK_THRESHOLD = 3       # 一个回合内累计失败 N 次触发介入
LOOP_THRESHOLD = 3         # 连续 N 次完全相同的调用视为空转（v3）
STOP_BOUNCE_CAP = 2        # 每会话最多打回 2 次（防烧 token）
TRANSCRIPT_WINDOW = 256 * 1024
STATE_TTL = 3 * 86400

FAIL_SIGNATURES = (        # 强失败签名，小写匹配（TokenEconomizer：退出码被掩盖时按输出判定）
    "no such file or directory",
    "command not found",
    "permission denied",
    "traceback (most recent call last)",
    "syntaxerror",
    "segmentation fault",
    "fatal:",
)


def fail_safe():
    sys.stdout.write("")
    sys.exit(0)


def debug_log(tag: str, info: str) -> None:
    try:
        path = os.path.join(STATE_DIR, "debug.log")
        if os.path.exists(path) and os.path.getsize(path) > 512 * 1024:
            os.remove(path)
        with open(path, "a", encoding="utf-8") as f:
            f.write(time.strftime("%m-%d %H:%M:%S ") + "[" + tag + "] " + info[:1500] + "\n")
    except Exception:
        pass


def load_state(session_id: str) -> dict:
    path = os.path.join(STATE_DIR, session_id + ".json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(session_id: str, state: dict) -> None:
    try:
        os.makedirs(STATE_DIR, exist_ok=True)
        with open(os.path.join(STATE_DIR, session_id + ".json"), "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except Exception:
        pass


def cleanup_old_states() -> None:
    try:
        now = time.time()
        for name in os.listdir(STATE_DIR):
            if name.endswith(".json"):
                path = os.path.join(STATE_DIR, name)
                if now - os.path.getmtime(path) > STATE_TTL:
                    os.remove(path)
    except Exception:
        pass


def is_explicit_failure(payload) -> bool:
    if payload.get("hook_event_name") == "PostToolUseFailure":
        return True
    resp = payload.get("tool_response")
    if not isinstance(resp, dict):
        return False
    if resp.get("is_error") is True or resp.get("success") is False:
        return True
    if isinstance(resp.get("error"), str) and resp["error"].strip():
        return True
    for key in ("exit_code", "exitCode"):
        if isinstance(resp.get(key), int) and resp[key] > 0:
            return True
    tec = resp.get("tool_error_code")
    if isinstance(tec, str) and tec not in ("", "0"):
        return True
    return False


def call_hash(payload) -> str:
    """同工具+同参数 = 同一动作（用于空转循环检测，对标原版 repeated identical action）。"""
    try:
        blob = json.dumps(
            {"t": payload.get("tool_name"), "i": payload.get("tool_input")},
            ensure_ascii=False, sort_keys=True,
        )
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]
    except Exception:
        return ""


def count_signatures_in_tail(transcript_path: str) -> int:
    """扫 transcript 尾部，统计工具输出里的失败签名总次数（Stop 时刻调用，已落盘）。"""
    try:
        with open(transcript_path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - TRANSCRIPT_WINDOW))
            data = f.read().decode("utf-8", "ignore")
    except Exception:
        return 0
    total = 0
    for line in data.splitlines():
        line = line.strip()
        if not line or '"callId"' not in line or '"output"' not in line:
            continue
        try:
            d = json.loads(line)
        except Exception:
            continue
        if d.get("callId") and isinstance(d.get("output"), dict):
            text = str(d["output"].get("text") or "").lower()
            total += sum(text.count(sig) for sig in FAIL_SIGNATURES)
    return min(total, 10)


def main() -> None:
    if os.path.exists(KILL_SWITCH):
        fail_safe()
    raw = sys.stdin.read() if not sys.stdin.isatty() else ""
    if not raw.strip():
        fail_safe()
    try:
        payload = json.loads(raw)
    except Exception:
        fail_safe()

    event = payload.get("hook_event_name")
    session_id = str(payload.get("session_id") or "unknown")

    # ---------- PostToolUse / PostToolUseFailure：实时计数 ----------
    if event in ("PostToolUse", "PostToolUseFailure"):
        debug_log("count", raw)
        state = load_state(session_id)
        call_id = str(payload.get("call_id") or "")
        counted = state.setdefault("counted_calls", [])
        if is_explicit_failure(payload) and not (call_id and call_id in counted):
            state["turn_failures"] = int(state.get("turn_failures", 0)) + 1
            if call_id:
                counted.append(call_id)
                del counted[:-50]
            save_state(session_id, state)
        # v3 空转循环检测：只在 PostToolUse 上跟踪（每调用恰好一次，Failure 双触发不会重复计）
        if event == "PostToolUse":
            h = call_hash(payload)
            if h:
                if h == state.get("last_call_hash"):
                    rep = int(state.get("repeat_count", 0)) + 1
                    state["repeat_count"] = rep
                    if rep >= LOOP_THRESHOLD:
                        # 连续空转：第 3 次起每次都记 1 个无进展单位
                        state["turn_failures"] = int(state.get("turn_failures", 0)) + 1
                        debug_log("loop", json.dumps({
                            "sid": session_id[:8], "hash": h, "repeat": rep,
                        }, ensure_ascii=False))
                else:
                    state["last_call_hash"] = h
                    state["repeat_count"] = 1
                save_state(session_id, state)
        # 成功/读不到：中性，不清零（窗口只在 Stop 评估后重置）
        cleanup_old_states()
        fail_safe()

    # ---------- Stop：回合结束评估 + 打回 ----------
    if event == "Stop":
        state = load_state(session_id)
        turn_failures = int(state.get("turn_failures", 0))
        sigs = count_signatures_in_tail(str(payload.get("transcript_path") or ""))
        new_sigs = max(0, sigs - int(state.get("last_stop_sig_count", 0)))
        total = turn_failures + new_sigs
        debug_log("stop", json.dumps({
            "sid": session_id[:8], "turn_failures": turn_failures,
            "sigs": sigs, "new_sigs": new_sigs, "total": total,
            "bounces": state.get("stop_bounces", 0),
        }, ensure_ascii=False))
        bounced = False
        if (total >= STREAK_THRESHOLD
                and int(state.get("stop_bounces", 0)) < STOP_BOUNCE_CAP):
            state["stop_bounces"] = int(state.get("stop_bounces", 0)) + 1
            state["pending_notice"] = True
            bounced = True
        # 本回合窗口清零
        state["turn_failures"] = 0
        state["last_stop_sig_count"] = sigs
        state["counted_calls"] = []
        state["last_call_hash"] = ""
        state["repeat_count"] = 0
        save_state(session_id, state)
        if bounced:
            sys.stdout.write(json.dumps({
                "continue": False,
                "reason": (
                    "【止损介入】本回合检测到 %d 次工具层无进展（连续失败或重复相同空转）。"
                    "先停下：总结目前掌握的信息，换一种思路再试；如果没有把握，"
                    "直接向用户说明卡点并给出可选方向，不要再重复同样的操作。" % total
                ),
            }, ensure_ascii=False))
        else:
            sys.stdout.write("")
        sys.exit(0)

    # ---------- UserPromptSubmit：补投递 ----------
    if event == "UserPromptSubmit":
        state = load_state(session_id)
        if state.get("pending_notice"):
            state["pending_notice"] = False
            save_state(session_id, state)
            sys.stdout.write(json.dumps({
                "continue": True,
                "hookSpecificOutput": {
                    "hookEventName": "UserPromptSubmit",
                    "additionalContext": (
                        "【止损提醒】上一轮任务中工具调用多次失败。请先向用户说明卡在哪里、"
                        "给出你的判断和 2-3 个可选方向，让用户决定，不要直接继续重复同样的操作。"
                    ),
                },
            }, ensure_ascii=False))
            sys.exit(0)
        fail_safe()

    fail_safe()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        fail_safe()
