# token-stuck-guard 设计与实测数据

## 机制（v3，对标微软 TokenEconomizer loop guard）

hook 注册 4 个事件，纯本地 Python 脚本（stdlib-only），fail-open：任何异常静默放行，绝不阻塞会话。

| 事件 | 做什么 |
|---|---|
| PostToolUse / PostToolUseFailure | 实时计数显式失败（exitCode>0 / is_error / 失败事件），call_id 去重（失败时双事件同触发只计 1）；成功与读不到输出一律中性不清零。另做空转检测：连续 ≥3 次完全相同调用（同工具+同参数 sha256）即使成功也计无进展 |
| Stop（回合结束） | transcript 此刻必然已落盘：扫尾部 256KB 统计「被洗白的失败」新增数（exitCode=0 但输出含 no such file / command not found / traceback 等强签名），加显式失败合计 ≥3 → `{"continue": false, reason}` 打回一次 |
| UserPromptSubmit | 上回合判定卡住但打回没拦住时，补投递一条止损提醒（社区实测确认可达模型的通道） |

### 关键参数（scripts/stuck_guard.py 顶部）

| 参数 | 默认值 | 含义 |
|---|---|---|
| STREAK_THRESHOLD | 3 | 一个回合累计无进展 N 次触发打回 |
| LOOP_THRESHOLD | 3 | 连续 N 次相同调用视为空转 |
| STOP_BOUNCE_CAP | 2 | 每会话最多打回 2 次（防止损工具自己烧钱） |
| TRANSCRIPT_WINDOW | 256KB | Stop 时扫描 transcript 的尾部窗口 |
| STATE_TTL | 3 天 | 会话状态文件自动清理 |

### 保险丝

- 打回每会话上限 2 次、每回合窗口评估后清零、成功即复位
- fail-open 全包：坏输入、空输入、脚本崩溃一律静默 exit 0
- kill switch：`touch ~/.codebuddy/hooks/stuck_guard.off` 整体停用，删除即恢复
- 调试日志 512KB 自动轮转

## 踩坑记录（移植时必读）

1. **桌面端读 `~/.workbuddy/settings.json` 的 hooks 字段**，不是 `~/.codebuddy/settings.json`（后者是 CodeBuddy CLI 另一条产品线）。注册到错误路径 = hook 永远不触发。
2. **回合进行中 transcript 未落盘**：PostToolUse 触发瞬间去读会话记录必然扑空，"回合内读输出判定伪失败"的方案原理上不成立。判定必须放在 Stop 时刻（落盘已保证）。
3. **退出码会被洗白**：agent 常把多次失败塞进一条 Bash 命令用 `; echo exit=$?` 串联，最终退出码 0。必须靠输出签名兜底，且在 Stop 时扫"新增"数（本次总数 − 上次 Stop 记录值）。
4. **失败时 PostToolUse 与 PostToolUseFailure 双触发**：必须用 call_id 去重，否则 3 次失败记成 6 次。
5. 桌面端对 hooks 配置**热加载**（实测 WorkBuddy 5.9.3），改完不用重启；但保险起见告知用户"不生效就重启一次"。

## 为什么不做裁判模型与基线学习（原版有、本版裁掉）

- **裁判模型确认**：每次介入前多付一次模型调用。误伤代价已被"每会话打回上限 2 次"封顶，期望收益小于成本；且给 fail-open 路径引入网络依赖与故障点。
- **基线学习**：原版论文自述需在同一仓库反复跑约 6 个会话才见效，WorkBuddy 任务异构一次性，无稳定基线可学。

## 实测数据（2026-11-14，本机）

- hook 自身开销：每次工具调用约 33ms，0 模型 token（TokenEconomizer 原版每次判定需调"裁判"模型，本版为纯本地脚本）
- A/B 对照（同死文件任务 + 同加压指令，真实子代理 transcript usage 计量）：
  - 严格口径（同提示词）：回合 -41.7%，input -43.0%，非缓存 input（计费大头）**-62.6%**，output -57.8%
  - 宽松口径：input -23%，output -30%
- 折算日常总体约 **-5% ~ -15%**：卡住概率 × 单任务节省；下限对应论文 loop guard 单项消融（-5%~-7%），上限对应卡住高发的重度使用场景
- 参考：TokenEconomizer 三机制全家桶在 SWE-Bench 实测 -18.4% ~ -30.9%

## 无法区分"故意失败"与"真卡住"

测试本身（连续跑 3 次必失败命令）也会触发打回——这是设计内行为，与原版一致。真实任务里连续 3 次失败就该被叫停。
